export interface Company {
  name: string;
  ceo: string;
  logo: string | null;
  capital: number;
  reputation: number;
  marketShare: number;
}

export interface CountryData {
  id: string;
  name: string;
  population: number;
  gdpPerCapita: number;
  region: string;
  flag: string;
  licenseStatus: 'none' | 'negotiating' | 'owned';
  licenseExpiry?: Date;
  marketSize: 'small' | 'medium' | 'large';
  competitors: number;
  coverage?: number;
  customers?: number;
  arpu?: number;
}

export interface Employee {
  id: string;
  name: string;
  position: string;
  salary: number;
  skills: {
    technical: number;
    management: number;
    sales: number;
    customerService: number;
  };
  avatar: string;
  hireDate: Date;
  performance: number;
}

export interface Infrastructure {
  id: string;
  type: 'cell-tower' | 'base-station' | 'data-controller' | 'fiber-cable';
  name: string;
  cost: number;
  maintenanceCost: number;
  coverage: number;
  capacity: number;
  countryId: string;
  installDate: Date;
}

export interface MarketingCampaign {
  id: string;
  name: string;
  type: 'tv' | 'radio' | 'digital' | 'outdoor' | 'print';
  budget: number;
  duration: number;
  effectiveness: number;
  countryId: string;
  startDate: Date;
  isActive: boolean;
}

export interface Service {
  id: string;
  name: string;
  type: 'voice' | 'sms' | 'data' | 'bundle';
  price: number;
  cost: number;
  features: string[];
  popularity: number;
}

export interface ResearchProject {
  id: string;
  name: string;
  category: 'network' | 'services' | 'efficiency' | 'innovation';
  cost: number;
  duration: number;
  progress: number;
  benefits: string[];
  isCompleted: boolean;
  isActive: boolean;
}

export interface Loan {
  id: string;
  amount: number;
  interestRate: number;
  term: number;
  monthlyPayment: number;
  remainingBalance: number;
  startDate: Date;
  nextPaymentDate: Date;
}

export interface Investment {
  id: string;
  amount: number;
  equityPercentage: number;
  investorName: string;
  terms: string[];
  receiveDate: Date;
}

export interface Notification {
  id: string;
  type: 'warning' | 'info' | 'error';
  message: string;
  timestamp: Date;
}

export interface GameState {
  isAuthenticated: boolean;
  username: string;
  company: Company;
  gameDate: Date;
  gameSpeed: number;
  isPaused: boolean;
  selectedCountry: CountryData | null;
  countries: CountryData[];
  employees: Employee[];
  infrastructure: Infrastructure[];
  marketingCampaigns: MarketingCampaign[];
  services: Service[];
  researchProjects: ResearchProject[];
  loans: Loan[];
  investments: Investment[];
  notifications: Notification[];
  startDate: Date;
  monthlyExpenses: {
    salaries: number;
    maintenance: number;
    marketing: number;
    loans: number;
    other: number;
  };
  monthlyRevenue: {
    subscribers: number;
    services: number;
    other: number;
  };
  customers: {
    total: number;
    acquisition: number;
    churn: number;
    satisfaction: number;
    arpu: number;
  };
}

export type GameAction = 
  | { type: 'SET_AUTH'; payload: { username: string } }
  | { type: 'SET_COMPANY'; payload: Partial<Company> }
  | { type: 'TOGGLE_PAUSE' }
  | { type: 'ADVANCE_TIME' }
  | { type: 'SELECT_COUNTRY'; payload: CountryData }
  | { type: 'SET_COUNTRIES'; payload: CountryData[] }
  | { type: 'ADD_EMPLOYEE'; payload: Employee }
  | { type: 'UPDATE_EMPLOYEE'; payload: { id: string; updates: Partial<Employee> } }
  | { type: 'REMOVE_EMPLOYEE'; payload: string }
  | { type: 'ADD_INFRASTRUCTURE'; payload: Infrastructure }
  | { type: 'ADD_MARKETING_CAMPAIGN'; payload: MarketingCampaign }
  | { type: 'UPDATE_MARKETING_CAMPAIGN'; payload: { id: string; updates: Partial<MarketingCampaign> } }
  | { type: 'ADD_SERVICE'; payload: Service }
  | { type: 'UPDATE_SERVICE'; payload: { id: string; updates: Partial<Service> } }
  | { type: 'ADD_RESEARCH_PROJECT'; payload: ResearchProject }
  | { type: 'UPDATE_RESEARCH_PROJECT'; payload: { id: string; updates: Partial<ResearchProject> } }
  | { type: 'ADD_LOAN'; payload: Loan }
  | { type: 'ADD_INVESTMENT'; payload: Investment }
  | { type: 'ADD_NOTIFICATION'; payload: Omit<Notification, 'id' | 'timestamp'> }
  | { type: 'CLEAR_NOTIFICATIONS' }
  | { type: 'UPDATE_MONTHLY_EXPENSES'; payload: Partial<GameState['monthlyExpenses']> }
  | { type: 'UPDATE_MONTHLY_REVENUE'; payload: Partial<GameState['monthlyRevenue']> }
  | { type: 'UPDATE_CUSTOMERS'; payload: Partial<GameState['customers']> }
  | { type: 'LOAD_GAME'; payload: GameState };