import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useGame } from '../hooks/useGame';

export default function LiveAcquisitionWidget() {
  const { state } = useGame();
  const [acquisitionRate, setAcquisitionRate] = useState(0);

  useEffect(() => {
    const rate = calculateAcquisitionRate();
    setAcquisitionRate(rate);
  }, [state.company.reputation, state.selectedCountry]);

  const calculateAcquisitionRate = () => {
    if (!state.selectedCountry) return 0;
    
    const baseRate = 0.5;
    const reputationFactor = (state.company.reputation || 50) / 100;
    const employeeCount = state.employees?.filter(emp => 
      emp.countryId === state.selectedCountry?.id
    ).length || 0;
    const employeeBoost = employeeCount * 0.1;
    
    return Math.max(0.1, baseRate + reputationFactor + employeeBoost);
  };

  const status = acquisitionRate > 2 ? 'Great' : acquisitionRate > 1 ? 'Good' : 'Slow';
  const statusColor = acquisitionRate > 2 ? '#00FF00' : acquisitionRate > 1 ? '#FFFF00' : '#FF8000';

  if (!state.selectedCountry) return null;

  return (
    <View style={styles.widget}>
      <View style={styles.header}>
        <MaterialIcons name="trending-up" size={12} color="#00FFFF" />
        <Text style={styles.title}>Live</Text>
        <View style={[styles.statusDot, { backgroundColor: statusColor }]} />
      </View>
      
      <Text style={styles.rate}>{acquisitionRate.toFixed(1)}/min</Text>
      <Text style={styles.status}>{status}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  widget: {
    backgroundColor: 'rgba(0,255,255,0.1)',
    padding: 8,
    borderRadius: 6,
    alignItems: 'center',
    minWidth: 60,
    borderWidth: 1,
    borderColor: 'rgba(0,255,255,0.3)',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginBottom: 4,
  },
  title: {
    fontSize: 8,
    fontWeight: 'bold',
    color: 'white',
  },
  statusDot: {
    width: 4,
    height: 4,
    borderRadius: 2,
  },
  rate: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#00FFFF',
  },
  status: {
    fontSize: 6,
    color: 'rgba(255,255,255,0.8)',
  },
});