import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { Platform } from 'react-native';
import { GameProvider } from '../contexts/GameContext';

export default function RootLayout() {
  return (
    <SafeAreaProvider>
      <GameProvider>
        <StatusBar 
          style="light" 
          backgroundColor={Platform.OS === 'ios' ? undefined : '#000000'}
          translucent={Platform.OS === 'android'}
        />
        <Stack screenOptions={{ 
          headerShown: false,
          gestureEnabled: Platform.OS === 'ios',
          animation: Platform.OS === 'ios' ? 'slide_from_right' : 'fade'
        }}>
          <Stack.Screen name="index" />
          <Stack.Screen name="(game)" />
        </Stack>
      </GameProvider>
    </SafeAreaProvider>
  );
}