import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Modal, TextInput } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { MaterialIcons } from '@expo/vector-icons';
import { useGame } from '../../../hooks/useGame';

interface InfrastructureItem {
  id: string;
  type: 'cell-tower' | 'base-station' | 'data-controller' | 'fiber-cable' | 'server-rack' | 'satellite-dish';
  name: string;
  cost: number;
  maintenanceCost: number;
  coverage: number;
  capacity: number;
  reliability: number;
  description: string;
  icon: string;
}

const infrastructureTypes: InfrastructureItem[] = [
  {
    id: 'basic-tower',
    type: 'cell-tower',
    name: 'Basic Cell Tower',
    cost: 250000,
    maintenanceCost: 5000,
    coverage: 15,
    capacity: 500,
    reliability: 85,
    description: 'Standard cellular tower with basic coverage',
    icon: 'cell-tower'
  },
  {
    id: 'advanced-tower',
    type: 'cell-tower',
    name: 'Advanced Cell Tower',
    cost: 450000,
    maintenanceCost: 9000,
    coverage: 25,
    capacity: 1200,
    reliability: 92,
    description: 'High-capacity tower with extended range',
    icon: 'cell-tower'
  },
  {
    id: 'premium-tower',
    type: 'cell-tower',
    name: 'Premium Cell Tower',
    cost: 750000,
    maintenanceCost: 15000,
    coverage: 40,
    capacity: 2500,
    reliability: 98,
    description: '5G-ready tower with maximum coverage',
    icon: 'cell-tower'
  },
  {
    id: 'small-base-station',
    type: 'base-station',
    name: 'Small Base Station',
    cost: 75000,
    maintenanceCost: 1500,
    coverage: 5,
    capacity: 150,
    reliability: 88,
    description: 'Compact base station for urban areas',
    icon: 'router'
  },
  {
    id: 'macro-base-station',
    type: 'base-station',
    name: 'Macro Base Station',
    cost: 180000,
    maintenanceCost: 3600,
    coverage: 12,
    capacity: 800,
    reliability: 94,
    description: 'High-power base station for wide coverage',
    icon: 'router'
  },
  {
    id: 'data-controller-basic',
    type: 'data-controller',
    name: 'Basic Data Controller',
    cost: 120000,
    maintenanceCost: 2400,
    coverage: 0,
    capacity: 0,
    reliability: 15,
    description: 'Improves network reliability and data processing',
    icon: 'memory'
  },
  {
    id: 'data-controller-advanced',
    type: 'data-controller',
    name: 'Advanced Data Controller',
    cost: 280000,
    maintenanceCost: 5600,
    coverage: 0,
    capacity: 0,
    reliability: 25,
    description: 'High-performance data processing and routing',
    icon: 'memory'
  },
  {
    id: 'fiber-cable-basic',
    type: 'fiber-cable',
    name: 'Fiber Optic Cable (10km)',
    cost: 50000,
    maintenanceCost: 500,
    coverage: 0,
    capacity: 300,
    reliability: 8,
    description: 'High-speed fiber connection between towers',
    icon: 'cable'
  },
  {
    id: 'fiber-cable-premium',
    type: 'fiber-cable',
    name: 'Premium Fiber Cable (25km)',
    cost: 120000,
    maintenanceCost: 1200,
    coverage: 0,
    capacity: 800,
    reliability: 12,
    description: 'Enterprise-grade fiber with redundancy',
    icon: 'cable'
  },
  {
    id: 'server-rack-basic',
    type: 'server-rack',
    name: 'Basic Server Rack',
    cost: 85000,
    maintenanceCost: 1700,
    coverage: 0,
    capacity: 200,
    reliability: 10,
    description: 'Data center infrastructure for service hosting',
    icon: 'dns'
  },
  {
    id: 'server-rack-enterprise',
    type: 'server-rack',
    name: 'Enterprise Server Rack',
    cost: 200000,
    maintenanceCost: 4000,
    coverage: 0,
    capacity: 600,
    reliability: 18,
    description: 'High-availability server infrastructure',
    icon: 'dns'
  },
  {
    id: 'satellite-dish',
    type: 'satellite-dish',
    name: 'Satellite Communication Dish',
    cost: 350000,
    maintenanceCost: 7000,
    coverage: 100,
    capacity: 400,
    reliability: 90,
    description: 'Satellite backhaul for remote areas',
    icon: 'satellite'
  }
];

export default function InfrastructureTab() {
  const { state, dispatch } = useGame();
  const [selectedTab, setSelectedTab] = useState<'overview' | 'purchase' | 'management'>('overview');
  const [showPurchaseModal, setShowPurchaseModal] = useState(false);
  const [selectedItem, setSelectedItem] = useState<InfrastructureItem | null>(null);
  const [quantity, setQuantity] = useState('1');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const calculateNetworkMetrics = () => {
    const infrastructure = state.infrastructure?.filter(inf => inf.countryId === state.selectedCountry?.id) || [];
    
    const totalCoverage = infrastructure.reduce((sum, inf) => sum + (inf.coverage || 0), 0);
    const totalCapacity = infrastructure.reduce((sum, inf) => sum + (inf.capacity || 0), 0);
    const totalReliability = infrastructure.reduce((sum, inf) => sum + (inf.reliability || 0), 0);
    const maintenanceCost = infrastructure.reduce((sum, inf) => sum + (inf.maintenanceCost || 0), 0);
    
    // Calculate quality scores (0-100%)
    const coverage = Math.min(100, totalCoverage);
    const capacity = Math.min(100, totalCapacity / 100); // Scale down capacity
    const reliability = Math.min(100, 60 + totalReliability); // Base 60% + infrastructure bonus
    const signalStrength = Math.min(100, 40 + (infrastructure.length * 8)); // 40% base + 8% per equipment
    
    return {
      coverage,
      capacity,
      reliability,
      signalStrength,
      maintenanceCost,
      totalInfrastructure: infrastructure.length,
      networkQuality: Math.round((coverage + capacity + reliability + signalStrength) / 4)
    };
  };

  const handlePurchase = (item: InfrastructureItem) => {
    if (!state.selectedCountry) {
      dispatch({ 
        type: 'ADD_NOTIFICATION', 
        payload: { 
          type: 'warning', 
          message: 'Please select a country first before purchasing infrastructure',
          id: Date.now().toString()
        }
      });
      return;
    }

    setSelectedItem(item);
    setQuantity('1');
    setShowPurchaseModal(true);
  };

  const confirmPurchase = () => {
    if (!selectedItem || !state.selectedCountry) return;

    const qty = parseInt(quantity) || 1;
    const totalCost = selectedItem.cost * qty;
    
    if (state.company.capital < totalCost) {
      dispatch({ 
        type: 'ADD_NOTIFICATION', 
        payload: { 
          type: 'error', 
          message: `Insufficient capital. Need $${totalCost.toLocaleString()}, have $${state.company.capital.toLocaleString()}`,
          id: Date.now().toString()
        }
      });
      return;
    }

    // Create infrastructure items
    for (let i = 0; i < qty; i++) {
      const newInfrastructure = {
        id: `infrastructure_${Date.now()}_${i}_${Math.random().toString(36).substr(2, 9)}`,
        type: selectedItem.type,
        name: selectedItem.name,
        cost: selectedItem.cost,
        maintenanceCost: selectedItem.maintenanceCost,
        coverage: selectedItem.coverage,
        capacity: selectedItem.capacity,
        reliability: selectedItem.reliability,
        countryId: state.selectedCountry.id,
        installDate: new Date(state.gameDate),
        status: 'operational' as const
      };

      dispatch({ type: 'ADD_INFRASTRUCTURE', payload: newInfrastructure });
    }

    // Deduct capital
    dispatch({ type: 'SPEND_CAPITAL', payload: totalCost });

    dispatch({ 
      type: 'ADD_NOTIFICATION', 
      payload: { 
        type: 'info', 
        message: `${qty}x ${selectedItem.name} purchased for $${totalCost.toLocaleString()}!`,
        id: Date.now().toString()
      }
    });

    setShowPurchaseModal(false);
    setSelectedItem(null);
  };

  const formatCurrency = (amount: number) => {
    if (amount >= 1000000) return `$${(amount / 1000000).toFixed(2)}M`;
    if (amount >= 1000) return `$${(amount / 1000).toFixed(0)}K`;
    return `$${amount.toLocaleString()}`;
  };

  const getQualityColor = (quality: number) => {
    if (quality >= 80) return '#4CAF50';
    if (quality >= 60) return '#2196F3';
    if (quality >= 40) return '#FF9800';
    return '#F44336';
  };

  const getQualityLabel = (quality: number) => {
    if (quality >= 80) return 'Excellent';
    if (quality >= 60) return 'Good';
    if (quality >= 40) return 'Fair';
    return 'Poor';
  };

  const metrics = calculateNetworkMetrics();
  const categories = ['all', 'cell-tower', 'base-station', 'data-controller', 'fiber-cable', 'server-rack', 'satellite-dish'];
  const filteredItems = selectedCategory === 'all' 
    ? infrastructureTypes 
    : infrastructureTypes.filter(item => item.type === selectedCategory);

  const infrastructureByType = state.infrastructure?.filter(inf => inf.countryId === state.selectedCountry?.id)
    .reduce((acc, inf) => {
      acc[inf.type] = (acc[inf.type] || 0) + 1;
      return acc;
    }, {} as Record<string, number>) || {};

  if (!state.selectedCountry) {
    return (
      <View style={styles.container}>
        <LinearGradient colors={['#004D40', '#00251A']} style={styles.background}>
          <View style={styles.emptyState}>
            <MaterialIcons name="public" size={80} color="#4DD0E1" />
            <Text style={styles.emptyTitle}>Select a Market</Text>
            <Text style={styles.emptySubtitle}>
              Choose a country from the Countries tab to manage infrastructure
            </Text>
          </View>
        </LinearGradient>
      </View>
    );
  }

  return (
        <View style={styles.container}>
      <LinearGradient colors={['#000000', '#8B0040', '#006400']} style={styles.background}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Infrastructure Management</Text>
          <Text style={styles.subtitle}>{state.selectedCountry.flag} {state.selectedCountry.name}</Text>
        </View>

        {/* Tab Navigation */}
        <View style={styles.tabNavigation}>
          <TouchableOpacity
            style={[styles.tab, selectedTab === 'overview' && styles.activeTab]}
            onPress={() => setSelectedTab('overview')}
          >
            <Text style={[styles.tabText, selectedTab === 'overview' && styles.activeTabText]}>
              Overview
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.tab, selectedTab === 'purchase' && styles.activeTab]}
            onPress={() => setSelectedTab('purchase')}
          >
            <Text style={[styles.tabText, selectedTab === 'purchase' && styles.activeTabText]}>
              Purchase
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.tab, selectedTab === 'management' && styles.activeTab]}
            onPress={() => setSelectedTab('management')}
          >
            <Text style={[styles.tabText, selectedTab === 'management' && styles.activeTabText]}>
              Management
            </Text>
          </TouchableOpacity>
        </View>

        <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
          {selectedTab === 'overview' && (
            <>
              {/* Network Quality Metrics */}
              <BlurView intensity={15} style={styles.metricsGrid}>
                <View style={styles.metricCard}>
                  <MaterialIcons name="signal-cellular-4-bar" size={24} color={getQualityColor(metrics.coverage)} />
                  <Text style={[styles.metricValue, { color: getQualityColor(metrics.coverage) }]}>
                    {metrics.coverage.toFixed(1)}%
                  </Text>
                  <Text style={styles.metricLabel}>Coverage</Text>
                </View>
                
                <View style={styles.metricCard}>
                  <MaterialIcons name="speed" size={24} color={getQualityColor(metrics.signalStrength)} />
                  <Text style={[styles.metricValue, { color: getQualityColor(metrics.signalStrength) }]}>
                    {metrics.signalStrength.toFixed(1)}%
                  </Text>
                  <Text style={styles.metricLabel}>Signal Strength</Text>
                </View>
                
                <View style={styles.metricCard}>
                  <MaterialIcons name="network-check" size={24} color={getQualityColor(metrics.reliability)} />
                  <Text style={[styles.metricValue, { color: getQualityColor(metrics.reliability) }]}>
                    {metrics.reliability.toFixed(1)}%
                  </Text>
                  <Text style={styles.metricLabel}>Reliability</Text>
                </View>
                
                <View style={styles.metricCard}>
                  <MaterialIcons name="assessment" size={24} color={getQualityColor(metrics.networkQuality)} />
                  <Text style={[styles.metricValue, { color: getQualityColor(metrics.networkQuality) }]}>
                    {getQualityLabel(metrics.networkQuality)}
                  </Text>
                  <Text style={styles.metricLabel}>Overall Quality</Text>
                </View>
              </BlurView>

              {/* Infrastructure Summary */}
              <BlurView intensity={15} style={styles.section}>
                <View style={styles.sectionHeader}>
                  <MaterialIcons name="business" size={20} color="#4DD0E1" />
                  <Text style={styles.sectionTitle}>Infrastructure Summary</Text>
                </View>
                
                <View style={styles.summaryGrid}>
                  <View style={styles.summaryCard}>
                    <MaterialIcons name="cell-tower" size={20} color="#4CAF50" />
                    <Text style={styles.summaryValue}>{infrastructureByType['cell-tower'] || 0}</Text>
                    <Text style={styles.summaryLabel}>Cell Towers</Text>
                  </View>
                  
                  <View style={styles.summaryCard}>
                    <MaterialIcons name="router" size={20} color="#2196F3" />
                    <Text style={styles.summaryValue}>{infrastructureByType['base-station'] || 0}</Text>
                    <Text style={styles.summaryLabel}>Base Stations</Text>
                  </View>
                  
                  <View style={styles.summaryCard}>
                    <MaterialIcons name="memory" size={20} color="#FF9800" />
                    <Text style={styles.summaryValue}>{infrastructureByType['data-controller'] || 0}</Text>
                    <Text style={styles.summaryLabel}>Data Controllers</Text>
                  </View>
                  
                  <View style={styles.summaryCard}>
                    <MaterialIcons name="cable" size={20} color="#9C27B0" />
                    <Text style={styles.summaryValue}>{infrastructureByType['fiber-cable'] || 0}</Text>
                    <Text style={styles.summaryLabel}>Fiber Cables</Text>
                  </View>
                </View>
              </BlurView>

              {/* Maintenance Costs */}
              <BlurView intensity={15} style={styles.section}>
                <View style={styles.sectionHeader}>
                  <MaterialIcons name="build" size={20} color="#FF9800" />
                  <Text style={styles.sectionTitle}>Monthly Maintenance</Text>
                  <Text style={styles.sectionValue}>{formatCurrency(metrics.maintenanceCost)}</Text>
                </View>
                
                <View style={styles.maintenanceInfo}>
                  <Text style={styles.maintenanceText}>
                    Total Infrastructure: {metrics.totalInfrastructure} items
                  </Text>
                  <Text style={styles.maintenanceText}>
                    Average Cost per Item: {formatCurrency(metrics.maintenanceCost / Math.max(1, metrics.totalInfrastructure))}
                  </Text>
                </View>
              </BlurView>
            </>
          )}

          {selectedTab === 'purchase' && (
            <>
              {/* Category Filter */}
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.categoryFilter}>
                {categories.map(category => (
                  <TouchableOpacity
                    key={category}
                    style={[styles.categoryButton, selectedCategory === category && styles.categoryButtonActive]}
                    onPress={() => setSelectedCategory(category)}
                  >
                    <Text style={[styles.categoryText, selectedCategory === category && styles.categoryTextActive]}>
                      {category === 'all' ? 'All' : category.replace('-', ' ')}
                    </Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>

              {/* Infrastructure Items */}
              <BlurView intensity={15} style={styles.section}>
                <View style={styles.sectionHeader}>
                  <MaterialIcons name="shopping-cart" size={20} color="#4DD0E1" />
                  <Text style={styles.sectionTitle}>Available Equipment</Text>
                </View>
                
                {filteredItems.map((item) => (
                  <View key={item.id} style={styles.itemCard}>
                    <View style={styles.itemHeader}>
                      <MaterialIcons name={item.icon as any} size={24} color="#4DD0E1" />
                      <View style={styles.itemInfo}>
                        <Text style={styles.itemName}>{item.name}</Text>
                        <Text style={styles.itemDescription}>{item.description}</Text>
                      </View>
                      <View style={styles.itemActions}>
                        <Text style={styles.itemCost}>{formatCurrency(item.cost)}</Text>
                        <TouchableOpacity 
                          style={styles.purchaseButton}
                          onPress={() => handlePurchase(item)}
                        >
                          <Text style={styles.purchaseButtonText}>Buy</Text>
                        </TouchableOpacity>
                      </View>
                    </View>
                    
                    <View style={styles.itemStats}>
                      {item.coverage > 0 && (
                        <View style={styles.statItem}>
                          <MaterialIcons name="signal-cellular-4-bar" size={12} color="#4CAF50" />
                          <Text style={styles.statText}>Coverage: {item.coverage}km</Text>
                        </View>
                      )}
                      {item.capacity > 0 && (
                        <View style={styles.statItem}>
                          <MaterialIcons name="people" size={12} color="#2196F3" />
                          <Text style={styles.statText}>Capacity: {item.capacity}</Text>
                        </View>
                      )}
                      {item.reliability > 0 && (
                        <View style={styles.statItem}>
                          <MaterialIcons name="verified" size={12} color="#FF9800" />
                          <Text style={styles.statText}>Reliability: +{item.reliability}%</Text>
                        </View>
                      )}
                      <View style={styles.statItem}>
                        <MaterialIcons name="build" size={12} color="#F44336" />
                        <Text style={styles.statText}>Maintenance: {formatCurrency(item.maintenanceCost)}/mo</Text>
                      </View>
                    </View>
                  </View>
                ))}
              </BlurView>
            </>
          )}

          {selectedTab === 'management' && (
            <BlurView intensity={15} style={styles.section}>
              <View style={styles.sectionHeader}>
                <MaterialIcons name="settings" size={20} color="#4DD0E1" />
                <Text style={styles.sectionTitle}>Installed Infrastructure</Text>
              </View>
              
              {(state.infrastructure?.filter(inf => inf.countryId === state.selectedCountry?.id) || []).length === 0 ? (
                <View style={styles.emptyState}>
                  <MaterialIcons name="construction" size={48} color="rgba(255,255,255,0.5)" />
                  <Text style={styles.emptyText}>No infrastructure installed</Text>
                  <Text style={styles.emptySubtext}>Go to Purchase tab to buy equipment</Text>
                </View>
              ) : (
                (state.infrastructure?.filter(inf => inf.countryId === state.selectedCountry?.id) || []).map((infrastructure) => (
                  <View key={infrastructure.id} style={styles.managementCard}>
                    <View style={styles.managementHeader}>
                      <MaterialIcons name="cell-tower" size={20} color="#4DD0E1" />
                      <View style={styles.managementInfo}>
                        <Text style={styles.managementName}>{infrastructure.name}</Text>
                        <Text style={styles.managementDate}>
                          Installed: {infrastructure.installDate.toLocaleDateString()}
                        </Text>
                      </View>
                      <Text style={styles.managementCost}>
                        {formatCurrency(infrastructure.maintenanceCost)}/mo
                      </Text>
                    </View>
                    
                    <View style={styles.managementStats}>
                      {infrastructure.coverage > 0 && (
                        <Text style={styles.managementStat}>Coverage: {infrastructure.coverage}km</Text>
                      )}
                      {infrastructure.capacity > 0 && (
                        <Text style={styles.managementStat}>Capacity: {infrastructure.capacity}</Text>
                      )}
                      {infrastructure.reliability > 0 && (
                        <Text style={styles.managementStat}>Reliability: +{infrastructure.reliability}%</Text>
                      )}
                    </View>
                  </View>
                ))
              )}
            </BlurView>
          )}
        </ScrollView>

        {/* Purchase Modal */}
        <Modal visible={showPurchaseModal} transparent animationType="fade">
          <View style={styles.modalOverlay}>
            <BlurView intensity={40} style={styles.modalContent}>
              <Text style={styles.modalTitle}>Purchase Infrastructure</Text>
              
              {selectedItem && (
                <>
                  <Text style={styles.modalItemName}>{selectedItem.name}</Text>
                  <Text style={styles.modalItemDescription}>{selectedItem.description}</Text>
                  
                  <View style={styles.modalQuantitySection}>
                    <Text style={styles.modalQuantityLabel}>Quantity:</Text>
                    <TextInput
                      style={styles.modalQuantityInput}
                      value={quantity}
                      onChangeText={setQuantity}
                      keyboardType="numeric"
                      placeholder="1"
                      placeholderTextColor="rgba(255,255,255,0.6)"
                    />
                  </View>
                  
                  <View style={styles.modalCostSection}>
                    <View style={styles.modalCostRow}>
                      <Text style={styles.modalCostLabel}>Unit Cost:</Text>
                      <Text style={styles.modalCostValue}>{formatCurrency(selectedItem.cost)}</Text>
                    </View>
                    <View style={styles.modalCostRow}>
                      <Text style={styles.modalCostLabel}>Total Cost:</Text>
                      <Text style={styles.modalCostValue}>
                        {formatCurrency(selectedItem.cost * (parseInt(quantity) || 1))}
                      </Text>
                    </View>
                    <View style={styles.modalCostRow}>
                      <Text style={styles.modalCostLabel}>Available Capital:</Text>
                      <Text style={styles.modalCostValue}>{formatCurrency(state.company.capital)}</Text>
                    </View>
                  </View>
                  
                  <View style={styles.modalButtons}>
                    <TouchableOpacity
                      style={styles.modalCancelButton}
                      onPress={() => setShowPurchaseModal(false)}
                    >
                      <Text style={styles.modalCancelText}>Cancel</Text>
                    </TouchableOpacity>
                    
                    <TouchableOpacity
                      style={styles.modalConfirmButton}
                      onPress={confirmPurchase}
                    >
                      <Text style={styles.modalConfirmText}>Purchase</Text>
                    </TouchableOpacity>
                  </View>
                </>
              )}
            </BlurView>
          </View>
        </Modal>
      </LinearGradient>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
  },
  header: {
    padding: 20,
    alignItems: 'center',
  },
  title: {
    fontSize: 36,
    fontWeight: 'bold',
    color: 'white',
  },
  subtitle: {
    fontSize: 24,
    color: 'rgba(255,255,255,0.8)',
    textAlign: 'center',
    marginTop: 6,
    fontWeight: 'bold',
  },
  tabNavigation: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.1)',
    marginHorizontal: 4,
    borderRadius: 8,
  },
  activeTab: {
    backgroundColor: '#4DD0E1',
  },
  tabText: {
    fontSize: 21,
    fontWeight: 'bold',
    color: 'rgba(255,255,255,0.8)',
  },
  activeTabText: {
    color: 'white',
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
  },
  metricsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 16,
    padding: 16,
    marginBottom: 20,
  },
  metricCard: {
    width: '48%',
    alignItems: 'center',
    marginBottom: 16,
  },
  metricValue: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 8,
    textAlign: 'center',
  },
  metricLabel: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
    textAlign: 'center',
    marginTop: 4,
  },
  section: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 16,
    padding: 16,
    marginBottom: 20,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
    gap: 8,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
    flex: 1,
  },
  sectionValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#4DD0E1',
  },
  summaryGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  summaryCard: {
    width: '48%',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 8,
    padding: 12,
    alignItems: 'center',
    marginBottom: 8,
  },
  summaryValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
    marginVertical: 4,
  },
  summaryLabel: {
    fontSize: 10,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  maintenanceInfo: {
    gap: 4,
  },
  maintenanceText: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
  },
  categoryFilter: {
    marginBottom: 16,
  },
  categoryButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 20,
    marginRight: 8,
  },
  categoryButtonActive: {
    backgroundColor: '#4DD0E1',
  },
  categoryText: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
    textTransform: 'capitalize',
  },
  categoryTextActive: {
    color: 'white',
  },
  itemCard: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
  },
  itemHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  itemInfo: {
    flex: 1,
    marginLeft: 12,
  },
  itemName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'white',
  },
  itemDescription: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
    marginTop: 2,
  },
  itemActions: {
    alignItems: 'flex-end',
  },
  itemCost: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#4DD0E1',
    marginBottom: 8,
  },
  purchaseButton: {
    backgroundColor: '#00ACC1',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
  },
  purchaseButtonText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: 'white',
  },
  itemStats: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  statText: {
    fontSize: 10,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
  },
  managementCard: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
  },
  managementHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  managementInfo: {
    flex: 1,
    marginLeft: 12,
  },
  managementName: {
    fontSize: 14,
    fontWeight: 'bold',
    color: 'white',
  },
  managementDate: {
    fontSize: 10,
    color: 'rgba(255,255,255,0.6)',
    fontWeight: 'bold',
  },
  managementCost: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#FF9800',
  },
  managementStats: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  managementStat: {
    fontSize: 10,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
  },
  emptyState: {
    alignItems: 'center',
    padding: 40,
  },
  emptyTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
    marginTop: 20,
  },
  emptySubtitle: {
    fontSize: 16,
    color: 'rgba(255,255,255,0.8)',
    textAlign: 'center',
    marginTop: 12,
    lineHeight: 24,
    fontWeight: 'bold',
  },
  emptyText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
    marginTop: 16,
  },
  emptySubtext: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.6)',
    textAlign: 'center',
    marginTop: 8,
    fontWeight: 'bold',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.7)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    width: '90%',
    maxWidth: 400,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 20,
    padding: 24,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
    marginBottom: 16,
  },
  modalItemName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#4DD0E1',
    textAlign: 'center',
  },
  modalItemDescription: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.8)',
    textAlign: 'center',
    marginBottom: 20,
    fontWeight: 'bold',
  },
  modalQuantitySection: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  modalQuantityLabel: {
    fontSize: 14,
    fontWeight: 'bold',
    color: 'white',
    marginRight: 12,
  },
  modalQuantityInput: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 8,
    padding: 8,
    fontSize: 16,
    color: 'white',
    fontWeight: 'bold',
    minWidth: 60,
    textAlign: 'center',
  },
  modalCostSection: {
    marginBottom: 24,
  },
  modalCostRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  modalCostLabel: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
  },
  modalCostValue: {
    fontSize: 14,
    fontWeight: 'bold',
    color: 'white',
  },
  modalButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  modalCancelButton: {
    flex: 1,
    backgroundColor: 'rgba(255,255,255,0.2)',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  modalCancelText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'white',
  },
  modalConfirmButton: {
    flex: 1,
    backgroundColor: '#00ACC1',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  modalConfirmText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'white',
  },
});