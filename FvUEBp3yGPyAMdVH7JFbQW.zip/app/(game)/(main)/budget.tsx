import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { MaterialIcons } from '@expo/vector-icons';
import { useGame } from '../../../hooks/useGame';

export default function BudgetTab() {
  const { state, dispatch } = useGame();
  const [selectedPeriod, setSelectedPeriod] = useState<'monthly' | 'yearly'>('monthly');

  const calculateMonthlyExpenses = () => {
    const salaries = state.employees?.reduce((sum, emp) => sum + (emp.salary || 0), 0) || 0;
    const maintenance = state.infrastructure?.reduce((sum, inf) => sum + (inf.maintenanceCost || 0), 0) || 0;
    const campaigns = state.marketingCampaigns?.filter(c => c.isActive)
      .reduce((sum, camp) => sum + (camp.budget || 0), 0) || 0;
    const loans = state.loans?.reduce((sum, loan) => sum + (loan.monthlyPayment || 0), 0) || 0;
    
    return {
      salaries,
      maintenance,
      marketing: campaigns,
      loans,
      other: 0,
      total: salaries + maintenance + campaigns + loans
    };
  };

  const calculateMonthlyRevenue = () => {
    const activeCustomers = state.customers?.filter(c => c.isActive) || [];
    const subscriberRevenue = activeCustomers.reduce((sum, customer) => sum + (customer.arpu || 0), 0);
    
    const deviceRevenue = state.deviceSalesStats?.monthlyRevenue || 0;
    const serviceRevenue = 0;
    
    return {
      subscribers: subscriberRevenue,
      devices: deviceRevenue,
      services: serviceRevenue,
      other: 0,
      total: subscriberRevenue + deviceRevenue + serviceRevenue
    };
  };

  const calculateCashFlow = () => {
    const expenses = calculateMonthlyExpenses();
    const revenue = calculateMonthlyRevenue();
    return revenue.total - expenses.total;
  };

  const calculateRunway = () => {
    const cashFlow = calculateCashFlow();
    if (cashFlow >= 0) return 'Positive Cash Flow';
    
    const monthsRemaining = Math.floor(state.company.capital / Math.abs(cashFlow));
    return monthsRemaining > 0 ? `${monthsRemaining} months` : 'Critical';
  };

  const formatCurrency = (amount: number) => {
    if (amount >= 1000000) return `$${(amount / 1000000).toFixed(2)}M`;
    if (amount >= 1000) return `$${(amount / 1000).toFixed(0)}K`;
    return `$${amount.toLocaleString()}`;
  };

  const getExpenseColor = (category: string, amount: number, total: number) => {
    const percentage = total > 0 ? (amount / total) * 100 : 0;
    if (percentage > 40) return '#F44336';
    if (percentage > 25) return '#FF9800';
    return '#4CAF50';
  };

  const expenses = calculateMonthlyExpenses();
  const revenue = calculateMonthlyRevenue();
  const cashFlow = calculateCashFlow();
  const runway = calculateRunway();

  const expenseCategories = [
    { name: 'Employee Salaries', amount: expenses.salaries, icon: 'people', auto: true },
    { name: 'Infrastructure Maintenance', amount: expenses.maintenance, icon: 'build', auto: true },
    { name: 'Marketing Campaigns', amount: expenses.marketing, icon: 'campaign', auto: true },
    { name: 'Loan Payments', amount: expenses.loans, icon: 'account-balance', auto: true },
    { name: 'Other Expenses', amount: expenses.other, icon: 'receipt', auto: false },
  ];

  const revenueCategories = [
    { name: 'Subscriber Revenue', amount: revenue.subscribers, icon: 'people', color: '#4CAF50' },
    { name: 'Device Sales', amount: revenue.devices, icon: 'phone-android', color: '#2196F3' },
    { name: 'Service Revenue', amount: revenue.services, icon: 'star', color: '#FF9800' },
    { name: 'Other Revenue', amount: revenue.other, icon: 'attach-money', color: '#9C27B0' },
  ];

  const nextPaymentDate = new Date(state.gameDate);
  nextPaymentDate.setMonth(nextPaymentDate.getMonth() + 1, 1);
  const daysUntilPayment = Math.ceil((nextPaymentDate.getTime() - state.gameDate.getTime()) / (1000 * 60 * 60 * 24));

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#000000', '#8B0040', '#006400']} style={styles.background}>
        <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
          <View style={styles.header}>
            <Text style={styles.title}>Budget Management</Text>
            <Text style={styles.subtitle}>Financial overview and cash flow analysis</Text>
          </View>

          <BlurView intensity={15} style={styles.metricsGrid}>
            <View style={styles.metricCard}>
              <MaterialIcons name="account-balance-wallet" size={16} color="#4DD0E1" />
              <Text style={styles.metricValue}>{formatCurrency(state.company.capital)}</Text>
              <Text style={styles.metricLabel}>Current Capital</Text>
            </View>
            
            <View style={styles.metricCard}>
              <MaterialIcons name={cashFlow >= 0 ? 'trending-up' : 'trending-down'} size={16} color={cashFlow >= 0 ? '#4CAF50' : '#F44336'} />
              <Text style={[styles.metricValue, { color: cashFlow >= 0 ? '#4CAF50' : '#F44336' }]}>
                {formatCurrency(Math.abs(cashFlow))}
              </Text>
              <Text style={styles.metricLabel}>Monthly Cash Flow</Text>
            </View>
            
            <View style={styles.metricCard}>
              <MaterialIcons name="schedule" size={16} color={runway === 'Critical' ? '#F44336' : '#FF9800'} />
              <Text style={[styles.metricValue, { fontSize: 11, color: runway === 'Critical' ? '#F44336' : '#FF9800' }]}>
                {runway}
              </Text>
              <Text style={styles.metricLabel}>Cash Runway</Text>
            </View>
            
            <View style={styles.metricCard}>
              <MaterialIcons name="payment" size={16} color="#2196F3" />
              <Text style={styles.metricValue}>{daysUntilPayment}</Text>
              <Text style={styles.metricLabel}>Days to Payment</Text>
            </View>
          </BlurView>

          <View style={styles.periodToggle}>
            <TouchableOpacity
              style={[styles.periodButton, selectedPeriod === 'monthly' && styles.periodButtonActive]}
              onPress={() => setSelectedPeriod('monthly')}
            >
              <Text style={[styles.periodText, selectedPeriod === 'monthly' && styles.periodTextActive]}>
                Monthly
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.periodButton, selectedPeriod === 'yearly' && styles.periodButtonActive]}
              onPress={() => setSelectedPeriod('yearly')}
            >
              <Text style={[styles.periodText, selectedPeriod === 'yearly' && styles.periodTextActive]}>
                Yearly
              </Text>
            </TouchableOpacity>
          </View>

          <BlurView intensity={15} style={styles.section}>
            <View style={styles.sectionHeader}>
              <MaterialIcons name="trending-up" size={14} color="#4CAF50" />
              <Text style={styles.sectionTitle}>Revenue ({selectedPeriod})</Text>
              <Text style={styles.sectionTotal}>{formatCurrency(revenue.total * (selectedPeriod === 'yearly' ? 12 : 1))}</Text>
            </View>
            
            {revenueCategories.map((category, index) => {
              const amount = category.amount * (selectedPeriod === 'yearly' ? 12 : 1);
              const percentage = revenue.total > 0 ? (category.amount / revenue.total) * 100 : 0;
              
              return (
                <View key={index} style={styles.categoryRow}>
                  <View style={styles.categoryHeader}>
                    <MaterialIcons name={category.icon as any} size={12} color={category.color} />
                    <Text style={styles.categoryName}>{category.name}</Text>
                    <Text style={styles.categoryAmount}>{formatCurrency(amount)}</Text>
                  </View>
                  <View style={styles.progressBar}>
                    <View 
                      style={[
                        styles.progressFill, 
                        { width: `${percentage}%`, backgroundColor: category.color }
                      ]} 
                    />
                  </View>
                  <Text style={styles.categoryPercentage}>{percentage.toFixed(1)}%</Text>
                </View>
              );
            })}
          </BlurView>

          <BlurView intensity={15} style={styles.section}>
            <View style={styles.sectionHeader}>
              <MaterialIcons name="trending-down" size={14} color="#F44336" />
              <Text style={styles.sectionTitle}>Expenses ({selectedPeriod})</Text>
              <Text style={styles.sectionTotal}>{formatCurrency(expenses.total * (selectedPeriod === 'yearly' ? 12 : 1))}</Text>
            </View>
            
            {expenseCategories.map((category, index) => {
              const amount = category.amount * (selectedPeriod === 'yearly' ? 12 : 1);
              const percentage = expenses.total > 0 ? (category.amount / expenses.total) * 100 : 0;
              const color = getExpenseColor(category.name, category.amount, expenses.total);
              
              return (
                <View key={index} style={styles.categoryRow}>
                  <View style={styles.categoryHeader}>
                    <MaterialIcons name={category.icon as any} size={12} color={color} />
                    <Text style={styles.categoryName}>{category.name}</Text>
                    {category.auto && <Text style={styles.autoBadge}>AUTO</Text>}
                    <Text style={styles.categoryAmount}>{formatCurrency(amount)}</Text>
                  </View>
                  <View style={styles.progressBar}>
                    <View 
                      style={[
                        styles.progressFill, 
                        { width: `${percentage}%`, backgroundColor: color }
                      ]} 
                    />
                  </View>
                  <Text style={styles.categoryPercentage}>{percentage.toFixed(1)}%</Text>
                </View>
              );
            })}
          </BlurView>

          {(cashFlow < 0 || state.company.capital < expenses.total * 3) && (
            <BlurView intensity={15} style={[styles.section, styles.alertSection]}>
              <View style={styles.sectionHeader}>
                <MaterialIcons name="warning" size={14} color="#F44336" />
                <Text style={[styles.sectionTitle, { color: '#F44336' }]}>Financial Alerts</Text>
              </View>
              
              {cashFlow < 0 && (
                <View style={styles.alertRow}>
                  <MaterialIcons name="error" size={12} color="#F44336" />
                  <Text style={styles.alertText}>
                    Negative cash flow: {formatCurrency(Math.abs(cashFlow))} monthly deficit
                  </Text>
                </View>
              )}
              
              {state.company.capital < expenses.total * 3 && (
                <View style={styles.alertRow}>
                  <MaterialIcons name="warning" size={12} color="#FF9800" />
                  <Text style={styles.alertText}>
                    Low runway: Less than 3 months of expenses remaining
                  </Text>
                </View>
              )}
              
              {state.company.capital < expenses.total && (
                <View style={styles.alertRow}>
                  <MaterialIcons name="error" size={12} color="#F44336" />
                  <Text style={styles.alertText}>
                    Critical: Insufficient funds for next monthly payment
                  </Text>
                </View>
              )}
            </BlurView>
          )}
        </ScrollView>
      </LinearGradient>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
    padding: 12,
  },
  header: {
    alignItems: 'center',
    marginBottom: 12,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
  },
  subtitle: {
    fontSize: 16,
    color: 'rgba(255,255,255,0.8)',
    textAlign: 'center',
    marginTop: 4,
    fontWeight: 'bold',
  },
  metricsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 12,
    padding: 12,
    marginBottom: 12,
  },
  metricCard: {
    width: '48%',
    alignItems: 'center',
    marginBottom: 12,
  },
  metricValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
    marginTop: 8,
    textAlign: 'center',
  },
  metricLabel: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
    textAlign: 'center',
    marginTop: 4,
  },
  periodToggle: {
    flexDirection: 'row',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 6,
    padding: 3,
    marginBottom: 12,
  },
  periodButton: {
    flex: 1,
    paddingVertical: 6,
    alignItems: 'center',
    borderRadius: 4,
  },
  periodButtonActive: {
    backgroundColor: '#4DD0E1',
  },
  periodText: {
    fontSize: 10,
    fontWeight: 'bold',
    color: 'rgba(255,255,255,0.8)',
  },
  periodTextActive: {
    color: 'white',
  },
  section: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 12,
    padding: 12,
    marginBottom: 12,
  },
  alertSection: {
    borderColor: 'rgba(244,67,54,0.3)',
    borderWidth: 1,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
    gap: 6,
  },
  sectionTitle: {
    fontSize: 12,
    fontWeight: 'bold',
    color: 'white',
    flex: 1,
  },
  sectionTotal: {
    fontSize: 11,
    fontWeight: 'bold',
    color: '#4DD0E1',
  },
  categoryRow: {
    marginBottom: 8,
  },
  categoryHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
    gap: 6,
  },
  categoryName: {
    flex: 1,
    fontSize: 10,
    fontWeight: 'bold',
    color: 'white',
  },
  autoBadge: {
    fontSize: 8,
    fontWeight: 'bold',
    color: '#4DD0E1',
    backgroundColor: 'rgba(77,208,225,0.2)',
    paddingHorizontal: 4,
    paddingVertical: 1,
    borderRadius: 3,
  },
  categoryAmount: {
    fontSize: 10,
    fontWeight: 'bold',
    color: 'white',
  },
  progressBar: {
    height: 4,
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 2,
    marginBottom: 3,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    borderRadius: 2,
  },
  categoryPercentage: {
    fontSize: 8,
    color: 'rgba(255,255,255,0.6)',
    fontWeight: 'bold',
    textAlign: 'right',
  },
  alertRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
    gap: 6,
  },
  alertText: {
    flex: 1,
    fontSize: 10,
    fontWeight: 'bold',
    color: 'white',
  },
});