import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, TextInput, ScrollView, StyleSheet, Platform, Modal, Alert } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { BlurView } from 'expo-blur';
import { useGame } from '../../../hooks/useGame';
import { CARIBBEAN_COUNTRIES, calculateLicenseCost, type CountryData } from '../../../constants/countries';

export default function CountriesTab() {
  const { state, dispatch } = useGame();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRegion, setSelectedRegion] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'name' | 'population' | 'gdp' | 'license'>('name');
  const [showLicenseModal, setShowLicenseModal] = useState(false);
  const [selectedCountryForLicense, setSelectedCountryForLicense] = useState<CountryData | null>(null);

  // Web alert state
  const [alertConfig, setAlertConfig] = useState<{
    visible: boolean;
    title: string;
    message: string;
    onOk?: () => void;
  }>({ visible: false, title: '', message: '' });

  const showWebAlert = (title: string, message: string, onOk?: () => void) => {
    if (Platform.OS === 'web') {
      setAlertConfig({ visible: true, title, message, onOk });
    } else {
      Alert.alert(title, message, onOk ? [{ text: 'OK', onPress: onOk }] : undefined);
    }
  };

  useEffect(() => {
    dispatch({ type: 'SET_COUNTRIES', payload: CARIBBEAN_COUNTRIES });
  }, [dispatch]);

  const regions = ['all', 'British Overseas Territories', 'Kingdom of Netherlands', 'Greater Antilles', 'Lesser Antilles', 'South America', 'Central America'];

  const filteredCountries = state.countries
    .filter(country => {
      const matchesSearch = country.name.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesRegion = selectedRegion === 'all' || country.region === selectedRegion;
      return matchesSearch && matchesRegion;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'population':
          return b.population - a.population;
        case 'gdp':
          return b.gdpPerCapita - a.gdpPerCapita;
        case 'license':
          return calculateLicenseCost(b.population) - calculateLicenseCost(a.population);
        default:
          return a.name.localeCompare(b.name);
      }
    });

  const handleSelectCountry = (country: CountryData) => {
    dispatch({ type: 'SELECT_COUNTRY', payload: country });
  };

  const handlePurchaseLicense = (country: CountryData) => {
    const licenseCost = calculateLicenseCost(country.population);
    
    if (state.company.capital < licenseCost) {
      showWebAlert('Insufficient Funds', `You need $${licenseCost.toLocaleString()} to purchase the spectrum license for ${country.name}. Current capital: $${state.company.capital.toLocaleString()}`);
      return;
    }

    setSelectedCountryForLicense(country);
    setShowLicenseModal(true);
  };

  const confirmPurchase = () => {
    if (!selectedCountryForLicense) return;

    const licenseCost = calculateLicenseCost(selectedCountryForLicense.population);
    
    // Update company capital
    dispatch({ 
      type: 'SET_COMPANY', 
      payload: { 
        capital: state.company.capital - licenseCost 
      }
    });

    // Update country license status
    const updatedCountries = state.countries.map(country => 
      country.id === selectedCountryForLicense.id 
        ? { ...country, licenseStatus: 'owned' as const, licenseExpiry: new Date(Date.now() + 10 * 365 * 24 * 60 * 60 * 1000) }
        : country
    );
    
    dispatch({ type: 'SET_COUNTRIES', payload: updatedCountries });
    dispatch({ type: 'SELECT_COUNTRY', payload: { ...selectedCountryForLicense, licenseStatus: 'owned' } });

    // Add success notification
    dispatch({ 
      type: 'ADD_NOTIFICATION', 
      payload: { 
        type: 'info', 
        message: `Successfully acquired spectrum license for ${selectedCountryForLicense.name}!` 
      }
    });

    setShowLicenseModal(false);
    setSelectedCountryForLicense(null);
  };

  const getMarketSizeColor = (size: string) => {
    switch (size) {
      case 'large': return '#F44336';
      case 'medium': return '#FF9800';
      case 'small': return '#4CAF50';
      default: return '#757575';
    }
  };

  const formatCurrency = (amount: number) => {
    if (amount >= 1000000) {
      return `$${(amount / 1000000).toFixed(2)}M`;
    } else if (amount >= 1000) {
      return `$${(amount / 1000).toFixed(0)}K`;
    }
    return `$${amount.toLocaleString()}`;
  };

  return (
        <View style={styles.container}>
      <LinearGradient colors={['#000000', '#8B0040', '#006400']} style={styles.background}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Caribbean Markets</Text>
          <Text style={styles.subtitle}>Select your market to establish operations</Text>
        </View>

        {/* Search and Filters */}
        <View style={styles.filtersContainer}>
          <View style={styles.searchContainer}>
            <MaterialIcons name="search" size={20} color="rgba(255,255,255,0.6)" />
            <TextInput
              style={styles.searchInput}
              placeholder="Search countries..."
              placeholderTextColor="rgba(255,255,255,0.6)"
              value={searchQuery}
              onChangeText={setSearchQuery}
            />
          </View>

          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.regionFilter}>
            {regions.map(region => (
              <TouchableOpacity
                key={region}
                style={[styles.regionButton, selectedRegion === region && styles.regionButtonActive]}
                onPress={() => setSelectedRegion(region)}
              >
                <Text style={[styles.regionText, selectedRegion === region && styles.regionTextActive]}>
                  {region === 'all' ? 'All Regions' : region}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>

          <View style={styles.sortContainer}>
            <Text style={styles.sortLabel}>Sort by:</Text>
            <TouchableOpacity
              style={[styles.sortButton, sortBy === 'name' && styles.sortButtonActive]}
              onPress={() => setSortBy('name')}
            >
              <Text style={[styles.sortText, sortBy === 'name' && styles.sortTextActive]}>Name</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.sortButton, sortBy === 'population' && styles.sortButtonActive]}
              onPress={() => setSortBy('population')}
            >
              <Text style={[styles.sortText, sortBy === 'population' && styles.sortTextActive]}>Population</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.sortButton, sortBy === 'license' && styles.sortButtonActive]}
              onPress={() => setSortBy('license')}
            >
              <Text style={[styles.sortText, sortBy === 'license' && styles.sortTextActive]}>License Cost</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Countries List */}
        <ScrollView style={styles.countriesList} showsVerticalScrollIndicator={false}>
          {filteredCountries.map(country => (
            <BlurView key={country.id} intensity={10} style={styles.countryCard}>
              <TouchableOpacity
                style={[styles.countryContent, state.selectedCountry?.id === country.id && styles.selectedCountry]}
                onPress={() => handleSelectCountry(country)}
              >
                <View style={styles.countryHeader}>
                  <View style={styles.countryNameSection}>
                    <Text style={styles.countryFlag}>{country.flag}</Text>
                    <View>
                      <Text style={styles.countryName}>{country.name}</Text>
                      <Text style={styles.countryRegion}>{country.region}</Text>
                    </View>
                  </View>
                  <View 
                    style={[styles.marketSizeIndicator, { backgroundColor: getMarketSizeColor(country.marketSize) }]}
                  >
                    <Text style={styles.marketSizeText}>{country.marketSize.toUpperCase()}</Text>
                  </View>
                </View>

                <View style={styles.countryStats}>
                  <View style={styles.statItem}>
                    <MaterialIcons name="people" size={16} color="#4DD0E1" />
                    <Text style={styles.statText}>{country.population.toLocaleString()}</Text>
                  </View>
                  <View style={styles.statItem}>
                    <MaterialIcons name="attach-money" size={16} color="#4DD0E1" />
                    <Text style={styles.statText}>${country.gdpPerCapita.toLocaleString()}</Text>
                  </View>
                  <View style={styles.statItem}>
                    <MaterialIcons name="business" size={16} color="#4DD0E1" />
                    <Text style={styles.statText}>{country.competitors} competitors</Text>
                  </View>
                </View>

                <View style={styles.licenseSection}>
                  <View style={styles.licenseInfo}>
                    <Text style={styles.licenseLabel}>Spectrum License:</Text>
                    <Text style={styles.licenseCost}>
                      {formatCurrency(calculateLicenseCost(country.population))}
                    </Text>
                  </View>
                  
                  {country.licenseStatus === 'none' ? (
                    <TouchableOpacity
                      style={styles.purchaseButton}
                      onPress={() => handlePurchaseLicense(country)}
                    >
                      <Text style={styles.purchaseButtonText}>Purchase License</Text>
                    </TouchableOpacity>
                  ) : (
                    <View style={styles.ownedBadge}>
                      <MaterialIcons name="check-circle" size={16} color="#4CAF50" />
                      <Text style={styles.ownedText}>Licensed</Text>
                    </View>
                  )}
                </View>
              </TouchableOpacity>
            </BlurView>
          ))}
        </ScrollView>

        {/* License Purchase Modal */}
        <Modal visible={showLicenseModal} transparent animationType="fade">
          <View style={styles.modalOverlay}>
            <BlurView intensity={40} style={styles.modalContent}>
              <Text style={styles.modalTitle}>Purchase Spectrum License</Text>
              
              {selectedCountryForLicense && (
                <>
                  <Text style={styles.modalCountry}>
                    {selectedCountryForLicense.flag} {selectedCountryForLicense.name}
                  </Text>
                  
                  <View style={styles.modalDetails}>
                    <View style={styles.modalDetailRow}>
                      <Text style={styles.modalDetailLabel}>Population:</Text>
                      <Text style={styles.modalDetailValue}>
                        {selectedCountryForLicense.population.toLocaleString()}
                      </Text>
                    </View>
                    
                    <View style={styles.modalDetailRow}>
                      <Text style={styles.modalDetailLabel}>License Cost:</Text>
                      <Text style={styles.modalDetailValue}>
                        {formatCurrency(calculateLicenseCost(selectedCountryForLicense.population))}
                      </Text>
                    </View>
                    
                    <View style={styles.modalDetailRow}>
                      <Text style={styles.modalDetailLabel}>License Term:</Text>
                      <Text style={styles.modalDetailValue}>10 years</Text>
                    </View>
                    
                    <View style={styles.modalDetailRow}>
                      <Text style={styles.modalDetailLabel}>Current Capital:</Text>
                      <Text style={styles.modalDetailValue}>
                        {formatCurrency(state.company.capital)}
                      </Text>
                    </View>
                    
                    <View style={styles.modalDetailRow}>
                      <Text style={styles.modalDetailLabel}>Remaining Capital:</Text>
                      <Text style={[styles.modalDetailValue, { color: '#4CAF50' }]}>
                        {formatCurrency(state.company.capital - calculateLicenseCost(selectedCountryForLicense.population))}
                      </Text>
                    </View>
                  </View>
                  
                  <View style={styles.modalButtons}>
                    <TouchableOpacity
                      style={styles.modalCancelButton}
                      onPress={() => setShowLicenseModal(false)}
                    >
                      <Text style={styles.modalCancelText}>Cancel</Text>
                    </TouchableOpacity>
                    
                    <TouchableOpacity
                      style={styles.modalConfirmButton}
                      onPress={confirmPurchase}
                    >
                      <Text style={styles.modalConfirmText}>Purchase License</Text>
                    </TouchableOpacity>
                  </View>
                </>
              )}
            </BlurView>
          </View>
        </Modal>

        {/* Web Alert Modal */}
        {Platform.OS === 'web' && (
          <Modal visible={alertConfig.visible} transparent animationType="fade">
            <View style={styles.alertOverlay}>
              <View style={styles.alertBox}>
                <Text style={styles.alertTitle}>{alertConfig.title}</Text>
                <Text style={styles.alertMessage}>{alertConfig.message}</Text>
                <TouchableOpacity 
                  style={styles.alertButton}
                  onPress={() => {
                    alertConfig.onOk?.();
                    setAlertConfig(prev => ({ ...prev, visible: false }));
                  }}
                >
                  <Text style={styles.alertButtonText}>OK</Text>
                </TouchableOpacity>
              </View>
            </View>
          </Modal>
        )}
      </LinearGradient>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
  },
  header: {
    padding: 20,
    alignItems: 'center',
  },
  title: {
    fontSize: 36,
    fontWeight: 'bold',
    color: 'white',
  },
  subtitle: {
    fontSize: 24,
    color: 'rgba(255,255,255,0.8)',
    textAlign: 'center',
    marginTop: 6,
    fontWeight: 'bold',
  },
  filtersContainer: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 12,
    paddingHorizontal: 16,
    marginBottom: 16,
  },
  searchInput: {
    flex: 1,
    paddingVertical: 12,
    paddingLeft: 12,
    fontSize: 16,
    color: 'white',
    fontWeight: 'bold',
  },
  regionFilter: {
    marginBottom: 16,
  },
  regionButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 20,
    marginRight: 8,
  },
  regionButtonActive: {
    backgroundColor: '#4DD0E1',
  },
  regionText: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
  },
  regionTextActive: {
    color: 'white',
  },
  sortContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  sortLabel: {
    fontSize: 14,
    color: 'white',
    fontWeight: 'bold',
  },
  sortButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 12,
  },
  sortButtonActive: {
    backgroundColor: '#4DD0E1',
  },
  sortText: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
  },
  sortTextActive: {
    color: 'white',
  },
  countriesList: {
    flex: 1,
    paddingHorizontal: 20,
  },
  countryCard: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 16,
    marginBottom: 12,
    overflow: 'hidden',
  },
  countryContent: {
    padding: 16,
  },
  selectedCountry: {
    backgroundColor: 'rgba(77,208,225,0.2)',
  },
  countryHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  countryNameSection: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  countryFlag: {
    fontSize: 32,
    marginRight: 12,
  },
  countryName: {
    fontSize: 27,
    fontWeight: 'bold',
    color: 'white',
  },
  countryRegion: {
    fontSize: 18,
    color: 'rgba(255,255,255,0.6)',
    fontWeight: 'bold',
  },
  marketSizeIndicator: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  marketSizeText: {
    fontSize: 10,
    fontWeight: 'bold',
    color: 'white',
  },
  countryStats: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  statText: {
    fontSize: 18,
    color: 'white',
    fontWeight: 'bold',
  },
  licenseSection: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  licenseInfo: {
    flex: 1,
  },
  licenseLabel: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
  },
  licenseCost: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#4DD0E1',
  },
  purchaseButton: {
    backgroundColor: '#00ACC1',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
  },
  purchaseButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
  },
  ownedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  ownedText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#4CAF50',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.7)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    width: '90%',
    maxWidth: 400,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 20,
    padding: 24,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
    marginBottom: 16,
  },
  modalCountry: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#4DD0E1',
    textAlign: 'center',
    marginBottom: 20,
  },
  modalDetails: {
    marginBottom: 24,
  },
  modalDetailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  modalDetailLabel: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
  },
  modalDetailValue: {
    fontSize: 14,
    fontWeight: 'bold',
    color: 'white',
  },
  modalButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  modalCancelButton: {
    flex: 1,
    backgroundColor: 'rgba(255,255,255,0.2)',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  modalCancelText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'white',
  },
  modalConfirmButton: {
    flex: 1,
    backgroundColor: '#00ACC1',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  modalConfirmText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'white',
  },
  alertOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  alertBox: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 8,
    minWidth: 280,
  },
  alertTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    color: 'black',
  },
  alertMessage: {
    fontSize: 16,
    marginBottom: 20,
    color: 'black',
  },
  alertButton: {
    backgroundColor: '#007AFF',
    padding: 10,
    borderRadius: 4,
    alignItems: 'center',
  },
  alertButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});