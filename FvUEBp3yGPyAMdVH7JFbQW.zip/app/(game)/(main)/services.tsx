import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, TextInput, Modal, Alert, Platform } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { MaterialIcons } from '@expo/vector-icons';
import { useGame } from '../../../hooks/useGame';

interface ServicePlan {
  id: string;
  name: string;
  type: 'voice' | 'sms' | 'data' | 'bundle';
  price: number;
  cost: number;
  features: {
    voiceMinutes?: number;
    smsMessages?: number;
    dataGB?: number;
    validity?: number;
  };
  isActive: boolean;
  popularity: number;
}

const defaultServices: Omit<ServicePlan, 'id'>[] = [
  {
    name: 'Basic Voice Plan',
    type: 'voice',
    price: 25,
    cost: 12,
    features: { voiceMinutes: 300, validity: 30 },
    isActive: true,
    popularity: 75
  },
  {
    name: 'Unlimited Voice',
    type: 'voice',
    price: 45,
    cost: 22,
    features: { voiceMinutes: 999999, validity: 30 },
    isActive: true,
    popularity: 85
  },
  {
    name: 'SMS Bundle',
    type: 'sms',
    price: 10,
    cost: 4,
    features: { smsMessages: 1000, validity: 30 },
    isActive: true,
    popularity: 60
  },
  {
    name: 'Data Starter',
    type: 'data',
    price: 15,
    cost: 8,
    features: { dataGB: 2, validity: 30 },
    isActive: true,
    popularity: 70
  },
  {
    name: 'Data Pro',
    type: 'data',
    price: 35,
    cost: 18,
    features: { dataGB: 10, validity: 30 },
    isActive: true,
    popularity: 80
  },
  {
    name: 'Ultimate Bundle',
    type: 'bundle',
    price: 65,
    cost: 32,
    features: { voiceMinutes: 999999, smsMessages: 999999, dataGB: 25, validity: 30 },
    isActive: true,
    popularity: 90
  }
];

export default function ServicesTab() {
  const { state, dispatch } = useGame();
  const [services, setServices] = useState<ServicePlan[]>(() => 
    defaultServices.map(service => ({
      ...service,
      id: `service_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    }))
  );
  
  const [selectedTab, setSelectedTab] = useState<'overview' | 'voice' | 'sms' | 'data' | 'bundle'>('overview');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingService, setEditingService] = useState<ServicePlan | null>(null);
  const [editingPrice, setEditingPrice] = useState<string | null>(null);
  const [editPrice, setEditPrice] = useState('');
  
  const [newService, setNewService] = useState({
    name: '',
    type: 'bundle' as 'voice' | 'sms' | 'data' | 'bundle',
    price: 0,
    cost: 0,
    voiceMinutes: 0,
    smsMessages: 0,
    dataGB: 0,
    validity: 30
  });

  // Web alert state
  const [alertConfig, setAlertConfig] = useState<{
    visible: boolean;
    title: string;
    message: string;
    onConfirm?: () => void;
    onCancel?: () => void;
  }>({ visible: false, title: '', message: '' });

  const showWebAlert = (title: string, message: string, onConfirm?: () => void, onCancel?: () => void) => {
    if (Platform.OS === 'web') {
      setAlertConfig({ visible: true, title, message, onConfirm, onCancel });
    } else {
      Alert.alert(
        title, 
        message, 
        onConfirm ? [
          { text: 'Cancel', onPress: onCancel },
          { text: 'Confirm', onPress: onConfirm }
        ] : [{ text: 'OK' }]
      );
    }
  };

  const getServiceTypeIcon = (type: string) => {
    switch (type) {
      case 'voice': return 'phone';
      case 'sms': return 'message';
      case 'data': return 'wifi';
      case 'bundle': return 'featured-play-list';
      default: return 'settings';
    }
  };

  const getServiceTypeColor = (type: string) => {
    switch (type) {
      case 'voice': return '#00FF00';
      case 'sms': return '#00FFFF';
      case 'data': return '#FF0000';
      case 'bundle': return '#FFFF00';
      default: return '#757575';
    }
  };

  const formatCurrency = (amount: number) => {
    return `$${amount.toLocaleString()}`;
  };

  const formatFeatures = (service: ServicePlan) => {
    const features = [];
    if (service.features.voiceMinutes) {
      features.push(service.features.voiceMinutes === 999999 ? 'Unlimited Voice' : `${service.features.voiceMinutes} mins`);
    }
    if (service.features.smsMessages) {
      features.push(service.features.smsMessages === 999999 ? 'Unlimited SMS' : `${service.features.smsMessages} SMS`);
    }
    if (service.features.dataGB) {
      features.push(`${service.features.dataGB}GB Data`);
    }
    if (service.features.validity) {
      features.push(`${service.features.validity} days`);
    }
    return features.join(' • ');
  };

  const calculateProfit = (price: number, cost: number) => {
    return price - cost;
  };

  const calculateProfitMargin = (price: number, cost: number) => {
    return price > 0 ? ((price - cost) / price * 100) : 0;
  };

  const handlePriceEdit = (serviceId: string) => {
    const service = services.find(s => s.id === serviceId);
    if (service) {
      setEditPrice(service.price.toString());
      setEditingPrice(serviceId);
    }
  };

  const savePriceEdit = (serviceId: string) => {
    const newPrice = parseFloat(editPrice) || 0;
    if (newPrice >= 1 && newPrice <= 500) {
      setServices(prev => prev.map(service => 
        service.id === serviceId ? { ...service, price: newPrice } : service
      ));
      setEditingPrice(null);
      
      dispatch({ 
        type: 'ADD_NOTIFICATION', 
        payload: { 
          type: 'info', 
          message: `Service price updated to ${formatCurrency(newPrice)}`,
          id: Date.now().toString()
        }
      });
    }
  };

  const toggleServiceStatus = (serviceId: string) => {
    setServices(prev => prev.map(service => 
      service.id === serviceId ? { ...service, isActive: !service.isActive } : service
    ));
  };

  const editService = (service: ServicePlan) => {
    setEditingService(service);
    setNewService({
      name: service.name,
      type: service.type,
      price: service.price,
      cost: service.cost,
      voiceMinutes: service.features.voiceMinutes || 0,
      smsMessages: service.features.smsMessages || 0,
      dataGB: service.features.dataGB || 0,
      validity: service.features.validity || 30
    });
    setShowEditModal(true);
  };

  const deleteService = (serviceId: string) => {
    const service = services.find(s => s.id === serviceId);
    if (service) {
      showWebAlert(
        'Delete Service',
        `Are you sure you want to delete "${service.name}"? This action cannot be undone.`,
        () => {
          setServices(prev => prev.filter(s => s.id !== serviceId));
          dispatch({ 
            type: 'ADD_NOTIFICATION', 
            payload: { 
              type: 'info', 
              message: `Service "${service.name}" deleted successfully`,
              id: Date.now().toString()
            }
          });
        }
      );
    }
  };

  const saveEditedService = () => {
    if (!editingService) return;

    if (!newService.name.trim() || newService.price <= 0) {
      showWebAlert('Error', 'Please provide service name and valid price');
      return;
    }

    const updatedService: ServicePlan = {
      ...editingService,
      name: newService.name.trim(),
      type: newService.type,
      price: newService.price,
      cost: newService.cost,
      features: {
        voiceMinutes: newService.voiceMinutes || undefined,
        smsMessages: newService.smsMessages || undefined,
        dataGB: newService.dataGB || undefined,
        validity: newService.validity
      }
    };

    setServices(prev => prev.map(service => 
      service.id === editingService.id ? updatedService : service
    ));

    setShowEditModal(false);
    setEditingService(null);
    
    dispatch({ 
      type: 'ADD_NOTIFICATION', 
      payload: { 
        type: 'info', 
        message: `Service "${updatedService.name}" updated successfully!`,
        id: Date.now().toString()
      }
    });
  };

  const createNewService = () => {
    if (!newService.name.trim() || newService.price <= 0) {
      showWebAlert('Error', 'Please provide service name and valid price');
      return;
    }

    const service: ServicePlan = {
      id: `service_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      name: newService.name.trim(),
      type: newService.type,
      price: newService.price,
      cost: newService.cost,
      features: {
        voiceMinutes: newService.voiceMinutes || undefined,
        smsMessages: newService.smsMessages || undefined,
        dataGB: newService.dataGB || undefined,
        validity: newService.validity
      },
      isActive: true,
      popularity: 50 + Math.random() * 30
    };

    setServices(prev => [...prev, service]);
    setShowCreateModal(false);
    setNewService({
      name: '',
      type: 'bundle',
      price: 0,
      cost: 0,
      voiceMinutes: 0,
      smsMessages: 0,
      dataGB: 0,
      validity: 30
    });

    dispatch({ 
      type: 'ADD_NOTIFICATION', 
      payload: { 
        type: 'info', 
        message: `New service "${service.name}" created successfully!`,
        id: Date.now().toString()
      }
    });
  };

  const filteredServices = selectedTab === 'overview' 
    ? services 
    : services.filter(service => service.type === selectedTab);

  const serviceStats = {
    totalServices: services.length,
    activeServices: services.filter(s => s.isActive).length,
    totalRevenuePotential: services.reduce((sum, s) => s.isActive ? sum + s.price : sum, 0),
    averageMargin: services.length > 0 ? services.reduce((sum, s) => sum + calculateProfitMargin(s.price, s.cost), 0) / services.length : 0
  };

  return (
        <View style={styles.container}>
      <LinearGradient colors={['#000000', '#8B0040', '#006400']} style={styles.background}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Services & Pricing</Text>
          <Text style={styles.subtitle}>Manage your service portfolio and pricing strategy</Text>
        </View>

        {/* Service Statistics */}
        <BlurView intensity={15} style={styles.statsGrid}>
          <View style={styles.statCard}>
            <MaterialIcons name="featured-play-list" size={16} color="#00FF00" />
            <Text style={styles.statValue}>{serviceStats.totalServices}</Text>
            <Text style={styles.statLabel}>Total Services</Text>
          </View>
          
          <View style={styles.statCard}>
            <MaterialIcons name="check-circle" size={16} color="#00FF00" />
            <Text style={styles.statValue}>{serviceStats.activeServices}</Text>
            <Text style={styles.statLabel}>Active Services</Text>
          </View>
          
          <View style={styles.statCard}>
            <MaterialIcons name="attach-money" size={16} color="#FFFF00" />
            <Text style={styles.statValue}>{formatCurrency(serviceStats.totalRevenuePotential)}</Text>
            <Text style={styles.statLabel}>Revenue Potential</Text>
          </View>
          
          <View style={styles.statCard}>
            <MaterialIcons name="trending-up" size={16} color="#00FFFF" />
            <Text style={styles.statValue}>{serviceStats.averageMargin.toFixed(1)}%</Text>
            <Text style={styles.statLabel}>Avg Profit Margin</Text>
          </View>
        </BlurView>

        {/* Tab Navigation */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.tabNavigation}>
          {['overview', 'voice', 'sms', 'data', 'bundle'].map(tab => (
            <TouchableOpacity
              key={tab}
              style={[styles.tab, selectedTab === tab && styles.activeTab]}
              onPress={() => setSelectedTab(tab as any)}
            >
              <MaterialIcons 
                name={getServiceTypeIcon(tab)} 
                size={10} 
                color={selectedTab === tab ? '#000000' : 'rgba(255,255,255,0.8)'} 
              />
              <Text style={[styles.tabText, selectedTab === tab && styles.activeTabText]}>
                {tab.charAt(0).toUpperCase() + tab.slice(1)}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {/* Create New Service Button */}
        <TouchableOpacity 
          style={styles.createButton}
          onPress={() => setShowCreateModal(true)}
        >
          <MaterialIcons name="add" size={14} color="white" />
          <Text style={styles.createButtonText}>Create New Service</Text>
        </TouchableOpacity>

        {/* Services List */}
        <ScrollView style={styles.servicesList} showsVerticalScrollIndicator={false}>
          {filteredServices.map(service => (
            <BlurView key={service.id} intensity={15} style={styles.serviceCard}>
              <View style={styles.serviceHeader}>
                <View style={styles.serviceInfo}>
                  <View style={styles.serviceTitleRow}>
                    <MaterialIcons 
                      name={getServiceTypeIcon(service.type)} 
                      size={14} 
                      color={getServiceTypeColor(service.type)} 
                    />
                    <Text style={styles.serviceName}>{service.name}</Text>
                    <TouchableOpacity
                      style={[styles.statusToggle, service.isActive ? styles.activeToggle : styles.inactiveToggle]}
                      onPress={() => toggleServiceStatus(service.id)}
                    >
                      <Text style={styles.statusText}>{service.isActive ? 'Active' : 'Inactive'}</Text>
                    </TouchableOpacity>
                  </View>
                  <Text style={styles.serviceFeatures}>{formatFeatures(service)}</Text>
                </View>
                
                <View style={styles.serviceActions}>
                  <TouchableOpacity 
                    style={styles.editButton}
                    onPress={() => editService(service)}
                  >
                    <MaterialIcons name="edit" size={10} color="white" />
                  </TouchableOpacity>
                  <TouchableOpacity 
                    style={styles.deleteButton}
                    onPress={() => deleteService(service.id)}
                  >
                    <MaterialIcons name="delete" size={10} color="white" />
                  </TouchableOpacity>
                </View>
              </View>

              <View style={styles.servicePricing}>
                <View style={styles.priceRow}>
                  <Text style={styles.priceLabel}>Customer Price:</Text>
                  {editingPrice === service.id ? (
                    <View style={styles.priceEdit}>
                      <TextInput
                        style={styles.priceInput}
                        value={editPrice}
                        onChangeText={setEditPrice}
                        keyboardType="numeric"
                        placeholder="Price"
                        placeholderTextColor="rgba(255,255,255,0.6)"
                      />
                      <TouchableOpacity 
                        style={styles.saveButton}
                        onPress={() => savePriceEdit(service.id)}
                      >
                        <MaterialIcons name="check" size={10} color="white" />
                      </TouchableOpacity>
                      <TouchableOpacity 
                        style={styles.cancelButton}
                        onPress={() => setEditingPrice(null)}
                      >
                        <MaterialIcons name="close" size={10} color="white" />
                      </TouchableOpacity>
                    </View>
                  ) : (
                    <TouchableOpacity 
                      style={styles.priceDisplay}
                      onPress={() => handlePriceEdit(service.id)}
                    >
                      <Text style={styles.priceValue}>{formatCurrency(service.price)}</Text>
                      <MaterialIcons name="edit" size={8} color="#00FF00" />
                    </TouchableOpacity>
                  )}
                </View>

                <View style={styles.profitAnalysis}>
                  <View style={styles.profitRow}>
                    <Text style={styles.profitLabel}>Cost:</Text>
                    <Text style={styles.costValue}>{formatCurrency(service.cost)}</Text>
                  </View>
                  <View style={styles.profitRow}>
                    <Text style={styles.profitLabel}>Profit:</Text>
                    <Text style={[styles.profitValue, { color: calculateProfit(service.price, service.cost) > 0 ? '#00FF00' : '#FF0000' }]}>
                      {formatCurrency(calculateProfit(service.price, service.cost))}
                    </Text>
                  </View>
                  <View style={styles.profitRow}>
                    <Text style={styles.profitLabel}>Margin:</Text>
                    <Text style={[styles.marginValue, { color: calculateProfitMargin(service.price, service.cost) > 20 ? '#00FF00' : '#FFFF00' }]}>
                      {calculateProfitMargin(service.price, service.cost).toFixed(1)}%
                    </Text>
                  </View>
                </View>

                <View style={styles.popularityContainer}>
                  <Text style={styles.popularityLabel}>Popularity:</Text>
                  <View style={styles.popularityBar}>
                    <View 
                      style={[
                        styles.popularityFill, 
                        { 
                          width: `${service.popularity}%`,
                          backgroundColor: service.popularity > 70 ? '#00FF00' : service.popularity > 40 ? '#FFFF00' : '#FF0000'
                        }
                      ]} 
                    />
                  </View>
                  <Text style={styles.popularityValue}>{service.popularity.toFixed(0)}%</Text>
                </View>
              </View>
            </BlurView>
          ))}
        </ScrollView>

        {/* Create/Edit Service Modal */}
        <Modal visible={showCreateModal || showEditModal} transparent animationType="fade">
          <View style={styles.modalOverlay}>
            <BlurView intensity={40} style={styles.modalContent}>
              <View style={styles.modalHeader}>
                <Text style={styles.modalTitle}>
                  {showEditModal ? 'Edit Service' : 'Create New Service'}
                </Text>
                <TouchableOpacity onPress={() => {
                  setShowCreateModal(false);
                  setShowEditModal(false);
                  setEditingService(null);
                }}>
                  <MaterialIcons name="close" size={14} color="white" />
                </TouchableOpacity>
              </View>

              <ScrollView style={styles.modalBody}>
                <View style={styles.inputContainer}>
                  <Text style={styles.inputLabel}>Service Name</Text>
                  <TextInput
                    style={styles.input}
                    value={newService.name}
                    onChangeText={(text) => setNewService(prev => ({ ...prev, name: text }))}
                    placeholder="Enter service name"
                    placeholderTextColor="rgba(255,255,255,0.6)"
                  />
                </View>

                <View style={styles.inputContainer}>
                  <Text style={styles.inputLabel}>Service Type</Text>
                  <View style={styles.typeButtons}>
                    {['voice', 'sms', 'data', 'bundle'].map(type => (
                      <TouchableOpacity
                        key={type}
                        style={[styles.typeButton, newService.type === type && styles.activeTypeButton]}
                        onPress={() => setNewService(prev => ({ ...prev, type: type as any }))}
                      >
                        <MaterialIcons name={getServiceTypeIcon(type)} size={10} color="white" />
                        <Text style={styles.typeButtonText}>{type.toUpperCase()}</Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                </View>

                <View style={styles.pricingContainer}>
                  <View style={styles.inputContainer}>
                    <Text style={styles.inputLabel}>Customer Price ($)</Text>
                    <TextInput
                      style={styles.input}
                      value={newService.price.toString()}
                      onChangeText={(text) => setNewService(prev => ({ ...prev, price: parseFloat(text) || 0 }))}
                      placeholder="0"
                      keyboardType="numeric"
                      placeholderTextColor="rgba(255,255,255,0.6)"
                    />
                  </View>

                  <View style={styles.inputContainer}>
                    <Text style={styles.inputLabel}>Operating Cost ($)</Text>
                    <TextInput
                      style={styles.input}
                      value={newService.cost.toString()}
                      onChangeText={(text) => setNewService(prev => ({ ...prev, cost: parseFloat(text) || 0 }))}
                      placeholder="0"
                      keyboardType="numeric"
                      placeholderTextColor="rgba(255,255,255,0.6)"
                    />
                  </View>
                </View>

                <View style={styles.featuresContainer}>
                  <Text style={styles.sectionTitle}>Service Features</Text>
                  
                  <View style={styles.inputContainer}>
                    <Text style={styles.inputLabel}>Voice Minutes (0 = None, 999999 = Unlimited)</Text>
                    <TextInput
                      style={styles.input}
                      value={newService.voiceMinutes.toString()}
                      onChangeText={(text) => setNewService(prev => ({ ...prev, voiceMinutes: parseInt(text) || 0 }))}
                      placeholder="0"
                      keyboardType="numeric"
                      placeholderTextColor="rgba(255,255,255,0.6)"
                    />
                  </View>

                  <View style={styles.inputContainer}>
                    <Text style={styles.inputLabel}>SMS Messages (0 = None, 999999 = Unlimited)</Text>
                    <TextInput
                      style={styles.input}
                      value={newService.smsMessages.toString()}
                      onChangeText={(text) => setNewService(prev => ({ ...prev, smsMessages: parseInt(text) || 0 }))}
                      placeholder="0"
                      keyboardType="numeric"
                      placeholderTextColor="rgba(255,255,255,0.6)"
                    />
                  </View>

                  <View style={styles.inputContainer}>
                    <Text style={styles.inputLabel}>Data (GB)</Text>
                    <TextInput
                      style={styles.input}
                      value={newService.dataGB.toString()}
                      onChangeText={(text) => setNewService(prev => ({ ...prev, dataGB: parseFloat(text) || 0 }))}
                      placeholder="0"
                      keyboardType="numeric"
                      placeholderTextColor="rgba(255,255,255,0.6)"
                    />
                  </View>

                  <View style={styles.inputContainer}>
                    <Text style={styles.inputLabel}>Validity (Days)</Text>
                    <TextInput
                      style={styles.input}
                      value={newService.validity.toString()}
                      onChangeText={(text) => setNewService(prev => ({ ...prev, validity: parseInt(text) || 30 }))}
                      placeholder="30"
                      keyboardType="numeric"
                      placeholderTextColor="rgba(255,255,255,0.6)"
                    />
                  </View>
                </View>
              </ScrollView>

              <View style={styles.modalButtons}>
                <TouchableOpacity
                  style={styles.modalCancelButton}
                  onPress={() => {
                    setShowCreateModal(false);
                    setShowEditModal(false);
                    setEditingService(null);
                  }}
                >
                  <Text style={styles.modalCancelText}>Cancel</Text>
                </TouchableOpacity>
                
                <TouchableOpacity
                  style={styles.modalConfirmButton}
                  onPress={showEditModal ? saveEditedService : createNewService}
                >
                  <Text style={styles.modalConfirmText}>
                    {showEditModal ? 'Update Service' : 'Create Service'}
                  </Text>
                </TouchableOpacity>
              </View>
            </BlurView>
          </View>
        </Modal>

        {/* Web Alert Modal */}
        {Platform.OS === 'web' && (
          <Modal visible={alertConfig.visible} transparent animationType="fade">
            <View style={styles.alertOverlay}>
              <View style={styles.alertBox}>
                <Text style={styles.alertTitle}>{alertConfig.title}</Text>
                <Text style={styles.alertMessage}>{alertConfig.message}</Text>
                <View style={styles.alertButtons}>
                  {alertConfig.onConfirm ? (
                    <>
                      <TouchableOpacity 
                        style={styles.alertCancelButton}
                        onPress={() => {
                          alertConfig.onCancel?.();
                          setAlertConfig(prev => ({ ...prev, visible: false }));
                        }}
                      >
                        <Text style={styles.alertButtonText}>Cancel</Text>
                      </TouchableOpacity>
                      <TouchableOpacity 
                        style={styles.alertConfirmButton}
                        onPress={() => {
                          alertConfig.onConfirm?.();
                          setAlertConfig(prev => ({ ...prev, visible: false }));
                        }}
                      >
                        <Text style={styles.alertButtonText}>Confirm</Text>
                      </TouchableOpacity>
                    </>
                  ) : (
                    <TouchableOpacity 
                      style={styles.alertOkButton}
                      onPress={() => setAlertConfig(prev => ({ ...prev, visible: false }))}
                    >
                      <Text style={styles.alertButtonText}>OK</Text>
                    </TouchableOpacity>
                  )}
                </View>
              </View>
            </View>
          </Modal>
        )}
      </LinearGradient>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
  },
  header: {
    padding: 10,
    alignItems: 'center',
  },
  title: {
    fontSize: 21,
    fontWeight: 'bold',
    color: 'white',
  },
  subtitle: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.8)',
    textAlign: 'center',
    marginTop: 3,
    fontWeight: 'bold',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 10,
    padding: 10,
    marginHorizontal: 10,
    marginBottom: 12,
  },
  statCard: {
    width: '48%',
    alignItems: 'center',
    marginBottom: 8,
  },
  statValue: {
    fontSize: 10,
    fontWeight: 'bold',
    color: 'white',
    marginTop: 4,
    textAlign: 'center',
  },
  statLabel: {
    fontSize: 6,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
    textAlign: 'center',
    marginTop: 2,
  },
  tabNavigation: {
    paddingHorizontal: 10,
    marginBottom: 12,
  },
  tab: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    paddingHorizontal: 10,
    paddingVertical: 5,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 12,
    marginRight: 5,
  },
  activeTab: {
    backgroundColor: '#00FF00',
  },
  tabText: {
    fontSize: 6,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
  },
  activeTabText: {
    color: '#000000',
  },
  createButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 5,
    backgroundColor: '#00FF00',
    marginHorizontal: 10,
    paddingVertical: 8,
    borderRadius: 5,
    marginBottom: 12,
  },
  createButtonText: {
    fontSize: 10,
    fontWeight: 'bold',
    color: '#000000',
  },
  servicesList: {
    flex: 1,
    paddingHorizontal: 10,
  },
  serviceCard: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 10,
    padding: 10,
    marginBottom: 8,
  },
  serviceHeader: {
    marginBottom: 8,
  },
  serviceInfo: {
    flex: 1,
  },
  serviceTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 4,
  },
  serviceName: {
    flex: 1,
    fontSize: 10,
    fontWeight: 'bold',
    color: 'white',
  },
  statusToggle: {
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 6,
  },
  activeToggle: {
    backgroundColor: 'rgba(0,255,0,0.3)',
  },
  inactiveToggle: {
    backgroundColor: 'rgba(255,0,0,0.3)',
  },
  statusText: {
    fontSize: 6,
    fontWeight: 'bold',
    color: 'white',
  },
  serviceFeatures: {
    fontSize: 8,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
  },
  serviceActions: {
    flexDirection: 'row',
    gap: 5,
    marginTop: 6,
  },
  editButton: {
    backgroundColor: '#00FFFF',
    padding: 5,
    borderRadius: 3,
  },
  deleteButton: {
    backgroundColor: '#FF0000',
    padding: 5,
    borderRadius: 3,
  },
  servicePricing: {
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.2)',
  },
  priceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 6,
  },
  priceLabel: {
    fontSize: 8,
    fontWeight: 'bold',
    color: 'white',
  },
  priceDisplay: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
  },
  priceValue: {
    fontSize: 9,
    fontWeight: 'bold',
    color: '#00FF00',
  },
  priceEdit: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
  },
  priceInput: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 2,
    paddingHorizontal: 5,
    paddingVertical: 2,
    fontSize: 8,
    color: 'white',
    fontWeight: 'bold',
    minWidth: 50,
  },
  saveButton: {
    backgroundColor: '#00FF00',
    padding: 2,
    borderRadius: 2,
  },
  cancelButton: {
    backgroundColor: '#FF0000',
    padding: 2,
    borderRadius: 2,
  },
  profitAnalysis: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 6,
  },
  profitRow: {
    alignItems: 'center',
  },
  profitLabel: {
    fontSize: 6,
    color: 'rgba(255,255,255,0.6)',
    fontWeight: 'bold',
  },
  costValue: {
    fontSize: 8,
    fontWeight: 'bold',
    color: '#FFFF00',
  },
  profitValue: {
    fontSize: 8,
    fontWeight: 'bold',
  },
  marginValue: {
    fontSize: 8,
    fontWeight: 'bold',
  },
  popularityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
  },
  popularityLabel: {
    fontSize: 6,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
  },
  popularityBar: {
    flex: 1,
    height: 3,
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 2,
    overflow: 'hidden',
  },
  popularityFill: {
    height: '100%',
    borderRadius: 2,
  },
  popularityValue: {
    fontSize: 6,
    color: 'white',
    fontWeight: 'bold',
    minWidth: 20,
    textAlign: 'right',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.8)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    width: '90%',
    maxWidth: 320,
    maxHeight: '80%',
    backgroundColor: 'rgba(0,0,0,0.95)',
    borderRadius: 12,
    overflow: 'hidden',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.2)',
  },
  modalTitle: {
    fontSize: 12,
    fontWeight: 'bold',
    color: 'white',
  },
  modalBody: {
    flex: 1,
    padding: 12,
  },
  inputContainer: {
    marginBottom: 10,
  },
  inputLabel: {
    fontSize: 8,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 3,
  },
  input: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 5,
    padding: 6,
    fontSize: 10,
    color: 'white',
    fontWeight: 'bold',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
  },
  typeButtons: {
    flexDirection: 'row',
    gap: 3,
  },
  typeButton: {
    flex: 1,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 5,
    padding: 6,
    alignItems: 'center',
    gap: 2,
  },
  activeTypeButton: {
    backgroundColor: '#00FF00',
  },
  typeButtonText: {
    fontSize: 5,
    fontWeight: 'bold',
    color: 'white',
  },
  pricingContainer: {
    flexDirection: 'row',
    gap: 6,
  },
  featuresContainer: {
    marginTop: 5,
  },
  sectionTitle: {
    fontSize: 10,
    fontWeight: 'bold',
    color: '#00FF00',
    marginBottom: 6,
  },
  modalButtons: {
    flexDirection: 'row',
    gap: 6,
    padding: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.2)',
  },
  modalCancelButton: {
    flex: 1,
    backgroundColor: 'rgba(255,255,255,0.2)',
    paddingVertical: 8,
    borderRadius: 5,
    alignItems: 'center',
  },
  modalCancelText: {
    fontSize: 10,
    fontWeight: 'bold',
    color: 'white',
  },
  modalConfirmButton: {
    flex: 1,
    backgroundColor: '#00FF00',
    paddingVertical: 8,
    borderRadius: 5,
    alignItems: 'center',
  },
  modalConfirmText: {
    fontSize: 10,
    fontWeight: 'bold',
    color: '#000000',
  },
  alertOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  alertBox: {
    backgroundColor: 'white',
    padding: 12,
    borderRadius: 5,
    minWidth: 200,
  },
  alertTitle: {
    fontSize: 12,
    fontWeight: 'bold',
    marginBottom: 6,
    color: 'black',
  },
  alertMessage: {
    fontSize: 10,
    marginBottom: 12,
    color: 'black',
  },
  alertButtons: {
    flexDirection: 'row',
    gap: 6,
  },
  alertCancelButton: {
    flex: 1,
    backgroundColor: '#ccc',
    padding: 6,
    borderRadius: 2,
    alignItems: 'center',
  },
  alertConfirmButton: {
    flex: 1,
    backgroundColor: '#007AFF',
    padding: 6,
    borderRadius: 2,
    alignItems: 'center',
  },
  alertOkButton: {
    backgroundColor: '#007AFF',
    padding: 6,
    borderRadius: 2,
    alignItems: 'center',
  },
  alertButtonText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 10,
  },
});