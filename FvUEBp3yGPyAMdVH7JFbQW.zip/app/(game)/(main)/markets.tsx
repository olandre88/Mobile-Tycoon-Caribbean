import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { BlurView } from 'expo-blur';
import { useGame } from '../../../hooks/useGame';

export default function MarketsTab() {
  const { state, dispatch } = useGame();
  const [selectedTab, setSelectedTab] = useState<'overview' | 'segments' | 'competition'>('overview');

  const customerSegments = {
    budget: { name: 'Budget Conscious', percentage: 30, arpu: 25, color: '#4CAF50' },
    premium: { name: 'Premium Users', percentage: 20, arpu: 85, color: '#2196F3' },
    business: { name: 'Business Customers', percentage: 15, arpu: 120, color: '#FF9800' },
    family: { name: 'Family Plans', percentage: 25, arpu: 60, color: '#9C27B0' },
    home: { name: 'Home Internet', percentage: 10, arpu: 45, color: '#F44336' }
  };

  const calculateMarketMetrics = () => {
    const totalCustomers = state.customers.length;
    const monthlyRevenue = totalCustomers > 0 
      ? state.customers.reduce((sum, customer) => sum + customer.arpu, 0) 
      : 0;
    const averageArpu = totalCustomers > 0 ? monthlyRevenue / totalCustomers : 0;
    const marketSize = state.selectedCountry?.population || 0;
    const marketShare = marketSize > 0 ? (totalCustomers / marketSize) * 100 : 0;
    const churnRate = 2.5; // Base 2.5% monthly churn

    return {
      totalCustomers,
      monthlyRevenue,
      averageArpu,
      marketShare,
      churnRate,
      marketSize
    };
  };

  const getSegmentData = () => {
    const segmentCounts = state.customers.reduce((acc, customer) => {
      acc[customer.segment] = (acc[customer.segment] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(customerSegments).map(([key, segment]) => ({
      ...segment,
      key,
      actual: segmentCounts[key] || 0,
      revenue: (segmentCounts[key] || 0) * segment.arpu
    }));
  };

  const metrics = calculateMarketMetrics();
  const segmentData = getSegmentData();

  const formatCurrency = (amount: number) => {
    if (amount >= 1000000) return `$${(amount / 1000000).toFixed(1)}M`;
    if (amount >= 1000) return `$${(amount / 1000).toFixed(0)}K`;
    return `$${amount.toLocaleString()}`;
  };

  if (!state.selectedCountry) {
    return (
      <View style={styles.container}>
        <LinearGradient colors={['#000000', '#00FF7F', '#FF0000']} style={styles.background}>
          <View style={styles.emptyState}>
            <MaterialIcons name="public" size={60} color="#00FF7F" />
            <Text style={styles.emptyTitle}>Select a Market</Text>
            <Text style={styles.emptySubtitle}>
              Choose a country from the Countries tab to view market analytics
            </Text>
          </View>
        </LinearGradient>
      </View>
    );
  }

  return (
        <View style={styles.container}>
      <LinearGradient colors={['#000000', '#8B0040', '#006400']} style={styles.background}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Markets & Customers</Text>
          <Text style={styles.subtitle}>{state.selectedCountry.flag} {state.selectedCountry.name}</Text>
        </View>

        {/* Tab Navigation */}
        <View style={styles.tabNavigation}>
          <TouchableOpacity
            style={[styles.tab, selectedTab === 'overview' && styles.activeTab]}
            onPress={() => setSelectedTab('overview')}
          >
            <Text style={[styles.tabText, selectedTab === 'overview' && styles.activeTabText]}>
              Overview
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.tab, selectedTab === 'segments' && styles.activeTab]}
            onPress={() => setSelectedTab('segments')}
          >
            <Text style={[styles.tabText, selectedTab === 'segments' && styles.activeTabText]}>
              Segments
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.tab, selectedTab === 'competition' && styles.activeTab]}
            onPress={() => setSelectedTab('competition')}
          >
            <Text style={[styles.tabText, selectedTab === 'competition' && styles.activeTabText]}>
              Competition
            </Text>
          </TouchableOpacity>
        </View>

        <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
          {selectedTab === 'overview' && (
            <>
              {/* Key Metrics */}
              <BlurView intensity={15} style={styles.metricsGrid}>
                <View style={styles.metricCard}>
                  <MaterialIcons name="people" size={18} color="#00FF7F" />
                  <Text style={styles.metricValue}>{metrics.totalCustomers.toLocaleString()}</Text>
                  <Text style={styles.metricLabel}>Total Customers</Text>
                </View>
                <View style={styles.metricCard}>
                  <MaterialIcons name="attach-money" size={18} color="#4CAF50" />
                  <Text style={styles.metricValue}>{formatCurrency(metrics.monthlyRevenue)}</Text>
                  <Text style={styles.metricLabel}>Monthly Revenue</Text>
                </View>
                <View style={styles.metricCard}>
                  <MaterialIcons name="trending-up" size={18} color="#FF9800" />
                  <Text style={styles.metricValue}>{formatCurrency(metrics.averageArpu)}</Text>
                  <Text style={styles.metricLabel}>Average ARPU</Text>
                </View>
                <View style={styles.metricCard}>
                  <MaterialIcons name="pie-chart" size={18} color="#2196F3" />
                  <Text style={styles.metricValue}>{metrics.marketShare.toFixed(2)}%</Text>
                  <Text style={styles.metricLabel}>Market Share</Text>
                </View>
              </BlurView>

              {/* Market Overview */}
              <BlurView intensity={15} style={styles.section}>
                <View style={styles.sectionHeader}>
                  <MaterialIcons name="analytics" size={16} color="#00FF7F" />
                  <Text style={styles.sectionTitle}>Market Overview</Text>
                </View>
                
                <View style={styles.overviewRow}>
                  <Text style={styles.overviewLabel}>Market Size:</Text>
                  <Text style={styles.overviewValue}>{metrics.marketSize.toLocaleString()} people</Text>
                </View>
                <View style={styles.overviewRow}>
                  <Text style={styles.overviewLabel}>Penetration:</Text>
                  <Text style={styles.overviewValue}>
                    {metrics.totalCustomers.toLocaleString()} / {metrics.marketSize.toLocaleString()}
                  </Text>
                </View>
                <View style={styles.overviewRow}>
                  <Text style={styles.overviewLabel}>Churn Rate:</Text>
                  <Text style={styles.overviewValue}>{metrics.churnRate}% monthly</Text>
                </View>
                <View style={styles.overviewRow}>
                  <Text style={styles.overviewLabel}>Growth Potential:</Text>
                  <Text style={styles.overviewValue}>
                    {((100 - metrics.marketShare) * metrics.marketSize / 100).toLocaleString()} customers
                  </Text>
                </View>
              </BlurView>

              {/* Network Quality */}
              <BlurView intensity={15} style={styles.section}>
                <View style={styles.sectionHeader}>
                  <MaterialIcons name="network-check" size={16} color="#00FF7F" />
                  <Text style={styles.sectionTitle}>Network Quality</Text>
                </View>
                
                <View style={styles.qualityMetric}>
                  <Text style={styles.qualityLabel}>Coverage</Text>
                  <View style={styles.progressBar}>
                    <View style={[styles.progressFill, { width: '75%', backgroundColor: '#4CAF50' }]} />
                  </View>
                  <Text style={styles.qualityValue}>75%</Text>
                </View>
                
                <View style={styles.qualityMetric}>
                  <Text style={styles.qualityLabel}>Signal Strength</Text>
                  <View style={styles.progressBar}>
                    <View style={[styles.progressFill, { width: '82%', backgroundColor: '#2196F3' }]} />
                  </View>
                  <Text style={styles.qualityValue}>82%</Text>
                </View>
                
                <View style={styles.qualityMetric}>
                  <Text style={styles.qualityLabel}>Data Speed</Text>
                  <View style={styles.progressBar}>
                    <View style={[styles.progressFill, { width: '68%', backgroundColor: '#FF9800' }]} />
                  </View>
                  <Text style={styles.qualityValue}>34 Mbps</Text>
                </View>
              </BlurView>
            </>
          )}

          {selectedTab === 'segments' && (
            <BlurView intensity={15} style={styles.section}>
              <View style={styles.sectionHeader}>
                <MaterialIcons name="group" size={16} color="#00FF7F" />
                <Text style={styles.sectionTitle}>Customer Segments</Text>
              </View>
              
              {segmentData.map((segment) => (
                <View key={segment.key} style={styles.segmentCard}>
                  <View style={styles.segmentHeader}>
                    <View style={[styles.segmentIndicator, { backgroundColor: segment.color }]} />
                    <Text style={styles.segmentName}>{segment.name}</Text>
                    <Text style={styles.segmentCount}>({segment.actual.toLocaleString()})</Text>
                  </View>
                  
                  <View style={styles.segmentMetrics}>
                    <View style={styles.segmentMetric}>
                      <Text style={styles.segmentMetricLabel}>Target %</Text>
                      <Text style={styles.segmentMetricValue}>{segment.percentage}%</Text>
                    </View>
                    <View style={styles.segmentMetric}>
                      <Text style={styles.segmentMetricLabel}>ARPU</Text>
                      <Text style={styles.segmentMetricValue}>{formatCurrency(segment.arpu)}</Text>
                    </View>
                    <View style={styles.segmentMetric}>
                      <Text style={styles.segmentMetricLabel}>Revenue</Text>
                      <Text style={styles.segmentMetricValue}>{formatCurrency(segment.revenue)}</Text>
                    </View>
                  </View>
                  
                  <View style={styles.progressBar}>
                    <View 
                      style={[
                        styles.progressFill, 
                        { 
                          width: `${Math.min(100, (segment.actual / (metrics.totalCustomers || 1)) * 100)}%`,
                          backgroundColor: segment.color 
                        }
                      ]} 
                    />
                  </View>
                </View>
              ))}
            </BlurView>
          )}

          {selectedTab === 'competition' && (
            <BlurView intensity={15} style={styles.section}>
              <View style={styles.sectionHeader}>
                <MaterialIcons name="business" size={16} color="#00FF7F" />
                <Text style={styles.sectionTitle}>Competitive Analysis</Text>
              </View>
              
              <View style={styles.competitorCard}>
                <View style={styles.competitorHeader}>
                  <Text style={styles.competitorName}>Your Company</Text>
                  <Text style={styles.competitorShare}>{metrics.marketShare.toFixed(1)}%</Text>
                </View>
                <View style={styles.progressBar}>
                  <View style={[styles.progressFill, { width: `${metrics.marketShare}%`, backgroundColor: '#00FF7F' }]} />
                </View>
              </View>
              
              {/* Simulated competitors */}
              {Array.from({ length: Math.min(5, state.selectedCountry.competitors) }).map((_, index) => {
                const competitorShare = Math.random() * (30 - metrics.marketShare) + 5;
                const competitorNames = ['TeleCarib', 'IslandNet', 'CaribConnect', 'TropicTel', 'AquaWireless'];
                
                return (
                  <View key={index} style={styles.competitorCard}>
                    <View style={styles.competitorHeader}>
                      <Text style={styles.competitorName}>{competitorNames[index]}</Text>
                      <Text style={styles.competitorShare}>{competitorShare.toFixed(1)}%</Text>
                    </View>
                    <View style={styles.progressBar}>
                      <View style={[styles.progressFill, { width: `${competitorShare}%`, backgroundColor: '#FF5722' }]} />
                    </View>
                  </View>
                );
              })}
              
              <View style={styles.competitorInsights}>
                <Text style={styles.insightsTitle}>Market Insights</Text>
                <Text style={styles.insightsText}>
                  • Market has {state.selectedCountry.competitors} active competitors
                </Text>
                <Text style={styles.insightsText}>
                  • Your market share: {metrics.marketShare > 10 ? 'Strong position' : 'Growth opportunity'}
                </Text>
                <Text style={styles.insightsText}>
                  • Competition level: {state.selectedCountry.competitors > 5 ? 'High' : 'Moderate'}
                </Text>
              </View>
            </BlurView>
          )}
        </ScrollView>
      </LinearGradient>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
  },
  header: {
    padding: 12,
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
  },
  subtitle: {
    fontSize: 15,
    color: 'rgba(255,255,255,0.8)',
    textAlign: 'center',
    marginTop: 3,
    fontWeight: 'bold',
  },
  tabNavigation: {
    flexDirection: 'row',
    paddingHorizontal: 12,
    marginBottom: 12,
  },
  tab: {
    flex: 1,
    paddingVertical: 8,
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.1)',
    marginHorizontal: 2,
    borderRadius: 6,
  },
  activeTab: {
    backgroundColor: '#00FF7F',
  },
  tabText: {
    fontSize: 10,
    fontWeight: 'bold',
    color: 'rgba(255,255,255,0.8)',
  },
  activeTabText: {
    color: '#000000',
  },
  content: {
    flex: 1,
    paddingHorizontal: 12,
  },
  metricsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 12,
    padding: 12,
    marginBottom: 16,
  },
  metricCard: {
    width: '48%',
    alignItems: 'center',
    marginBottom: 12,
  },
  metricValue: {
    fontSize: 14,
    fontWeight: 'bold',
    color: 'white',
    marginTop: 6,
  },
  metricLabel: {
    fontSize: 8,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
    textAlign: 'center',
    marginTop: 3,
  },
  section: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 12,
    padding: 12,
    marginBottom: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
    gap: 6,
  },
  sectionTitle: {
    fontSize: 12,
    fontWeight: 'bold',
    color: 'white',
  },
  overviewRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 6,
  },
  overviewLabel: {
    fontSize: 10,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
  },
  overviewValue: {
    fontSize: 10,
    fontWeight: 'bold',
    color: 'white',
  },
  qualityMetric: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
    gap: 8,
  },
  qualityLabel: {
    flex: 1,
    fontSize: 10,
    fontWeight: 'bold',
    color: 'white',
  },
  progressBar: {
    flex: 2,
    height: 6,
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 3,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    borderRadius: 3,
  },
  qualityValue: {
    fontSize: 8,
    fontWeight: 'bold',
    color: 'white',
    minWidth: 40,
    textAlign: 'right',
  },
  segmentCard: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 8,
    padding: 8,
    marginBottom: 8,
  },
  segmentHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
    gap: 6,
  },
  segmentIndicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  segmentName: {
    flex: 1,
    fontSize: 10,
    fontWeight: 'bold',
    color: 'white',
  },
  segmentCount: {
    fontSize: 8,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
  },
  segmentMetrics: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 6,
  },
  segmentMetric: {
    alignItems: 'center',
  },
  segmentMetricLabel: {
    fontSize: 7,
    color: 'rgba(255,255,255,0.6)',
    fontWeight: 'bold',
  },
  segmentMetricValue: {
    fontSize: 8,
    fontWeight: 'bold',
    color: 'white',
    marginTop: 1,
  },
  competitorCard: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 8,
    padding: 8,
    marginBottom: 8,
  },
  competitorHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 6,
  },
  competitorName: {
    fontSize: 10,
    fontWeight: 'bold',
    color: 'white',
  },
  competitorShare: {
    fontSize: 10,
    fontWeight: 'bold',
    color: '#00FF7F',
  },
  competitorInsights: {
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.2)',
  },
  insightsTitle: {
    fontSize: 11,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 6,
  },
  insightsText: {
    fontSize: 8,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
    marginBottom: 3,
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 32,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
    marginTop: 16,
  },
  emptySubtitle: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.8)',
    textAlign: 'center',
    marginTop: 8,
    lineHeight: 18,
    fontWeight: 'bold',
  },
});