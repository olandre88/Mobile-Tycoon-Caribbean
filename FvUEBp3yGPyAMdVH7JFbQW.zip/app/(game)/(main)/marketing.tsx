import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, TextInput, Modal, Platform, Alert } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { MaterialIcons } from '@expo/vector-icons';
import { useGame } from '../../../hooks/useGame';

interface MarketingCampaign {
  id: string;
  name: string;
  type: 'tv' | 'radio' | 'digital' | 'outdoor' | 'print';
  budget: number;
  duration: number;
  effectiveness: number;
  status: 'active' | 'paused' | 'ended';
  startDate: Date;
  endDate: Date;
  targetSegment: string;
  reach: number;
  conversions: number;
}

interface Promotion {
  id: string;
  name: string;
  type: 'discount' | 'bonus' | 'loyalty' | 'referral' | 'bundle';
  description: string;
  satisfactionImpact: number; // -5 to +5
  duration: number; // days
  cost: number;
  isActive: boolean;
  startDate: Date;
  endDate: Date;
  effectivenessRating: number;
}

const campaignTypes = [
  { id: 'tv', name: 'TV Advertising', icon: 'tv', color: '#FF6B6B', cost: 50000, effectiveness: 85 },
  { id: 'radio', name: 'Radio', icon: 'radio', color: '#4ECDC4', cost: 25000, effectiveness: 70 },
  { id: 'digital', name: 'Digital/Social', icon: 'language', color: '#45B7D1', cost: 30000, effectiveness: 90 },
  { id: 'outdoor', name: 'Billboards', icon: 'place', color: '#96CEB4', cost: 40000, effectiveness: 60 },
  { id: 'print', name: 'Print Media', icon: 'article', color: '#FECA57', cost: 20000, effectiveness: 50 }
];

const promotionTemplates: Omit<Promotion, 'id' | 'isActive' | 'startDate' | 'endDate'>[] = [
  {
    name: '50% Off First Month',
    type: 'discount',
    description: 'New customers get 50% discount on first month service',
    satisfactionImpact: 4,
    duration: 30,
    cost: 75000,
    effectivenessRating: 88
  },
  {
    name: 'Double Data Bonus',
    type: 'bonus',
    description: 'All customers receive double data allowance this month',
    satisfactionImpact: 5,
    duration: 30,
    cost: 45000,
    effectivenessRating: 92
  },
  {
    name: 'Loyalty Rewards Program',
    type: 'loyalty',
    description: 'Long-term customers get exclusive benefits and priority support',
    satisfactionImpact: 3,
    duration: 90,
    cost: 25000,
    effectivenessRating: 75
  },
  {
    name: 'Refer a Friend $50',
    type: 'referral',
    description: 'Customers earn $50 credit for each successful referral',
    satisfactionImpact: 2,
    duration: 60,
    cost: 60000,
    effectivenessRating: 82
  },
  {
    name: 'Family Bundle Deal',
    type: 'bundle',
    description: 'Family plans with 4+ lines get 20% discount permanently',
    satisfactionImpact: 4,
    duration: 365,
    cost: 35000,
    effectivenessRating: 86
  },
  {
    name: 'Free Device Upgrade',
    type: 'bonus',
    description: 'Premium customers eligible for free device upgrade',
    satisfactionImpact: 5,
    duration: 45,
    cost: 120000,
    effectivenessRating: 95
  }
];

export default function MarketingTab() {
  const { state, dispatch } = useGame();
  const [selectedTab, setSelectedTab] = useState<'campaigns' | 'promotions'>('campaigns');
  const [campaigns, setCampaigns] = useState<MarketingCampaign[]>([]);
  const [promotions, setPromotions] = useState<Promotion[]>([]);
  const [showCampaignModal, setShowCampaignModal] = useState(false);
  const [showPromotionModal, setShowPromotionModal] = useState(false);
  const [selectedCampaignType, setSelectedCampaignType] = useState<string>('');
  const [campaignName, setCampaignName] = useState('');
  const [campaignBudget, setCampaignBudget] = useState('');
  const [campaignDuration, setCampaignDuration] = useState('30');

  // Custom promotion states
  const [customPromotion, setCustomPromotion] = useState({
    name: '',
    description: '',
    satisfactionImpact: 0,
    duration: 30,
    cost: 0
  });

  // Web alert state
  const [alertConfig, setAlertConfig] = useState<{
    visible: boolean;
    title: string;
    message: string;
    onOk?: () => void;
  }>({ visible: false, title: '', message: '' });

  const showWebAlert = (title: string, message: string, onOk?: () => void) => {
    if (Platform.OS === 'web') {
      setAlertConfig({ visible: true, title, message, onOk });
    } else {
      Alert.alert(title, message, onOk ? [{ text: 'OK', onPress: onOk }] : undefined);
    }
  };

  // Update customer satisfaction based on active promotions
  useEffect(() => {
    const activePromotions = promotions.filter(promo => 
      promo.isActive && new Date() <= promo.endDate
    );
    
    if (activePromotions.length > 0) {
      const totalSatisfactionBoost = activePromotions.reduce((sum, promo) => 
        sum + promo.satisfactionImpact, 0
      );
      
      // Apply satisfaction change (with some randomness)
      const finalImpact = totalSatisfactionBoost + (Math.random() - 0.5) * 2;
      
      if (Math.abs(finalImpact) > 0.5) {
        dispatch({ 
          type: 'ADD_NOTIFICATION', 
          payload: { 
            type: finalImpact > 0 ? 'info' : 'warning', 
            message: `📈 Promotions ${finalImpact > 0 ? 'boosted' : 'reduced'} customer satisfaction by ${Math.abs(finalImpact).toFixed(1)}%`,
            id: Date.now().toString()
          }
        });
      }
    }
  }, [promotions.filter(p => p.isActive).length]);

  const handleCreateCampaign = () => {
    if (!campaignName.trim() || !selectedCampaignType || !campaignBudget) {
      showWebAlert('Error', 'Please fill all campaign details');
      return;
    }

    const budget = parseFloat(campaignBudget);
    if (state.company.capital < budget) {
      showWebAlert('Insufficient Capital', `Need $${budget.toLocaleString()} for this campaign. Available: $${state.company.capital.toLocaleString()}`);
      return;
    }

    const campaignType = campaignTypes.find(type => type.id === selectedCampaignType);
    if (!campaignType) return;

    const newCampaign: MarketingCampaign = {
      id: `campaign_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      name: campaignName.trim(),
      type: selectedCampaignType as any,
      budget,
      duration: parseInt(campaignDuration) || 30,
      effectiveness: campaignType.effectiveness + (Math.random() - 0.5) * 20,
      status: 'active',
      startDate: new Date(),
      endDate: new Date(Date.now() + (parseInt(campaignDuration) || 30) * 24 * 60 * 60 * 1000),
      targetSegment: 'all',
      reach: Math.floor(budget / 10 + Math.random() * 1000),
      conversions: 0
    };

    setCampaigns(prev => [...prev, newCampaign]);
    dispatch({ type: 'SPEND_CAPITAL', payload: budget });
    
    dispatch({ 
      type: 'ADD_NOTIFICATION', 
      payload: { 
        type: 'info', 
        message: `📺 Campaign "${campaignName}" launched with $${budget.toLocaleString()} budget!`,
        id: Date.now().toString()
      }
    });

    setShowCampaignModal(false);
    resetCampaignForm();
  };

  const handleCreatePromotion = (template: typeof promotionTemplates[0]) => {
    if (state.company.capital < template.cost) {
      showWebAlert('Insufficient Capital', `Need $${template.cost.toLocaleString()} for this promotion. Available: $${state.company.capital.toLocaleString()}`);
      return;
    }

    const newPromotion: Promotion = {
      ...template,
      id: `promotion_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      isActive: true,
      startDate: new Date(),
      endDate: new Date(Date.now() + template.duration * 24 * 60 * 60 * 1000)
    };

    setPromotions(prev => [...prev, newPromotion]);
    dispatch({ type: 'SPEND_CAPITAL', payload: template.cost });
    
    dispatch({ 
      type: 'ADD_NOTIFICATION', 
      payload: { 
        type: 'info', 
        message: `🎁 Promotion "${template.name}" activated! Satisfaction impact: ${template.satisfactionImpact > 0 ? '+' : ''}${template.satisfactionImpact}%`,
        id: Date.now().toString()
      }
    });
  };

  const handleCreateCustomPromotion = () => {
    if (!customPromotion.name.trim() || !customPromotion.description.trim()) {
      showWebAlert('Error', 'Please provide promotion name and description');
      return;
    }

    if (state.company.capital < customPromotion.cost) {
      showWebAlert('Insufficient Capital', `Need $${customPromotion.cost.toLocaleString()} for this promotion`);
      return;
    }

    const newPromotion: Promotion = {
      id: `custom_promotion_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      name: customPromotion.name.trim(),
      type: 'bonus',
      description: customPromotion.description.trim(),
      satisfactionImpact: Math.max(-5, Math.min(5, customPromotion.satisfactionImpact)),
      duration: customPromotion.duration,
      cost: customPromotion.cost,
      isActive: true,
      startDate: new Date(),
      endDate: new Date(Date.now() + customPromotion.duration * 24 * 60 * 60 * 1000),
      effectivenessRating: 70 + Math.random() * 25
    };

    setPromotions(prev => [...prev, newPromotion]);
    dispatch({ type: 'SPEND_CAPITAL', payload: customPromotion.cost });
    
    dispatch({ 
      type: 'ADD_NOTIFICATION', 
      payload: { 
        type: 'info', 
        message: `🎨 Custom promotion "${newPromotion.name}" created! Impact: ${newPromotion.satisfactionImpact > 0 ? '+' : ''}${newPromotion.satisfactionImpact}%`,
        id: Date.now().toString()
      }
    });

    setCustomPromotion({
      name: '',
      description: '',
      satisfactionImpact: 0,
      duration: 30,
      cost: 0
    });
    setShowPromotionModal(false);
  };

  const pauseCampaign = (campaignId: string) => {
    setCampaigns(prev => prev.map(campaign =>
      campaign.id === campaignId
        ? { ...campaign, status: campaign.status === 'active' ? 'paused' : 'active' }
        : campaign
    ));
  };

  const endPromotion = (promotionId: string) => {
    setPromotions(prev => prev.map(promotion =>
      promotion.id === promotionId
        ? { ...promotion, isActive: false, endDate: new Date() }
        : promotion
    ));
  };

  const resetCampaignForm = () => {
    setCampaignName('');
    setCampaignBudget('');
    setCampaignDuration('30');
    setSelectedCampaignType('');
  };

  const formatCurrency = (amount: number) => {
    return `$${amount.toLocaleString()}`;
  };

  const getActiveCampaignCount = () => {
    return campaigns.filter(c => c.status === 'active').length;
  };

  const getActivePromotionCount = () => {
    return promotions.filter(p => p.isActive && new Date() <= p.endDate).length;
  };

  const getTotalMarketingSpend = () => {
    const campaignSpend = campaigns.reduce((sum, c) => sum + c.budget, 0);
    const promotionSpend = promotions.reduce((sum, p) => sum + p.cost, 0);
    return campaignSpend + promotionSpend;
  };

  return (
        <View style={styles.container}>
      <LinearGradient colors={['#000000', '#8B0040', '#006400']} style={styles.background}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Marketing & Promotions</Text>
          <Text style={styles.subtitle}>
            Active Campaigns: {getActiveCampaignCount()} • Active Promotions: {getActivePromotionCount()}
          </Text>
          <Text style={styles.spendInfo}>
            Total Spend: {formatCurrency(getTotalMarketingSpend())}
          </Text>
        </View>

        {/* Tab Navigation */}
        <View style={styles.tabNavigation}>
          <TouchableOpacity
            style={[styles.tab, selectedTab === 'campaigns' && styles.activeTab]}
            onPress={() => setSelectedTab('campaigns')}
          >
            <MaterialIcons name="campaign" size={16} color={selectedTab === 'campaigns' ? '#000000' : '#00FFFF'} />
            <Text style={[styles.tabText, selectedTab === 'campaigns' && styles.activeTabText]}>
              Campaigns
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.tab, selectedTab === 'promotions' && styles.activeTab]}
            onPress={() => setSelectedTab('promotions')}
          >
            <MaterialIcons name="local-offer" size={16} color={selectedTab === 'promotions' ? '#000000' : '#00FF7F'} />
            <Text style={[styles.tabText, selectedTab === 'promotions' && styles.activeTabText]}>
              Promotions
            </Text>
          </TouchableOpacity>
        </View>

        {selectedTab === 'campaigns' ? (
          <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
            {/* Create Campaign Button */}
            <TouchableOpacity 
              style={styles.createButton}
              onPress={() => setShowCampaignModal(true)}
            >
              <MaterialIcons name="add" size={18} color="white" />
              <Text style={styles.createButtonText}>Launch New Campaign</Text>
            </TouchableOpacity>

            {/* Campaigns List */}
            {campaigns.length === 0 ? (
              <BlurView intensity={20} style={styles.emptyState}>
                <MaterialIcons name="campaign" size={48} color="rgba(255,255,255,0.3)" />
                <Text style={styles.emptyTitle}>No Campaigns Yet</Text>
                <Text style={styles.emptySubtitle}>Launch your first marketing campaign to attract customers</Text>
              </BlurView>
            ) : (
              campaigns.map(campaign => (
                <BlurView key={campaign.id} intensity={20} style={[styles.campaignCard, { borderColor: campaignTypes.find(t => t.id === campaign.type)?.color || '#00FFFF' }]}>
                  <View style={styles.campaignHeader}>
                    <View style={styles.campaignInfo}>
                      <Text style={styles.campaignName}>{campaign.name}</Text>
                      <Text style={styles.campaignType}>
                        {campaignTypes.find(t => t.id === campaign.type)?.name || campaign.type}
                      </Text>
                      <Text style={styles.campaignDates}>
                        {campaign.startDate.toLocaleDateString()} - {campaign.endDate.toLocaleDateString()}
                      </Text>
                    </View>
                    <View style={styles.campaignActions}>
                      <View style={[
                        styles.statusBadge,
                        campaign.status === 'active' ? styles.activeStatus :
                        campaign.status === 'paused' ? styles.pausedStatus : styles.endedStatus
                      ]}>
                        <Text style={styles.statusText}>{campaign.status.toUpperCase()}</Text>
                      </View>
                      {campaign.status !== 'ended' && (
                        <TouchableOpacity
                          style={styles.pauseButton}
                          onPress={() => pauseCampaign(campaign.id)}
                        >
                          <MaterialIcons 
                            name={campaign.status === 'active' ? 'pause' : 'play-arrow'} 
                            size={16} 
                            color="white" 
                          />
                        </TouchableOpacity>
                      )}
                    </View>
                  </View>

                  <View style={styles.campaignStats}>
                    <View style={styles.statItem}>
                      <Text style={styles.statLabel}>Budget</Text>
                      <Text style={styles.statValue}>{formatCurrency(campaign.budget)}</Text>
                    </View>
                    <View style={styles.statItem}>
                      <Text style={styles.statLabel}>Reach</Text>
                      <Text style={styles.statValue}>{campaign.reach.toLocaleString()}</Text>
                    </View>
                    <View style={styles.statItem}>
                      <Text style={styles.statLabel}>Effectiveness</Text>
                      <Text style={styles.statValue}>{campaign.effectiveness.toFixed(0)}%</Text>
                    </View>
                    <View style={styles.statItem}>
                      <Text style={styles.statLabel}>Conversions</Text>
                      <Text style={styles.statValue}>{campaign.conversions}</Text>
                    </View>
                  </View>
                </BlurView>
              ))
            )}
          </ScrollView>
        ) : (
          <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
            {/* Create Custom Promotion Button */}
            <TouchableOpacity 
              style={styles.createButton}
              onPress={() => setShowPromotionModal(true)}
            >
              <MaterialIcons name="add" size={18} color="white" />
              <Text style={styles.createButtonText}>Create Custom Promotion</Text>
            </TouchableOpacity>

            {/* Promotion Templates */}
            <Text style={styles.sectionTitle}>Promotion Templates</Text>
            {promotionTemplates.map((template, index) => (
              <BlurView key={index} intensity={20} style={styles.promotionTemplate}>
                <View style={styles.templateHeader}>
                  <View style={styles.templateInfo}>
                    <Text style={styles.templateName}>{template.name}</Text>
                    <Text style={styles.templateDescription}>{template.description}</Text>
                    <View style={styles.templateDetails}>
                      <Text style={styles.templateDetail}>
                        Impact: <Text style={[
                          styles.impactValue,
                          { color: template.satisfactionImpact > 0 ? '#00FF7F' : '#FF4444' }
                        ]}>
                          {template.satisfactionImpact > 0 ? '+' : ''}{template.satisfactionImpact}% satisfaction
                        </Text>
                      </Text>
                      <Text style={styles.templateDetail}>Duration: {template.duration} days</Text>
                      <Text style={styles.templateDetail}>Effectiveness: {template.effectivenessRating}%</Text>
                    </View>
                  </View>
                  <View style={styles.templateActions}>
                    <Text style={styles.templateCost}>{formatCurrency(template.cost)}</Text>
                    <TouchableOpacity
                      style={styles.activateButton}
                      onPress={() => handleCreatePromotion(template)}
                    >
                      <Text style={styles.activateButtonText}>Activate</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </BlurView>
            ))}

            {/* Active Promotions */}
            {promotions.filter(p => p.isActive && new Date() <= p.endDate).length > 0 && (
              <>
                <Text style={styles.sectionTitle}>Active Promotions</Text>
                {promotions
                  .filter(p => p.isActive && new Date() <= p.endDate)
                  .map(promotion => (
                    <BlurView key={promotion.id} intensity={20} style={styles.activePromotion}>
                      <View style={styles.promotionHeader}>
                        <View style={styles.promotionInfo}>
                          <Text style={styles.promotionName}>{promotion.name}</Text>
                          <Text style={styles.promotionDescription}>{promotion.description}</Text>
                          <Text style={styles.promotionEnd}>
                            Ends: {promotion.endDate.toLocaleDateString()}
                          </Text>
                        </View>
                        <View style={styles.promotionActions}>
                          <View style={[
                            styles.impactBadge,
                            { backgroundColor: promotion.satisfactionImpact > 0 ? '#00AA00' : '#AA0000' }
                          ]}>
                            <Text style={styles.impactText}>
                              {promotion.satisfactionImpact > 0 ? '+' : ''}{promotion.satisfactionImpact}%
                            </Text>
                          </View>
                          <TouchableOpacity
                            style={styles.endButton}
                            onPress={() => endPromotion(promotion.id)}
                          >
                            <MaterialIcons name="stop" size={16} color="white" />
                          </TouchableOpacity>
                        </View>
                      </View>
                    </BlurView>
                  ))}
              </>
            )}
          </ScrollView>
        )}

        {/* Campaign Creation Modal */}
        <Modal visible={showCampaignModal} transparent animationType="fade">
          <View style={styles.modalOverlay}>
            <BlurView intensity={40} style={styles.modalContent}>
              <View style={styles.modalHeader}>
                <Text style={styles.modalTitle}>Launch Campaign</Text>
                <TouchableOpacity onPress={() => {
                  setShowCampaignModal(false);
                  resetCampaignForm();
                }}>
                  <MaterialIcons name="close" size={20} color="white" />
                </TouchableOpacity>
              </View>

              <ScrollView style={styles.modalBody}>
                <Text style={styles.inputLabel}>Campaign Name</Text>
                <TextInput
                  style={styles.input}
                  value={campaignName}
                  onChangeText={setCampaignName}
                  placeholder="Enter campaign name"
                  placeholderTextColor="rgba(255,255,255,0.6)"
                />

                <Text style={styles.inputLabel}>Campaign Type</Text>
                <View style={styles.typeGrid}>
                  {campaignTypes.map(type => (
                    <TouchableOpacity
                      key={type.id}
                      style={[
                        styles.typeButton,
                        selectedCampaignType === type.id && styles.typeButtonActive,
                        { borderColor: type.color }
                      ]}
                      onPress={() => setSelectedCampaignType(type.id)}
                    >
                      <MaterialIcons name={type.icon as any} size={20} color={type.color} />
                      <Text style={[styles.typeName, { color: type.color }]}>{type.name}</Text>
                      <Text style={styles.typeCost}>{formatCurrency(type.cost)}</Text>
                      <Text style={styles.typeEffectiveness}>{type.effectiveness}% effective</Text>
                    </TouchableOpacity>
                  ))}
                </View>

                <Text style={styles.inputLabel}>Budget ($)</Text>
                <TextInput
                  style={styles.input}
                  value={campaignBudget}
                  onChangeText={setCampaignBudget}
                  placeholder="Enter budget amount"
                  keyboardType="numeric"
                  placeholderTextColor="rgba(255,255,255,0.6)"
                />

                <Text style={styles.inputLabel}>Duration (days)</Text>
                <TextInput
                  style={styles.input}
                  value={campaignDuration}
                  onChangeText={setCampaignDuration}
                  placeholder="30"
                  keyboardType="numeric"
                  placeholderTextColor="rgba(255,255,255,0.6)"
                />
              </ScrollView>

              <View style={styles.modalButtons}>
                <TouchableOpacity
                  style={styles.modalCancelButton}
                  onPress={() => {
                    setShowCampaignModal(false);
                    resetCampaignForm();
                  }}
                >
                  <Text style={styles.modalCancelText}>Cancel</Text>
                </TouchableOpacity>
                
                <TouchableOpacity
                  style={styles.modalConfirmButton}
                  onPress={handleCreateCampaign}
                >
                  <Text style={styles.modalConfirmText}>Launch Campaign</Text>
                </TouchableOpacity>
              </View>
            </BlurView>
          </View>
        </Modal>

        {/* Custom Promotion Modal */}
        <Modal visible={showPromotionModal} transparent animationType="fade">
          <View style={styles.modalOverlay}>
            <BlurView intensity={40} style={styles.modalContent}>
              <View style={styles.modalHeader}>
                <Text style={styles.modalTitle}>Create Custom Promotion</Text>
                <TouchableOpacity onPress={() => setShowPromotionModal(false)}>
                  <MaterialIcons name="close" size={20} color="white" />
                </TouchableOpacity>
              </View>

              <ScrollView style={styles.modalBody}>
                <Text style={styles.inputLabel}>Promotion Name</Text>
                <TextInput
                  style={styles.input}
                  value={customPromotion.name}
                  onChangeText={(text) => setCustomPromotion(prev => ({ ...prev, name: text }))}
                  placeholder="Enter promotion name"
                  placeholderTextColor="rgba(255,255,255,0.6)"
                />

                <Text style={styles.inputLabel}>Description</Text>
                <TextInput
                  style={[styles.input, styles.textArea]}
                  value={customPromotion.description}
                  onChangeText={(text) => setCustomPromotion(prev => ({ ...prev, description: text }))}
                  placeholder="Describe the promotion"
                  multiline
                  numberOfLines={3}
                  placeholderTextColor="rgba(255,255,255,0.6)"
                />

                <Text style={styles.inputLabel}>
                  Satisfaction Impact (-5 to +5): {customPromotion.satisfactionImpact}%
                </Text>
                <View style={styles.sliderContainer}>
                  <TouchableOpacity
                    style={styles.sliderButton}
                    onPress={() => setCustomPromotion(prev => ({ 
                      ...prev, 
                      satisfactionImpact: Math.max(-5, prev.satisfactionImpact - 1) 
                    }))}
                  >
                    <MaterialIcons name="remove" size={16} color="white" />
                  </TouchableOpacity>
                  <View style={styles.sliderValue}>
                    <Text style={[
                      styles.sliderText,
                      { color: customPromotion.satisfactionImpact > 0 ? '#00FF7F' : customPromotion.satisfactionImpact < 0 ? '#FF4444' : 'white' }
                    ]}>
                      {customPromotion.satisfactionImpact > 0 ? '+' : ''}{customPromotion.satisfactionImpact}%
                    </Text>
                  </View>
                  <TouchableOpacity
                    style={styles.sliderButton}
                    onPress={() => setCustomPromotion(prev => ({ 
                      ...prev, 
                      satisfactionImpact: Math.min(5, prev.satisfactionImpact + 1) 
                    }))}
                  >
                    <MaterialIcons name="add" size={16} color="white" />
                  </TouchableOpacity>
                </View>

                <Text style={styles.inputLabel}>Duration (days)</Text>
                <TextInput
                  style={styles.input}
                  value={customPromotion.duration.toString()}
                  onChangeText={(text) => setCustomPromotion(prev => ({ 
                    ...prev, 
                    duration: parseInt(text) || 30 
                  }))}
                  placeholder="30"
                  keyboardType="numeric"
                  placeholderTextColor="rgba(255,255,255,0.6)"
                />

                <Text style={styles.inputLabel}>Cost ($)</Text>
                <TextInput
                  style={styles.input}
                  value={customPromotion.cost.toString()}
                  onChangeText={(text) => setCustomPromotion(prev => ({ 
                    ...prev, 
                    cost: parseFloat(text) || 0 
                  }))}
                  placeholder="Enter promotion cost"
                  keyboardType="numeric"
                  placeholderTextColor="rgba(255,255,255,0.6)"
                />
              </ScrollView>

              <View style={styles.modalButtons}>
                <TouchableOpacity
                  style={styles.modalCancelButton}
                  onPress={() => setShowPromotionModal(false)}
                >
                  <Text style={styles.modalCancelText}>Cancel</Text>
                </TouchableOpacity>
                
                <TouchableOpacity
                  style={styles.modalConfirmButton}
                  onPress={handleCreateCustomPromotion}
                >
                  <Text style={styles.modalConfirmText}>Create Promotion</Text>
                </TouchableOpacity>
              </View>
            </BlurView>
          </View>
        </Modal>

        {/* Web Alert Modal */}
        {Platform.OS === 'web' && (
          <Modal visible={alertConfig.visible} transparent animationType="fade">
            <View style={styles.alertOverlay}>
              <View style={styles.alertBox}>
                <Text style={styles.alertTitle}>{alertConfig.title}</Text>
                <Text style={styles.alertMessage}>{alertConfig.message}</Text>
                <TouchableOpacity 
                  style={styles.alertButton}
                  onPress={() => {
                    alertConfig.onOk?.();
                    setAlertConfig(prev => ({ ...prev, visible: false }));
                  }}
                >
                  <Text style={styles.alertButtonText}>OK</Text>
                </TouchableOpacity>
              </View>
            </View>
          </Modal>
        )}
      </LinearGradient>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
  },
  header: {
    padding: 16,
    alignItems: 'center',
    borderBottomWidth: 2,
    borderBottomColor: '#00FFFF',
  },
  title: {
    fontSize: 30,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 6,
  },
  subtitle: {
    fontSize: 18,
    color: '#00FFFF',
    fontWeight: 'bold',
    marginBottom: 6,
  },
  spendInfo: {
    fontSize: 10,
    color: '#00FF7F',
    fontWeight: 'bold',
  },
  tabNavigation: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.2)',
  },
  tab: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 8,
    backgroundColor: 'rgba(255,255,255,0.1)',
    marginHorizontal: 3,
    borderRadius: 6,
  },
  activeTab: {
    backgroundColor: '#00FFFF',
  },
  tabText: {
    fontSize: 10,
    fontWeight: 'bold',
    color: '#00FFFF',
  },
  activeTabText: {
    color: '#000000',
  },
  content: {
    flex: 1,
    paddingHorizontal: 16,
  },
  createButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    backgroundColor: '#00AA00',
    paddingVertical: 12,
    borderRadius: 8,
    marginVertical: 16,
    borderWidth: 2,
    borderColor: '#00FF7F',
  },
  createButtonText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: 'white',
  },
  emptyState: {
    alignItems: 'center',
    padding: 32,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 12,
    marginVertical: 16,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
    marginTop: 16,
    marginBottom: 8,
  },
  emptySubtitle: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.7)',
    textAlign: 'center',
    fontWeight: 'bold',
  },
  campaignCard: {
    backgroundColor: 'rgba(0,255,255,0.1)',
    borderRadius: 12,
    padding: 12,
    marginBottom: 8,
    borderWidth: 2,
  },
  campaignHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  campaignInfo: {
    flex: 1,
  },
  campaignName: {
    fontSize: 14,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 3,
  },
  campaignType: {
    fontSize: 10,
    color: '#00FFFF',
    fontWeight: 'bold',
    marginBottom: 3,
  },
  campaignDates: {
    fontSize: 8,
    color: 'rgba(255,255,255,0.7)',
    fontWeight: 'bold',
  },
  campaignActions: {
    alignItems: 'flex-end',
    gap: 6,
  },
  statusBadge: {
    paddingHorizontal: 6,
    paddingVertical: 3,
    borderRadius: 8,
  },
  activeStatus: {
    backgroundColor: '#00AA00',
  },
  pausedStatus: {
    backgroundColor: '#FF8800',
  },
  endedStatus: {
    backgroundColor: '#AA0000',
  },
  statusText: {
    fontSize: 7,
    fontWeight: 'bold',
    color: 'white',
  },
  pauseButton: {
    backgroundColor: '#00FFFF',
    width: 24,
    height: 24,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  campaignStats: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  statItem: {
    alignItems: 'center',
  },
  statLabel: {
    fontSize: 8,
    color: 'rgba(255,255,255,0.7)',
    fontWeight: 'bold',
    marginBottom: 3,
  },
  statValue: {
    fontSize: 10,
    fontWeight: 'bold',
    color: 'white',
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#00FF7F',
    marginTop: 16,
    marginBottom: 12,
  },
  promotionTemplate: {
    backgroundColor: 'rgba(0,255,127,0.1)',
    borderRadius: 12,
    padding: 12,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: '#00FF7F',
  },
  templateHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  templateInfo: {
    flex: 1,
    marginRight: 12,
  },
  templateName: {
    fontSize: 14,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 4,
  },
  templateDescription: {
    fontSize: 10,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
    marginBottom: 8,
    lineHeight: 16,
  },
  templateDetails: {
    gap: 3,
  },
  templateDetail: {
    fontSize: 8,
    color: 'rgba(255,255,255,0.7)',
    fontWeight: 'bold',
  },
  impactValue: {
    fontWeight: 'bold',
  },
  templateActions: {
    alignItems: 'flex-end',
  },
  templateCost: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#00FFFF',
    marginBottom: 8,
  },
  activateButton: {
    backgroundColor: '#00AA00',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
  },
  activateButtonText: {
    fontSize: 10,
    fontWeight: 'bold',
    color: 'white',
  },
  activePromotion: {
    backgroundColor: 'rgba(0,170,0,0.2)',
    borderRadius: 12,
    padding: 12,
    marginBottom: 8,
    borderWidth: 2,
    borderColor: '#00AA00',
  },
  promotionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  promotionInfo: {
    flex: 1,
    marginRight: 12,
  },
  promotionName: {
    fontSize: 14,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 4,
  },
  promotionDescription: {
    fontSize: 10,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
    marginBottom: 6,
  },
  promotionEnd: {
    fontSize: 8,
    color: '#00FFFF',
    fontWeight: 'bold',
  },
  promotionActions: {
    alignItems: 'flex-end',
    gap: 6,
  },
  impactBadge: {
    paddingHorizontal: 6,
    paddingVertical: 3,
    borderRadius: 8,
  },
  impactText: {
    fontSize: 8,
    fontWeight: 'bold',
    color: 'white',
  },
  endButton: {
    backgroundColor: '#AA0000',
    width: 24,
    height: 24,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.8)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    width: '90%',
    maxWidth: 400,
    maxHeight: '90%',
    backgroundColor: 'rgba(0,26,0,0.95)',
    borderRadius: 16,
    borderWidth: 2,
    borderColor: '#00FFFF',
    overflow: 'hidden',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 2,
    borderBottomColor: '#00FFFF',
  },
  modalTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'white',
  },
  modalBody: {
    flex: 1,
    padding: 16,
  },
  inputLabel: {
    fontSize: 12,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 6,
    marginTop: 12,
  },
  input: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 6,
    padding: 8,
    fontSize: 12,
    color: 'white',
    fontWeight: 'bold',
    borderWidth: 1,
    borderColor: '#00FFFF',
  },
  textArea: {
    minHeight: 60,
    textAlignVertical: 'top',
  },
  typeGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 8,
  },
  typeButton: {
    width: '48%',
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 8,
    padding: 8,
    alignItems: 'center',
    borderWidth: 2,
  },
  typeButtonActive: {
    backgroundColor: 'rgba(255,255,255,0.1)',
  },
  typeName: {
    fontSize: 8,
    fontWeight: 'bold',
    marginTop: 4,
    textAlign: 'center',
  },
  typeCost: {
    fontSize: 10,
    fontWeight: 'bold',
    color: '#00FFFF',
    marginTop: 3,
  },
  typeEffectiveness: {
    fontSize: 7,
    color: 'rgba(255,255,255,0.7)',
    fontWeight: 'bold',
    marginTop: 2,
  },
  sliderContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 16,
    marginBottom: 8,
  },
  sliderButton: {
    backgroundColor: '#00FFFF',
    width: 28,
    height: 28,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
  },
  sliderValue: {
    minWidth: 48,
    alignItems: 'center',
  },
  sliderText: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  modalButtons: {
    flexDirection: 'row',
    gap: 8,
    padding: 16,
    borderTopWidth: 2,
    borderTopColor: 'rgba(255,255,255,0.2)',
  },
  modalCancelButton: {
    flex: 1,
    backgroundColor: 'rgba(255,255,255,0.2)',
    paddingVertical: 10,
    borderRadius: 6,
    alignItems: 'center',
  },
  modalCancelText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: 'white',
  },
  modalConfirmButton: {
    flex: 1,
    backgroundColor: '#00FFFF',
    paddingVertical: 10,
    borderRadius: 6,
    alignItems: 'center',
  },
  modalConfirmText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#000000',
  },
  alertOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  alertBox: {
    backgroundColor: 'white',
    padding: 16,
    borderRadius: 6,
    minWidth: 200,
  },
  alertTitle: {
    fontSize: 12,
    fontWeight: 'bold',
    marginBottom: 6,
    color: 'black',
  },
  alertMessage: {
    fontSize: 10,
    marginBottom: 12,
    color: 'black',
  },
  alertButton: {
    backgroundColor: '#007AFF',
    padding: 6,
    borderRadius: 3,
    alignItems: 'center',
  },
  alertButtonText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 10,
  },
});