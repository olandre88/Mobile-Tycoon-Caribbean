import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, TextInput, Modal } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { MaterialIcons } from '@expo/vector-icons';
import { useGame } from '../../../hooks/useGame';

interface CandidateProfile {
  id: string;
  name: string;
  position: string;
  age: number;
  gender: 'male' | 'female';
  ethnicity: 'hispanic' | 'caribbean' | 'mixed';
  skills: {
    technical: number;
    management: number;
    sales: number;
    customerService: number;
  };
  expectedSalary: number;
  avatar: string;
  experience: number;
  education: string;
  nationality: string;
}

export default function EmployeesTab() {
  const { state, dispatch } = useGame();
  const [selectedTab, setSelectedTab] = useState<'overview' | 'hiring' | 'management'>('overview');
  const [candidates, setCandidates] = useState<CandidateProfile[]>([]);
  const [showHireModal, setShowHireModal] = useState(false);
  const [showCustomModal, setShowCustomModal] = useState(false);
  const [selectedCandidate, setSelectedCandidate] = useState<CandidateProfile | null>(null);
  const [customSalary, setCustomSalary] = useState('');
  const [showingSalaryEdit, setShowingSalaryEdit] = useState<string | null>(null);
  
  const [customCandidate, setCustomCandidate] = useState({
    name: '',
    position: 'Network Engineer',
    age: 25,
    gender: 'male' as 'male' | 'female',
    ethnicity: 'caribbean' as 'hispanic' | 'caribbean' | 'mixed',
    expectedSalary: 2500
  });

  const positions = [
    { id: 'ceo', name: 'Chief Executive Officer', icon: 'business-center', salaryRange: [4000, 8000] },
    { id: 'cto', name: 'Chief Technology Officer', icon: 'engineering', salaryRange: [3500, 7000] },
    { id: 'sales-manager', name: 'Sales Manager', icon: 'trending-up', salaryRange: [2500, 5000] },
    { id: 'network-engineer', name: 'Network Engineer', icon: 'router', salaryRange: [2000, 4000] },
    { id: 'customer-service', name: 'Customer Service Rep', icon: 'support-agent', salaryRange: [800, 2000] },
    { id: 'marketing-specialist', name: 'Marketing Specialist', icon: 'campaign', salaryRange: [1500, 3500] },
  ];

  const caribbeanNames = {
    male: ['Carlos', 'Miguel', 'José', 'Antonio', 'Roberto', 'Francisco', 'David', 'Juan', 'Pedro', 'Rafael'],
    female: ['Maria', 'Carmen', 'Ana', 'Rosa', 'Patricia', 'Isabella', 'Sofia', 'Camila', 'Lucia', 'Valentina']
  };

  const caribbeanSurnames = ['Rodriguez', 'Martinez', 'Garcia', 'Lopez', 'Gonzalez', 'Hernandez', 'Perez', 'Sanchez', 'Rivera', 'Torres'];

  const nationalities = [
    'Dominican', 'Puerto Rican', 'Cuban', 'Jamaican', 'Haitian', 'Trinidadian', 'Barbadian', 
    'Bahamian', 'Colombian', 'Venezuelan', 'Guyanese', 'Surinamese'
  ];

    const generateAvatar = (age: number, gender: 'male' | 'female', ethnicity: 'hispanic' | 'caribbean' | 'mixed') => {
    const baseEmojis = {
      male: {
        hispanic: ['👨🏽‍💼', '👨🏽‍💻', '👨🏽‍🔧', '👨🏽‍🏭'],
        caribbean: ['👨🏿‍💼', '👨🏿‍💻', '👨🏾‍💼', '👨🏾‍💻'],
        mixed: ['👨🏽‍💼', '👨🏽‍💻', '👨🏼‍💼', '👨🏽‍🔧']
      },
      female: {
        hispanic: ['👩🏽‍💼', '👩🏽‍💻', '👩🏽‍🔧', '👩🏽‍🏭'],
        caribbean: ['👩🏿‍💼', '👩🏿‍💻', '👩🏾‍💼', '👩🏾‍💻'],
        mixed: ['👩🏽‍💼', '👩🏽‍💻', '👩🏼‍💼', '👩🏽‍🔧']
      }
    };

    const options = baseEmojis[gender][ethnicity];
    return options[Math.floor(Math.random() * options.length)];
  };

  const generateCandidates = () => {
    const newCandidates: CandidateProfile[] = [];
    
    positions.forEach(position => {
      for (let i = 0; i < 3; i++) {
        const gender = Math.random() > 0.5 ? 'male' : 'female';
        const ethnicity = Math.random() > 0.6 ? 'caribbean' : Math.random() > 0.5 ? 'hispanic' : 'mixed';
        const age = Math.floor(Math.random() * 30) + 25;
        
        const firstName = gender === 'male' ? 
          caribbeanNames.male[Math.floor(Math.random() * caribbeanNames.male.length)] :
          caribbeanNames.female[Math.floor(Math.random() * caribbeanNames.female.length)];
        const lastName = caribbeanSurnames[Math.floor(Math.random() * caribbeanSurnames.length)];
        
        const baseSkill = Math.random() * 40 + 40;
        let skills = { technical: 0, management: 0, sales: 0, customerService: 0 };
        
        switch (position.id) {
          case 'ceo':
            skills = {
              technical: Math.round(baseSkill + Math.random() * 20),
              management: Math.round(baseSkill + 20 + Math.random() * 20),
              sales: Math.round(baseSkill + 10 + Math.random() * 20),
              customerService: Math.round(baseSkill + Math.random() * 15)
            };
            break;
          case 'cto':
            skills = {
              technical: Math.round(baseSkill + 20 + Math.random() * 20),
              management: Math.round(baseSkill + 10 + Math.random() * 15),
              sales: Math.round(baseSkill + Math.random() * 10),
              customerService: Math.round(baseSkill + Math.random() * 10)
            };
            break;
          default:
            skills = {
              technical: Math.round(baseSkill + Math.random() * 15),
              management: Math.round(baseSkill + Math.random() * 10),
              sales: Math.round(baseSkill + Math.random() * 15),
              customerService: Math.round(baseSkill + Math.random() * 15)
            };
        }

        Object.keys(skills).forEach(key => {
          skills[key as keyof typeof skills] = Math.min(100, skills[key as keyof typeof skills]);
        });

        const experience = Math.floor(Math.random() * 15) + 1;
        const salaryMultiplier = 0.8 + (Math.random() * 0.4);
        const expectedSalary = Math.round(
          (position.salaryRange[0] + (position.salaryRange[1] - position.salaryRange[0]) * (skills.technical + skills.management) / 200) * salaryMultiplier
        );

        newCandidates.push({
          id: `candidate_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          name: `${firstName} ${lastName}`,
          position: position.name,
          age,
          gender,
          ethnicity,
          skills,
          expectedSalary,
          avatar: generateAvatar(age, gender, ethnicity),
          experience,
          education: ['Bachelor\'s Degree', 'Master\'s Degree', 'Associate Degree', 'High School'][Math.floor(Math.random() * 4)],
          nationality: nationalities[Math.floor(Math.random() * nationalities.length)]
        });
      }
    });
    
    setCandidates(newCandidates);
  };

  const handleHireCandidate = (candidate: CandidateProfile) => {
    if (!state.selectedCountry) {
      dispatch({ 
        type: 'ADD_NOTIFICATION', 
        payload: { 
          type: 'warning', 
          message: 'Please select a country first before hiring employees',
          id: Date.now().toString()
        }
      });
      return;
    }

    setSelectedCandidate(candidate);
    setCustomSalary(candidate.expectedSalary.toString());
    setShowHireModal(true);
  };

  const confirmHire = () => {
    if (!selectedCandidate || !state.selectedCountry) return;

    const salary = parseInt(customSalary) || selectedCandidate.expectedSalary;
    
    if (state.company.capital < salary * 12) {
      dispatch({ 
        type: 'ADD_NOTIFICATION', 
        payload: { 
          type: 'error', 
          message: `Insufficient capital for annual salary of $${(salary * 12).toLocaleString()}`,
          id: Date.now().toString()
        }
      });
      return;
    }

    const newEmployee = {
      id: `employee_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      name: selectedCandidate.name,
      position: selectedCandidate.position,
      salary,
      skills: selectedCandidate.skills,
      avatar: selectedCandidate.avatar,
      hireDate: new Date(state.gameDate),
      performance: 80 + Math.random() * 20,
      countryId: state.selectedCountry.id,
      experience: selectedCandidate.experience,
      education: selectedCandidate.education,
      nationality: selectedCandidate.nationality
    };

    dispatch({ type: 'ADD_EMPLOYEE', payload: newEmployee });
    setCandidates(prev => prev.filter(c => c.id !== selectedCandidate.id));
    
    dispatch({ 
      type: 'ADD_NOTIFICATION', 
      payload: { 
        type: 'info', 
        message: `${selectedCandidate.name} hired as ${selectedCandidate.position}!`,
        id: Date.now().toString()
      }
    });
    
    setShowHireModal(false);
    setSelectedCandidate(null);
  };

  const handleCreateCustomCandidate = () => {
    if (!customCandidate.name.trim()) {
      dispatch({ 
        type: 'ADD_NOTIFICATION', 
        payload: { 
          type: 'error', 
          message: 'Please enter candidate name',
          id: Date.now().toString()
        }
      });
      return;
    }

    const baseSkill = Math.random() * 30 + 50;
    const skills = {
      technical: Math.round(baseSkill + Math.random() * 20),
      management: Math.round(baseSkill + Math.random() * 20),
      sales: Math.round(baseSkill + Math.random() * 20),
      customerService: Math.round(baseSkill + Math.random() * 20)
    };

    const newCandidate: CandidateProfile = {
      id: `custom_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      name: customCandidate.name.trim(),
      position: customCandidate.position,
      age: customCandidate.age,
      gender: customCandidate.gender,
      ethnicity: customCandidate.ethnicity,
      skills,
      expectedSalary: customCandidate.expectedSalary,
      avatar: generateAvatar(customCandidate.age, customCandidate.gender, customCandidate.ethnicity),
      experience: Math.floor(Math.random() * 10) + 1,
      education: ['Bachelor\'s Degree', 'Master\'s Degree', 'Associate Degree'][Math.floor(Math.random() * 3)],
      nationality: nationalities[Math.floor(Math.random() * nationalities.length)]
    };

    setCandidates(prev => [newCandidate, ...prev]);
    setCustomCandidate({
      name: '',
      position: 'Network Engineer',
      age: 25,
      gender: 'male',
      ethnicity: 'caribbean',
      expectedSalary: 2500
    });
    
    setShowCustomModal(false);
    
    dispatch({ 
      type: 'ADD_NOTIFICATION', 
      payload: { 
        type: 'info', 
        message: `Custom candidate ${newCandidate.name} added successfully!`,
        id: Date.now().toString()
      }
    });
  };

  const handleFireEmployee = (employeeId: string) => {
    const employee = state.employees.find(emp => emp.id === employeeId);
    if (employee) {
      dispatch({ type: 'REMOVE_EMPLOYEE', payload: employeeId });
      dispatch({ 
        type: 'ADD_NOTIFICATION', 
        payload: { 
          type: 'info', 
          message: `${employee.name} has been terminated`,
          id: Date.now().toString()
        }
      });
    }
  };

  const handleSalaryUpdate = (employeeId: string, newSalary: string) => {
    const salary = parseInt(newSalary) || 0;
    if (salary >= 500 && salary <= 10000) {
      dispatch({ 
        type: 'UPDATE_EMPLOYEE', 
        payload: { 
          id: employeeId, 
          updates: { salary }
        }
      });
      setShowingSalaryEdit(null);
    }
  };

  const getSkillColor = (skill: number) => {
    if (skill >= 80) return '#00FF00';
    if (skill >= 60) return '#00FF00';
    if (skill >= 40) return '#FF0000';
    return '#FF0000';
  };

  const formatCurrency = (amount: number) => {
    return `$${amount.toLocaleString()}`;
  };

  const teamStats = {
    totalEmployees: state.employees?.length || 0,
    totalMonthlySalaries: state.employees?.reduce((sum, emp) => sum + (emp.salary || 0), 0) || 0,
    averagePerformance: state.employees?.length > 0 ? 
      state.employees.reduce((sum, emp) => sum + (emp.performance || 80), 0) / state.employees.length : 0,
    topPerformer: state.employees?.reduce((top, emp) => 
      (emp.performance || 0) > (top?.performance || 0) ? emp : top, state.employees[0] || null)
  };

  return (
        <View style={styles.container}>
      <LinearGradient colors={['#000000', '#8B0040', '#006400']} style={styles.background}>
        <View style={styles.header}>
          <Text style={styles.title}>Team Management</Text>
          <Text style={styles.subtitle}>
            {state.selectedCountry ? `${state.selectedCountry.flag} ${state.selectedCountry.name}` : 'Select a country to manage team'}
          </Text>
        </View>

        <View style={styles.tabNavigation}>
          <TouchableOpacity
            style={[styles.tab, selectedTab === 'overview' && styles.activeTab]}
            onPress={() => setSelectedTab('overview')}
          >
            <Text style={[styles.tabText, selectedTab === 'overview' && styles.activeTabText]}>
              Overview
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.tab, selectedTab === 'hiring' && styles.activeTab]}
            onPress={() => setSelectedTab('hiring')}
          >
            <Text style={[styles.tabText, selectedTab === 'hiring' && styles.activeTabText]}>
              Hiring
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.tab, selectedTab === 'management' && styles.activeTab]}
            onPress={() => setSelectedTab('management')}
          >
            <Text style={[styles.tabText, selectedTab === 'management' && styles.activeTabText]}>
              Management
            </Text>
          </TouchableOpacity>
        </View>

        <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
          {selectedTab === 'overview' && (
            <>
              <BlurView intensity={15} style={styles.statsGrid}>
                <View style={styles.statCard}>
                  <MaterialIcons name="people" size={10} color="#00FF00" />
                  <Text style={styles.statValue}>{teamStats.totalEmployees}</Text>
                  <Text style={styles.statLabel}>Total Employees</Text>
                </View>
                <View style={styles.statCard}>
                  <MaterialIcons name="attach-money" size={10} color="#00FF00" />
                  <Text style={styles.statValue}>{formatCurrency(teamStats.totalMonthlySalaries)}</Text>
                  <Text style={styles.statLabel}>Monthly Salaries</Text>
                </View>
                <View style={styles.statCard}>
                  <MaterialIcons name="trending-up" size={10} color="#FF0000" />
                  <Text style={styles.statValue}>{teamStats.averagePerformance.toFixed(1)}%</Text>
                  <Text style={styles.statLabel}>Avg Performance</Text>
                </View>
                <View style={styles.statCard}>
                  <MaterialIcons name="star" size={10} color="#00FF00" />
                  <Text style={styles.statValue}>{teamStats.topPerformer?.name.split(' ')[0] || 'None'}</Text>
                  <Text style={styles.statLabel}>Top Performer</Text>
                </View>
              </BlurView>

              <BlurView intensity={15} style={styles.section}>
                <View style={styles.sectionHeader}>
                  <MaterialIcons name="group" size={7} color="#00FF00" />
                  <Text style={styles.sectionTitle}>Current Team</Text>
                </View>
                
                {state.employees?.filter(emp => emp.countryId === state.selectedCountry?.id).length === 0 ? (
                  <View style={styles.emptyState}>
                    <MaterialIcons name="people-outline" size={16} color="rgba(255,255,255,0.5)" />
                    <Text style={styles.emptyText}>No employees hired yet</Text>
                    <Text style={styles.emptySubtext}>Go to Hiring tab to recruit your team</Text>
                  </View>
                ) : (
                  state.employees?.filter(emp => emp.countryId === state.selectedCountry?.id).map((employee) => (
                    <View key={employee.id} style={styles.employeeCard}>
                      <View style={styles.employeeHeader}>
                        <Text style={styles.employeeAvatar}>{employee.avatar}</Text>
                        <View style={styles.employeeInfo}>
                          <Text style={styles.employeeName}>{employee.name}</Text>
                          <Text style={styles.employeePosition}>{employee.position}</Text>
                        </View>
                        <View style={styles.employeeStats}>
                          <Text style={styles.employeeSalary}>{formatCurrency(employee.salary)}/mo</Text>
                          <Text style={styles.employeePerformance}>{employee.performance?.toFixed(1)}%</Text>
                        </View>
                      </View>
                      
                      <View style={styles.skillsGrid}>
                        {Object.entries(employee.skills).map(([skill, value]) => (
                          <View key={skill} style={styles.skillItem}>
                            <Text style={styles.skillName}>{skill}</Text>
                            <View style={styles.skillBar}>
                              <View 
                                style={[
                                  styles.skillFill, 
                                  { 
                                    width: `${value}%`,
                                    backgroundColor: getSkillColor(value)
                                  }
                                ]} 
                              />
                            </View>
                            <Text style={[styles.skillValue, { color: getSkillColor(value) }]}>
                              {value}
                            </Text>
                          </View>
                        ))}
                      </View>
                    </View>
                  ))
                )}
              </BlurView>
            </>
          )}

          {selectedTab === 'hiring' && (
            <BlurView intensity={15} style={styles.section}>
              <View style={styles.sectionHeader}>
                <MaterialIcons name="person-add" size={7} color="#00FF00" />
                <Text style={styles.sectionTitle}>Available Candidates</Text>
                <View style={styles.headerButtons}>
                  <TouchableOpacity 
                    style={styles.customButton} 
                    onPress={() => setShowCustomModal(true)}
                  >
                    <MaterialIcons name="person-add" size={5} color="white" />
                    <Text style={styles.customButtonText}>Custom</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={styles.refreshButton} onPress={generateCandidates}>
                    <MaterialIcons name="refresh" size={5} color="white" />
                    <Text style={styles.refreshText}>Refresh</Text>
                  </TouchableOpacity>
                </View>
              </View>
              
              {candidates.length === 0 ? (
                <View style={styles.emptyState}>
                  <MaterialIcons name="person-search" size={16} color="rgba(255,255,255,0.5)" />
                  <Text style={styles.emptyText}>No candidates available</Text>
                  <TouchableOpacity style={styles.generateButton} onPress={generateCandidates}>
                    <MaterialIcons name="group-add" size={10} color="white" />
                    <Text style={styles.generateButtonText}>Find Candidates</Text>
                  </TouchableOpacity>
                </View>
              ) : (
                candidates.map((candidate) => (
                  <View key={candidate.id} style={styles.candidateCard}>
                    <View style={styles.candidateHeader}>
                      <Text style={styles.candidateAvatar}>{candidate.avatar}</Text>
                      <View style={styles.candidateInfo}>
                        <Text style={styles.candidateName}>{candidate.name}</Text>
                        <Text style={styles.candidatePosition}>{candidate.position}</Text>
                        <Text style={styles.candidateDetails}>
                          {candidate.age}y • {candidate.experience}yr exp • {candidate.education} • {candidate.nationality}
                        </Text>
                      </View>
                      <View style={styles.candidateActions}>
                        <Text style={styles.candidateSalary}>{formatCurrency(candidate.expectedSalary)}/mo</Text>
                        <TouchableOpacity 
                          style={styles.hireButton}
                          onPress={() => handleHireCandidate(candidate)}
                        >
                          <Text style={styles.hireButtonText}>Hire</Text>
                        </TouchableOpacity>
                      </View>
                    </View>
                    
                    <View style={styles.candidateSkills}>
                      {Object.entries(candidate.skills).map(([skill, value]) => (
                        <View key={skill} style={styles.candidateSkill}>
                          <Text style={styles.candidateSkillName}>{skill}</Text>
                          <Text style={[styles.candidateSkillValue, { color: getSkillColor(value) }]}>
                            {value}
                          </Text>
                        </View>
                      ))}
                    </View>
                  </View>
                ))
              )}
            </BlurView>
          )}

          {selectedTab === 'management' && (
            <BlurView intensity={15} style={styles.section}>
              <View style={styles.sectionHeader}>
                <MaterialIcons name="manage-accounts" size={7} color="#00FF00" />
                <Text style={styles.sectionTitle}>Team Management</Text>
              </View>
              
              {state.employees?.filter(emp => emp.countryId === state.selectedCountry?.id).map((employee) => (
                <View key={employee.id} style={styles.managementCard}>
                  <View style={styles.managementHeader}>
                    <Text style={styles.managementAvatar}>{employee.avatar}</Text>
                    <View style={styles.managementInfo}>
                      <Text style={styles.managementName}>{employee.name}</Text>
                      <Text style={styles.managementPosition}>{employee.position}</Text>
                    </View>
                    <TouchableOpacity 
                      style={styles.fireButton}
                      onPress={() => handleFireEmployee(employee.id)}
                    >
                      <MaterialIcons name="person-remove" size={6} color="white" />
                    </TouchableOpacity>
                  </View>
                  
                  <View style={styles.managementControls}>
                    <View style={styles.salaryControl}>
                      <Text style={styles.salaryLabel}>Monthly Salary:</Text>
                      {showingSalaryEdit === employee.id ? (
                        <View style={styles.salaryEdit}>
                          <TextInput
                            style={styles.salaryInput}
                            value={customSalary}
                            onChangeText={setCustomSalary}
                            keyboardType="numeric"
                            placeholder="Enter salary"
                            placeholderTextColor="rgba(255,255,255,0.6)"
                          />
                          <TouchableOpacity 
                            style={styles.saveButton}
                            onPress={() => handleSalaryUpdate(employee.id, customSalary)}
                          >
                            <MaterialIcons name="check" size={4} color="white" />
                          </TouchableOpacity>
                          <TouchableOpacity 
                            style={styles.cancelButton}
                            onPress={() => setShowingSalaryEdit(null)}
                          >
                            <MaterialIcons name="close" size={4} color="white" />
                          </TouchableOpacity>
                        </View>
                      ) : (
                        <TouchableOpacity 
                          style={styles.salaryDisplay}
                          onPress={() => {
                            setShowingSalaryEdit(employee.id);
                            setCustomSalary(employee.salary.toString());
                          }}
                        >
                          <Text style={styles.salaryValue}>{formatCurrency(employee.salary)}/mo</Text>
                          <MaterialIcons name="edit" size={4} color="#00FF00" />
                        </TouchableOpacity>
                      )}
                    </View>
                  </View>
                </View>
              ))}
            </BlurView>
          )}
        </ScrollView>

        <Modal visible={showHireModal} transparent animationType="fade">
          <View style={styles.modalOverlay}>
            <BlurView intensity={40} style={styles.modalContent}>
              <Text style={styles.modalTitle}>Hire Employee</Text>
              
              {selectedCandidate && (
                <>
                  <Text style={styles.modalCandidateName}>{selectedCandidate.name}</Text>
                  <Text style={styles.modalCandidatePosition}>{selectedCandidate.position}</Text>
                  
                  <View style={styles.modalSalarySection}>
                    <Text style={styles.modalSalaryLabel}>Monthly Salary:</Text>
                    <TextInput
                      style={styles.modalSalaryInput}
                      value={customSalary}
                      onChangeText={setCustomSalary}
                      keyboardType="numeric"
                      placeholder="Enter salary"
                      placeholderTextColor="rgba(255,255,255,0.6)"
                    />
                    <Text style={styles.modalSalaryNote}>
                      Expected: {formatCurrency(selectedCandidate.expectedSalary)}/mo
                    </Text>
                  </View>
                  
                  <View style={styles.modalButtons}>
                    <TouchableOpacity
                      style={styles.modalCancelButton}
                      onPress={() => setShowHireModal(false)}
                    >
                      <Text style={styles.modalCancelText}>Cancel</Text>
                    </TouchableOpacity>
                    
                    <TouchableOpacity
                      style={styles.modalConfirmButton}
                      onPress={confirmHire}
                    >
                      <Text style={styles.modalConfirmText}>Hire Employee</Text>
                    </TouchableOpacity>
                  </View>
                </>
              )}
            </BlurView>
          </View>
        </Modal>

        <Modal visible={showCustomModal} transparent animationType="fade">
          <View style={styles.modalOverlay}>
            <BlurView intensity={40} style={styles.modalContent}>
              <Text style={styles.modalTitle}>Create Custom Candidate</Text>
              
              <ScrollView style={styles.modalBody}>
                <View style={styles.inputContainer}>
                  <Text style={styles.inputLabel}>Full Name</Text>
                  <TextInput
                    style={styles.input}
                    value={customCandidate.name}
                    onChangeText={(text) => setCustomCandidate(prev => ({ ...prev, name: text }))}
                    placeholder="Enter candidate name"
                    placeholderTextColor="rgba(255,255,255,0.6)"
                  />
                </View>

                <View style={styles.inputContainer}>
                  <Text style={styles.inputLabel}>Position</Text>
                  <View style={styles.positionButtons}>
                    {positions.map(pos => (
                      <TouchableOpacity
                        key={pos.id}
                        style={[styles.positionButton, customCandidate.position === pos.name && styles.positionButtonActive]}
                        onPress={() => setCustomCandidate(prev => ({ ...prev, position: pos.name }))}
                      >
                        <Text style={styles.positionButtonText}>{pos.name}</Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                </View>

                <View style={styles.rowInputs}>
                  <View style={styles.halfInput}>
                    <Text style={styles.inputLabel}>Age</Text>
                    <TextInput
                      style={styles.input}
                      value={customCandidate.age.toString()}
                      onChangeText={(text) => setCustomCandidate(prev => ({ ...prev, age: parseInt(text) || 25 }))}
                      keyboardType="numeric"
                      placeholder="25"
                      placeholderTextColor="rgba(255,255,255,0.6)"
                    />
                  </View>
                  
                  <View style={styles.halfInput}>
                    <Text style={styles.inputLabel}>Expected Salary</Text>
                    <TextInput
                      style={styles.input}
                      value={customCandidate.expectedSalary.toString()}
                      onChangeText={(text) => setCustomCandidate(prev => ({ 
                        ...prev, 
                        expectedSalary: parseInt(text) || 2500 
                      }))}
                      keyboardType="numeric"
                      placeholder="2500"
                      placeholderTextColor="rgba(255,255,255,0.6)"
                    />
                  </View>
                </View>

                <View style={styles.rowInputs}>
                  <View style={styles.halfInput}>
                    <Text style={styles.inputLabel}>Gender</Text>
                    <View style={styles.optionButtons}>
                      <TouchableOpacity
                        style={[styles.optionButton, customCandidate.gender === 'male' && styles.optionButtonActive]}
                        onPress={() => setCustomCandidate(prev => ({ ...prev, gender: 'male' }))}
                      >
                        <Text style={styles.optionButtonText}>Male</Text>
                      </TouchableOpacity>
                      <TouchableOpacity
                        style={[styles.optionButton, customCandidate.gender === 'female' && styles.optionButtonActive]}
                        onPress={() => setCustomCandidate(prev => ({ ...prev, gender: 'female' }))}
                      >
                        <Text style={styles.optionButtonText}>Female</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                  
                  <View style={styles.halfInput}>
                    <Text style={styles.inputLabel}>Ethnicity</Text>
                    <View style={styles.optionButtons}>
                      <TouchableOpacity
                        style={[styles.optionButton, customCandidate.ethnicity === 'caribbean' && styles.optionButtonActive]}
                        onPress={() => setCustomCandidate(prev => ({ ...prev, ethnicity: 'caribbean' }))}
                      >
                        <Text style={styles.optionButtonText}>Caribbean</Text>
                      </TouchableOpacity>
                      <TouchableOpacity
                        style={[styles.optionButton, customCandidate.ethnicity === 'hispanic' && styles.optionButtonActive]}
                        onPress={() => setCustomCandidate(prev => ({ ...prev, ethnicity: 'hispanic' }))}
                      >
                        <Text style={styles.optionButtonText}>Hispanic</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>

                <View style={styles.avatarPreview}>
                  <Text style={styles.inputLabel}>Generated Avatar Preview:</Text>
                  <Text style={styles.previewAvatar}>
                    {generateAvatar(customCandidate.age, customCandidate.gender, customCandidate.ethnicity)}
                  </Text>
                </View>
              </ScrollView>
              
              <View style={styles.modalButtons}>
                <TouchableOpacity
                  style={styles.modalCancelButton}
                  onPress={() => setShowCustomModal(false)}
                >
                  <Text style={styles.modalCancelText}>Cancel</Text>
                </TouchableOpacity>
                
                <TouchableOpacity
                  style={styles.modalConfirmButton}
                  onPress={handleCreateCustomCandidate}
                >
                  <Text style={styles.modalConfirmText}>Create Candidate</Text>
                </TouchableOpacity>
              </View>
            </BlurView>
          </View>
        </Modal>
      </LinearGradient>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
  },
  header: {
    padding: 6,
    alignItems: 'center',
  },
  title: {
    fontSize: 12,
    fontWeight: 'bold',
    color: 'white',
  },
  subtitle: {
    fontSize: 8,
    color: 'rgba(255,255,255,0.8)',
    textAlign: 'center',
    marginTop: 2,
    fontWeight: 'bold',
  },
  tabNavigation: {
    flexDirection: 'row',
    paddingHorizontal: 6,
    marginBottom: 6,
  },
  tab: {
    flex: 1,
    paddingVertical: 2,
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.1)',
    marginHorizontal: 1,
    borderRadius: 2,
  },
  activeTab: {
    backgroundColor: '#00FF00',
  },
  tabText: {
    fontSize: 8,
    fontWeight: 'bold',
    color: 'rgba(255,255,255,0.8)',
  },
  activeTabText: {
    color: '#000000',
  },
  content: {
    flex: 1,
    paddingHorizontal: 6,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 3,
    padding: 3,
    marginBottom: 6,
  },
  statCard: {
    width: '48%',
    alignItems: 'center',
    marginBottom: 3,
  },
  statValue: {
    fontSize: 8,
    fontWeight: 'bold',
    color: 'white',
    marginTop: 3,
    textAlign: 'center',
  },
  statLabel: {
    fontSize: 3,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
    textAlign: 'center',
    marginTop: 1,
  },
  section: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 3,
    padding: 3,
    marginBottom: 6,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 3,
    gap: 2,
  },
  sectionTitle: {
    fontSize: 5,
    fontWeight: 'bold',
    color: 'white',
    flex: 1,
  },
  headerButtons: {
    flexDirection: 'row',
    gap: 2,
  },
  customButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 1,
    backgroundColor: 'rgba(0,255,0,0.2)',
    paddingHorizontal: 2,
    paddingVertical: 1,
    borderRadius: 2,
  },
  customButtonText: {
    fontSize: 3,
    fontWeight: 'bold',
    color: 'white',
  },
  refreshButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 1,
    backgroundColor: 'rgba(0,255,0,0.2)',
    paddingHorizontal: 2,
    paddingVertical: 1,
    borderRadius: 2,
  },
  refreshText: {
    fontSize: 3,
    fontWeight: 'bold',
    color: 'white',
  },
  emptyState: {
    alignItems: 'center',
    padding: 6,
  },
  emptyText: {
    fontSize: 5,
    fontWeight: 'bold',
    color: 'white',
    marginTop: 2,
  },
  emptySubtext: {
    fontSize: 3,
    color: 'rgba(255,255,255,0.6)',
    textAlign: 'center',
    marginTop: 1,
    fontWeight: 'bold',
  },
  generateButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 1,
    backgroundColor: '#00FF00',
    paddingHorizontal: 3,
    paddingVertical: 2,
    borderRadius: 2,
    marginTop: 3,
  },
  generateButtonText: {
    fontSize: 4,
    fontWeight: 'bold',
    color: '#000000',
  },
  employeeCard: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 2,
    padding: 3,
    marginBottom: 2,
  },
  employeeHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 2,
  },
  employeeAvatar: {
    fontSize: 8,
    marginRight: 2,
  },
  employeeInfo: {
    flex: 1,
  },
  employeeName: {
    fontSize: 4,
    fontWeight: 'bold',
    color: 'white',
  },
  employeePosition: {
    fontSize: 3,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
  },
  employeeStats: {
    alignItems: 'flex-end',
  },
  employeeSalary: {
    fontSize: 3,
    fontWeight: 'bold',
    color: '#00FF00',
  },
  employeePerformance: {
    fontSize: 3,
    color: '#00FF00',
    fontWeight: 'bold',
  },
  skillsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 1,
  },
  skillItem: {
    flex: 1,
    minWidth: '45%',
  },
  skillName: {
    fontSize: 2,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
    marginBottom: 1,
  },
  skillBar: {
    height: 1,
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 1,
    overflow: 'hidden',
    marginBottom: 1,
  },
  skillFill: {
    height: '100%',
    borderRadius: 1,
  },
  skillValue: {
    fontSize: 2,
    fontWeight: 'bold',
    textAlign: 'right',
  },
  candidateCard: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 2,
    padding: 3,
    marginBottom: 2,
  },
  candidateHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 2,
  },
  candidateAvatar: {
    fontSize: 8,
    marginRight: 2,
  },
  candidateInfo: {
    flex: 1,
  },
  candidateName: {
    fontSize: 4,
    fontWeight: 'bold',
    color: 'white',
  },
  candidatePosition: {
    fontSize: 3,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
  },
  candidateDetails: {
    fontSize: 2,
    color: 'rgba(255,255,255,0.6)',
    fontWeight: 'bold',
    marginTop: 1,
  },
  candidateActions: {
    alignItems: 'flex-end',
  },
  candidateSalary: {
    fontSize: 3,
    fontWeight: 'bold',
    color: '#00FF00',
    marginBottom: 1,
  },
  hireButton: {
    backgroundColor: '#00FF00',
    paddingHorizontal: 2,
    paddingVertical: 1,
    borderRadius: 1,
  },
  hireButtonText: {
    fontSize: 3,
    fontWeight: 'bold',
    color: '#000000',
  },
  candidateSkills: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 2,
  },
  candidateSkill: {
    alignItems: 'center',
  },
  candidateSkillName: {
    fontSize: 2,
    color: 'rgba(255,255,255,0.6)',
    fontWeight: 'bold',
  },
  candidateSkillValue: {
    fontSize: 2,
    fontWeight: 'bold',
  },
  managementCard: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 2,
    padding: 3,
    marginBottom: 2,
  },
  managementHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 2,
  },
  managementAvatar: {
    fontSize: 8,
    marginRight: 2,
  },
  managementInfo: {
    flex: 1,
  },
  managementName: {
    fontSize: 4,
    fontWeight: 'bold',
    color: 'white',
  },
  managementPosition: {
    fontSize: 3,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
  },
  fireButton: {
    backgroundColor: '#FF0000',
    padding: 2,
    borderRadius: 1,
  },
  managementControls: {
    paddingTop: 2,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.2)',
  },
  salaryControl: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  salaryLabel: {
    fontSize: 3,
    fontWeight: 'bold',
    color: 'white',
  },
  salaryDisplay: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 1,
  },
  salaryValue: {
    fontSize: 3,
    fontWeight: 'bold',
    color: '#00FF00',
  },
  salaryEdit: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 1,
  },
  salaryInput: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 1,
    paddingHorizontal: 2,
    paddingVertical: 1,
    fontSize: 3,
    color: 'white',
    fontWeight: 'bold',
    minWidth: 15,
  },
  saveButton: {
    backgroundColor: '#00FF00',
    padding: 1,
    borderRadius: 1,
  },
  cancelButton: {
    backgroundColor: '#FF0000',
    padding: 1,
    borderRadius: 1,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.7)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    width: '90%',
    maxWidth: 160,
    maxHeight: '80%',
    backgroundColor: 'rgba(0,0,0,0.95)',
    borderRadius: 6,
    padding: 6,
  },
  modalTitle: {
    fontSize: 6,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
    marginBottom: 3,
  },
  modalCandidateName: {
    fontSize: 5,
    fontWeight: 'bold',
    color: '#00FF00',
    textAlign: 'center',
  },
  modalCandidatePosition: {
    fontSize: 3,
    color: 'rgba(255,255,255,0.8)',
    textAlign: 'center',
    marginBottom: 4,
    fontWeight: 'bold',
  },
  modalSalarySection: {
    marginBottom: 6,
  },
  modalSalaryLabel: {
    fontSize: 3,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 1,
  },
  modalSalaryInput: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 2,
    padding: 2,
    fontSize: 4,
    color: 'white',
    fontWeight: 'bold',
    marginBottom: 1,
  },
  modalSalaryNote: {
    fontSize: 3,
    color: 'rgba(255,255,255,0.6)',
    fontWeight: 'bold',
  },
  modalBody: {
    maxHeight: 80,
  },
  inputContainer: {
    marginBottom: 3,
  },
  inputLabel: {
    fontSize: 3,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 1,
  },
  input: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 2,
    padding: 2,
    fontSize: 4,
    color: 'white',
    fontWeight: 'bold',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
  },
  positionButtons: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 1,
  },
  positionButton: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    paddingHorizontal: 2,
    paddingVertical: 1,
    borderRadius: 1,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
  },
  positionButtonActive: {
    backgroundColor: '#00FF00',
    borderColor: '#00FF00',
  },
  positionButtonText: {
    fontSize: 3,
    fontWeight: 'bold',
    color: 'white',
  },
  rowInputs: {
    flexDirection: 'row',
    gap: 2,
  },
  halfInput: {
    flex: 1,
  },
  optionButtons: {
    flexDirection: 'row',
    gap: 1,
  },
  optionButton: {
    flex: 1,
    backgroundColor: 'rgba(255,255,255,0.1)',
    paddingVertical: 1,
    borderRadius: 1,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
  },
  optionButtonActive: {
    backgroundColor: '#00FF00',
    borderColor: '#00FF00',
  },
  optionButtonText: {
    fontSize: 3,
    fontWeight: 'bold',
    color: 'white',
  },
  avatarPreview: {
    alignItems: 'center',
    marginTop: 3,
  },
  previewAvatar: {
    fontSize: 12,
    marginTop: 1,
  },
  modalButtons: {
    flexDirection: 'row',
    gap: 2,
    marginTop: 3,
  },
  modalCancelButton: {
    flex: 1,
    backgroundColor: 'rgba(255,255,255,0.2)',
    paddingVertical: 2,
    borderRadius: 2,
    alignItems: 'center',
  },
  modalCancelText: {
    fontSize: 4,
    fontWeight: 'bold',
    color: 'white',
  },
  modalConfirmButton: {
    flex: 1,
    backgroundColor: '#00FF00',
    paddingVertical: 2,
    borderRadius: 2,
    alignItems: 'center',
  },
  modalConfirmText: {
    fontSize: 4,
    fontWeight: 'bold',
    color: '#000000',
  },
});