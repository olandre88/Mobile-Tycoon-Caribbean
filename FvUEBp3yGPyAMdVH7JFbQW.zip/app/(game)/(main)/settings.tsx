import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView, StyleSheet, Platform, Modal, Alert } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { MaterialIcons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import * as ImagePicker from 'expo-image-picker';
import { router } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useGame } from '../../../hooks/useGame';

export default function SettingsTab() {
  const { state, dispatch } = useGame();
  const [companyName, setCompanyName] = useState(state.company.name);
  const [ceoName, setCeoName] = useState(state.company.ceo);
  const [companyLogo, setCompanyLogo] = useState(state.company.logo);
  const [autoSave, setAutoSave] = useState(state.settings.autoSave);
  const [soundEnabled, setSoundEnabled] = useState(state.settings.soundEnabled);
  const [gameSpeed, setGameSpeed] = useState(state.settings.gameSpeed);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const [alertConfig, setAlertConfig] = useState<{
    visible: boolean;
    title: string;
    message: string;
    onOk?: () => void;
  }>({ visible: false, title: '', message: '' });

  const showWebAlert = (title: string, message: string, onOk?: () => void) => {
    if (Platform.OS === 'web') {
      setAlertConfig({ visible: true, title, message, onOk });
    } else {
      Alert.alert(title, message, onOk ? [{ text: 'OK', onPress: onOk }] : undefined);
    }
  };

  const pickImage = async () => {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
      });

      if (!result.canceled && result.assets[0]) {
        const asset = result.assets[0];
        
        if (asset.fileSize && asset.fileSize > 5 * 1024 * 1024) {
          showWebAlert('File Too Large', 'Please select an image smaller than 5MB.');
          return;
        }

        setCompanyLogo(asset.uri);
        dispatch({ 
          type: 'SET_COMPANY', 
          payload: { logo: asset.uri }
        });
        
        dispatch({ 
          type: 'ADD_NOTIFICATION', 
          payload: { 
            type: 'info', 
            message: '✅ Company logo updated successfully!',
            id: Date.now().toString()
          }
        });
      }
    } catch (error) {
      showWebAlert('Error', 'Failed to pick image. Please try again.');
    }
  };

  const saveProfile = () => {
    if (!companyName.trim() || !ceoName.trim()) {
      showWebAlert('Error', 'Company name and CEO name are required');
      return;
    }

    if (companyName.length < 2) {
      showWebAlert('Error', 'Company name must be at least 2 characters long');
      return;
    }

    if (ceoName.length < 2) {
      showWebAlert('Error', 'CEO name must be at least 2 characters long');
      return;
    }

    dispatch({
      type: 'SET_COMPANY',
      payload: {
        name: companyName.trim(),
        ceo: ceoName.trim(),
        logo: companyLogo,
      }
    });

    dispatch({ 
      type: 'ADD_NOTIFICATION', 
      payload: { 
        type: 'info', 
        message: '✅ Company profile updated successfully!',
        id: Date.now().toString()
      }
    });
  };

  const saveSettings = () => {
    dispatch({
      type: 'UPDATE_SETTINGS',
      payload: {
        autoSave,
        soundEnabled,
        gameSpeed,
      }
    });

    dispatch({ 
      type: 'ADD_NOTIFICATION', 
      payload: { 
        type: 'info', 
        message: '⚙️ Game settings saved successfully!',
        id: Date.now().toString()
      }
    });
  };

  const exportSave = async () => {
    try {
      const gameData = JSON.stringify(state, null, 2);
      const timestamp = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
      const filename = `MobileTycoon_${state.company.name.replace(/\s+/g, '_')}_${timestamp}.json`;
      
      if (Platform.OS === 'web') {
        const blob = new Blob([gameData], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }
      
      await AsyncStorage.setItem(`backup_${timestamp}`, gameData);
      
      dispatch({ 
        type: 'ADD_NOTIFICATION', 
        payload: { 
          type: 'info', 
          message: '💾 Game save exported successfully!',
          id: Date.now().toString()
        }
      });
    } catch (error) {
      showWebAlert('Error', 'Failed to export save file. Please try again.');
    }
  };

  const deleteProfile = async () => {
    try {
      const keys = await AsyncStorage.getAllKeys();
      const gameKeys = keys.filter(key => 
        key.startsWith('mobileCaribbean_') || 
        key.startsWith('user_') ||
        key.startsWith('backup_')
      );
      await AsyncStorage.multiRemove(gameKeys);
      
      setShowDeleteConfirm(false);
      
      dispatch({ 
        type: 'ADD_NOTIFICATION', 
        payload: { 
          type: 'info', 
          message: '🗑️ Profile deleted successfully',
          id: Date.now().toString()
        }
      });
      
      dispatch({ type: 'RESET_GAME' });
      
      setTimeout(() => {
        router.replace('/');
      }, 1000);
    } catch (error) {
      showWebAlert('Error', 'Failed to delete profile. Please try again.');
    }
  };

  const logout = () => {
    showWebAlert('Logout Confirmation', 'Are you sure you want to logout? Your progress will be saved automatically.', () => {
      dispatch({ 
        type: 'ADD_NOTIFICATION', 
        payload: { 
          type: 'info', 
          message: '👋 Logged out successfully',
          id: Date.now().toString()
        }
      });
      router.replace('/');
    });
  };

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#000000', '#8B0040', '#006400']} style={styles.background}>
        <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
          <BlurView intensity={15} style={styles.section}>
            <View style={styles.sectionHeader}>
              <MaterialIcons name="business" size={36} color="#4DD0E1" />
              <Text style={styles.sectionTitle}>Company Profile</Text>
            </View>
            
            <View style={styles.logoSection}>
              <TouchableOpacity style={styles.logoContainer} onPress={pickImage}>
                {companyLogo ? (
                  <Image source={{ uri: companyLogo }} style={styles.logoImage} />
                ) : (
                  <View style={styles.logoPlaceholder}>
                    <MaterialIcons name="add-photo-alternate" size={48} color="rgba(255,255,255,0.6)" />
                    <Text style={styles.logoText}>Upload Logo</Text>
                  </View>
                )}
              </TouchableOpacity>
              <Text style={styles.logoHint}>Tap to change company logo (Max 5MB)</Text>
              <Text style={styles.logoFormats}>Supported: JPG, PNG, GIF</Text>
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.label}>Company Name</Text>
              <TextInput
                style={styles.input}
                value={companyName}
                onChangeText={setCompanyName}
                placeholder="Enter company name"
                placeholderTextColor="rgba(255,255,255,0.6)"
                maxLength={50}
              />
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.label}>CEO / President</Text>
              <TextInput
                style={styles.input}
                value={ceoName}
                onChangeText={setCeoName}
                placeholder="Enter CEO name"
                placeholderTextColor="rgba(255,255,255,0.6)"
                maxLength={30}
              />
            </View>

            <TouchableOpacity style={styles.saveButton} onPress={saveProfile}>
              <MaterialIcons name="save" size={30} color="white" />
              <Text style={styles.buttonText}>Save Profile</Text>
            </TouchableOpacity>
          </BlurView>

          <BlurView intensity={15} style={styles.section}>
            <View style={styles.sectionHeader}>
              <MaterialIcons name="settings" size={36} color="#4DD0E1" />
              <Text style={styles.sectionTitle}>Game Preferences</Text>
            </View>

            <View style={styles.preferenceRow}>
              <View style={styles.preferenceInfo}>
                <Text style={styles.preferenceLabel}>Auto-Save</Text>
                <Text style={styles.preferenceDescription}>Automatically save progress every 30 seconds</Text>
              </View>
              <TouchableOpacity
                style={[styles.toggle, autoSave && styles.toggleActive]}
                onPress={() => setAutoSave(!autoSave)}
              >
                <View style={[styles.toggleSlider, autoSave && styles.toggleSliderActive]} />
              </TouchableOpacity>
            </View>

            <View style={styles.preferenceRow}>
              <View style={styles.preferenceInfo}>
                <Text style={styles.preferenceLabel}>Sound Effects</Text>
                <Text style={styles.preferenceDescription}>Enable game sounds and notifications</Text>
              </View>
              <TouchableOpacity
                style={[styles.toggle, soundEnabled && styles.toggleActive]}
                onPress={() => setSoundEnabled(!soundEnabled)}
              >
                <View style={[styles.toggleSlider, soundEnabled && styles.toggleSliderActive]} />
              </TouchableOpacity>
            </View>

            <View style={styles.speedSection}>
              <Text style={styles.preferenceLabel}>Game Speed</Text>
              <Text style={styles.preferenceDescription}>
                {gameSpeed === 2466 ? 'Fast (2x Speed - 15 min/year)' : 
                 gameSpeed === 4932 ? 'Normal (1x Speed - 30 min/year)' : 
                 'Slow (0.5x Speed - 60 min/year)'}
              </Text>
              <View style={styles.speedButtons}>
                <TouchableOpacity
                  style={[styles.speedButton, gameSpeed === 9864 && styles.speedButtonActive]}
                  onPress={() => setGameSpeed(9864)}
                >
                  <Text style={styles.speedButtonText}>0.5x</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.speedButton, gameSpeed === 4932 && styles.speedButtonActive]}
                  onPress={() => setGameSpeed(4932)}
                >
                  <Text style={styles.speedButtonText}>1x</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.speedButton, gameSpeed === 2466 && styles.speedButtonActive]}
                  onPress={() => setGameSpeed(2466)}
                >
                  <Text style={styles.speedButtonText}>2x</Text>
                </TouchableOpacity>
              </View>
            </View>

            <TouchableOpacity style={styles.saveButton} onPress={saveSettings}>
              <MaterialIcons name="check" size={30} color="white" />
              <Text style={styles.buttonText}>Save Settings</Text>
            </TouchableOpacity>
          </BlurView>

          <BlurView intensity={15} style={styles.section}>
            <View style={styles.sectionHeader}>
              <MaterialIcons name="storage" size={36} color="#4DD0E1" />
              <Text style={styles.sectionTitle}>Data Management</Text>
            </View>

            <TouchableOpacity style={styles.actionButton} onPress={exportSave}>
              <MaterialIcons name="download" size={30} color="white" />
              <View style={styles.actionInfo}>
                <Text style={styles.actionLabel}>Export Save File</Text>
                <Text style={styles.actionDescription}>Download backup of your game progress</Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity style={styles.actionButton} onPress={logout}>
              <MaterialIcons name="logout" size={30} color="white" />
              <View style={styles.actionInfo}>
                <Text style={styles.actionLabel}>Logout</Text>
                <Text style={styles.actionDescription}>Return to login screen (auto-saves first)</Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity 
              style={[styles.actionButton, styles.dangerButton]} 
              onPress={() => setShowDeleteConfirm(true)}
            >
              <MaterialIcons name="delete-forever" size={30} color="white" />
              <View style={styles.actionInfo}>
                <Text style={styles.actionLabel}>Delete Profile</Text>
                <Text style={styles.actionDescription}>Permanently remove all data and backups</Text>
              </View>
            </TouchableOpacity>
          </BlurView>

          <BlurView intensity={15} style={styles.section}>
            <View style={styles.sectionHeader}>
              <MaterialIcons name="info" size={36} color="#4DD0E1" />
              <Text style={styles.sectionTitle}>System Information</Text>
            </View>
            
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Game Version:</Text>
              <Text style={styles.infoValue}>1.0.0</Text>
            </View>
            
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Platform:</Text>
              <Text style={styles.infoValue}>{Platform.OS.toUpperCase()}</Text>
            </View>
            
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Game Time:</Text>
              <Text style={styles.infoValue}>
                {state.gameDate.toLocaleDateString('en-US', { 
                  month: 'long', 
                  day: 'numeric', 
                  year: 'numeric' 
                })}
              </Text>
            </View>
            
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Session:</Text>
              <Text style={styles.infoValue}>
                {state.isPaused ? '⏸️ Paused' : '▶️ Running'}
              </Text>
            </View>
          </BlurView>
        </ScrollView>

        <Modal visible={showDeleteConfirm} transparent animationType="fade">
          <View style={styles.modalOverlay}>
            <BlurView intensity={50} style={styles.modalContent}>
              <MaterialIcons name="warning" size={72} color="#F44336" />
              <Text style={styles.modalTitle}>Delete Profile Forever?</Text>
              <Text style={styles.modalMessage}>
                This will permanently delete your entire profile, company data, game progress, and all backup saves. This action cannot be undone.
              </Text>
              <Text style={styles.modalWarning}>
                ⚠️ You will lose everything and return to the login screen.
              </Text>
              
              <View style={styles.modalButtons}>
                <TouchableOpacity
                  style={styles.modalCancelButton}
                  onPress={() => setShowDeleteConfirm(false)}
                >
                  <Text style={styles.modalCancelText}>Cancel</Text>
                </TouchableOpacity>
                
                <TouchableOpacity
                  style={styles.modalDeleteButton}
                  onPress={deleteProfile}
                >
                  <Text style={styles.modalDeleteText}>Delete Forever</Text>
                </TouchableOpacity>
              </View>
            </BlurView>
          </View>
        </Modal>

        {Platform.OS === 'web' && (
          <Modal visible={alertConfig.visible} transparent animationType="fade">
            <View style={styles.alertOverlay}>
              <View style={styles.alertBox}>
                <Text style={styles.alertTitle}>{alertConfig.title}</Text>
                <Text style={styles.alertMessage}>{alertConfig.message}</Text>
                <TouchableOpacity 
                  style={styles.alertButton}
                  onPress={() => {
                    alertConfig.onOk?.();
                    setAlertConfig(prev => ({ ...prev, visible: false }));
                  }}
                >
                  <Text style={styles.alertButtonText}>OK</Text>
                </TouchableOpacity>
              </View>
            </View>
          </Modal>
        )}
      </LinearGradient>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
    padding: 30,
  },
  section: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 24,
    padding: 30,
    marginBottom: 30,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 30,
    gap: 18,
  },
  sectionTitle: {
    fontSize: 30,
    fontWeight: 'bold',
    color: 'white',
  },
  logoSection: {
    alignItems: 'center',
    marginBottom: 30,
  },
  logoContainer: {
    width: 150,
    height: 150,
    borderRadius: 75,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderWidth: 3,
    borderColor: 'rgba(255,255,255,0.2)',
    borderStyle: 'dashed',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  logoImage: {
    width: '100%',
    height: '100%',
    borderRadius: 75,
  },
  logoPlaceholder: {
    alignItems: 'center',
    gap: 6,
  },
  logoText: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 18,
    fontWeight: 'bold',
  },
  logoHint: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  logoFormats: {
    color: 'rgba(255,255,255,0.4)',
    fontSize: 15,
    fontWeight: 'bold',
    textAlign: 'center',
    marginTop: 3,
  },
  inputContainer: {
    marginBottom: 24,
  },
  label: {
    fontSize: 21,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 12,
  },
  input: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 12,
    padding: 18,
    fontSize: 24,
    color: 'white',
    fontWeight: 'bold',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
  },
  saveButton: {
    backgroundColor: '#00ACC1',
    borderRadius: 12,
    padding: 18,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
    marginTop: 12,
  },
  buttonText: {
    color: 'white',
    fontSize: 24,
    fontWeight: 'bold',
  },
  preferenceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 18,
  },
  preferenceInfo: {
    flex: 1,
  },
  preferenceLabel: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
  },
  preferenceDescription: {
    fontSize: 18,
    color: 'rgba(255,255,255,0.6)',
    fontWeight: 'bold',
    marginTop: 3,
  },
  toggle: {
    width: 75,
    height: 45,
    borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.2)',
    padding: 3,
    justifyContent: 'center',
  },
  toggleActive: {
    backgroundColor: '#4CAF50',
  },
  toggleSlider: {
    width: 39,
    height: 39,
    borderRadius: 19,
    backgroundColor: 'white',
    alignSelf: 'flex-start',
  },
  toggleSliderActive: {
    alignSelf: 'flex-end',
  },
  speedSection: {
    paddingTop: 18,
  },
  speedButtons: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 12,
  },
  speedButton: {
    flex: 1,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 12,
    padding: 12,
    alignItems: 'center',
  },
  speedButtonActive: {
    backgroundColor: '#4DD0E1',
  },
  speedButtonText: {
    color: 'white',
    fontSize: 21,
    fontWeight: 'bold',
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 12,
    padding: 24,
    marginBottom: 18,
    gap: 18,
  },
  dangerButton: {
    backgroundColor: 'rgba(244,67,54,0.2)',
    borderWidth: 1,
    borderColor: 'rgba(244,67,54,0.3)',
  },
  actionInfo: {
    flex: 1,
  },
  actionLabel: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
  },
  actionDescription: {
    fontSize: 18,
    color: 'rgba(255,255,255,0.6)',
    fontWeight: 'bold',
    marginTop: 3,
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
  },
  infoLabel: {
    fontSize: 21,
    fontWeight: 'bold',
    color: 'rgba(255,255,255,0.8)',
  },
  infoValue: {
    fontSize: 21,
    fontWeight: 'bold',
    color: 'white',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.7)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    width: '90%',
    maxWidth: 600,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 30,
    padding: 36,
    alignItems: 'center',
  },
  modalTitle: {
    fontSize: 30,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
    marginTop: 24,
    marginBottom: 18,
  },
  modalMessage: {
    fontSize: 21,
    color: 'rgba(255,255,255,0.8)',
    textAlign: 'center',
    lineHeight: 30,
    marginBottom: 18,
    fontWeight: 'bold',
  },
  modalWarning: {
    fontSize: 18,
    color: '#F44336',
    textAlign: 'center',
    fontWeight: 'bold',
    marginBottom: 36,
  },
  modalButtons: {
    flexDirection: 'row',
    gap: 18,
    width: '100%',
  },
  modalCancelButton: {
    flex: 1,
    backgroundColor: 'rgba(255,255,255,0.2)',
    paddingVertical: 18,
    borderRadius: 12,
    alignItems: 'center',
  },
  modalCancelText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
  },
  modalDeleteButton: {
    flex: 1,
    backgroundColor: '#F44336',
    paddingVertical: 18,
    borderRadius: 12,
    alignItems: 'center',
  },
  modalDeleteText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
  },
  alertOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  alertBox: {
    backgroundColor: 'white',
    padding: 30,
    borderRadius: 12,
    minWidth: 420,
  },
  alertTitle: {
    fontSize: 27,
    fontWeight: 'bold',
    marginBottom: 15,
    color: 'black',
  },
  alertMessage: {
    fontSize: 24,
    marginBottom: 30,
    color: 'black',
  },
  alertButton: {
    backgroundColor: '#007AFF',
    padding: 15,
    borderRadius: 6,
    alignItems: 'center',
  },
  alertButtonText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 21,
  },
});