import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Modal } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { MaterialIcons } from '@expo/vector-icons';
import { useGame } from '../../../hooks/useGame';

interface ResearchProject {
  id: string;
  name: string;
  category: 'network' | 'services' | 'efficiency' | 'innovation';
  description: string;
  cost: number;
  duration: number; // in days
  progress: number; // 0-100
  benefits: string[];
  isCompleted: boolean;
  isActive: boolean;
  startDate?: Date;
  completionDate?: Date;
  requirements?: string[];
}

const researchProjects: Omit<ResearchProject, 'id' | 'progress' | 'isCompleted' | 'isActive'>[] = [
  // Network Category
  {
    name: '5G Infrastructure',
    category: 'network',
    description: 'Develop advanced 5G network capabilities for ultra-fast data speeds',
    cost: 5000000,
    duration: 120,
    benefits: ['300% data speed increase', '+50% network capacity', 'Premium service tier access'],
    requirements: ['Advanced Cell Towers', 'Network Engineers']
  },
  {
    name: 'Network Optimization AI',
    category: 'network',
    description: 'AI-powered network optimization for improved efficiency and coverage',
    cost: 2500000,
    duration: 90,
    benefits: ['+25% network efficiency', 'Automated load balancing', '-20% maintenance costs'],
    requirements: ['Data Controllers', 'Technical Staff']
  },
  {
    name: 'Satellite Backhaul',
    category: 'network',
    description: 'Satellite-based network backhaul for remote area coverage',
    cost: 8000000,
    duration: 180,
    benefits: ['Remote area coverage', '+100% network reach', 'Disaster resilience'],
    requirements: ['Spectrum License', 'Engineering Team']
  },

  // Services Category
  {
    name: 'IoT Platform',
    category: 'services',
    description: 'Internet of Things platform for smart device connectivity',
    cost: 3000000,
    duration: 150,
    benefits: ['New IoT revenue stream', 'Business customer attraction', '+40% ARPU'],
    requirements: ['Data Network', 'Software Engineers']
  },
  {
    name: 'Cloud Services',
    category: 'services',
    description: 'Enterprise cloud computing and storage services',
    cost: 4500000,
    duration: 100,
    benefits: ['Enterprise market access', '+60% business ARPU', 'Data center revenue'],
    requirements: ['Server Infrastructure', 'Technical Team']
  },
  {
    name: 'Mobile Payment System',
    category: 'services',
    description: 'Integrated mobile payment and financial services platform',
    cost: 6000000,
    duration: 200,
    benefits: ['Financial services revenue', '+80% customer retention', 'Transaction fees'],
    requirements: ['Security Compliance', 'Financial License']
  },

  // Efficiency Category
  {
    name: 'Automated Customer Service',
    category: 'efficiency',
    description: 'AI-powered chatbots and automated customer support systems',
    cost: 1500000,
    duration: 60,
    benefits: ['-60% support costs', '24/7 customer service', '+30% satisfaction'],
    requirements: ['Customer Service Team', 'Data Analytics']
  },
  {
    name: 'Predictive Maintenance',
    category: 'efficiency',
    description: 'AI-driven predictive maintenance for network infrastructure',
    cost: 2000000,
    duration: 75,
    benefits: ['-40% maintenance costs', '+95% network uptime', 'Proactive repairs'],
    requirements: ['Infrastructure', 'Data Collection Systems']
  },
  {
    name: 'Energy Optimization',
    category: 'efficiency',
    description: 'Smart energy management systems for reduced operational costs',
    cost: 1800000,
    duration: 90,
    benefits: ['-30% energy costs', 'Green energy integration', 'Carbon footprint reduction'],
    requirements: ['Infrastructure', 'Environmental Compliance']
  },

  // Innovation Category
  {
    name: 'Augmented Reality Services',
    category: 'innovation',
    description: 'AR/VR services and content delivery platform',
    cost: 7000000,
    duration: 240,
    benefits: ['Premium AR/VR services', 'Entertainment market', '+200% data usage'],
    requirements: ['5G Network', 'Content Partnerships']
  },
  {
    name: 'Quantum Encryption',
    category: 'innovation',
    description: 'Quantum-level security for ultra-secure communications',
    cost: 10000000,
    duration: 300,
    benefits: ['Military/Government contracts', 'Premium security services', 'Competitive advantage'],
    requirements: ['Advanced Security Team', 'Research Partnerships']
  },
  {
    name: 'Smart City Integration',
    category: 'innovation',
    description: 'Integrated smart city infrastructure and services platform',
    cost: 12000000,
    duration: 360,
    benefits: ['Government contracts', 'Smart city revenue', 'Infrastructure partnerships'],
    requirements: ['IoT Platform', 'Government Relations']
  }
];

export default function ResearchTab() {
  const { state, dispatch } = useGame();
  const [projects, setProjects] = useState<ResearchProject[]>(() => 
    researchProjects.map(project => ({
      ...project,
      id: `research_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      progress: 0,
      isCompleted: false,
      isActive: false
    }))
  );
  
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'network' | 'services' | 'efficiency' | 'innovation'>('all');
  const [showProjectModal, setShowProjectModal] = useState(false);
  const [selectedProject, setSelectedProject] = useState<ResearchProject | null>(null);

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'network': return 'network-cell';
      case 'services': return 'featured-play-list';
      case 'efficiency': return 'speed';
      case 'innovation': return 'lightbulb-outline';
      default: return 'science';
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'network': return '#4CAF50';
      case 'services': return '#2196F3';
      case 'efficiency': return '#FF9800';
      case 'innovation': return '#9C27B0';
      default: return '#757575';
    }
  };

  const formatCurrency = (amount: number) => {
    if (amount >= 1000000) return `$${(amount / 1000000).toFixed(1)}M`;
    if (amount >= 1000) return `$${(amount / 1000).toFixed(0)}K`;
    return `$${amount.toLocaleString()}`;
  };

  const formatDuration = (days: number) => {
    if (days >= 365) return `${(days / 365).toFixed(1)} years`;
    if (days >= 30) return `${Math.round(days / 30)} months`;
    return `${days} days`;
  };

  const startResearch = (project: ResearchProject) => {
    if (state.company.capital < project.cost) {
      dispatch({ 
        type: 'ADD_NOTIFICATION', 
        payload: { 
          type: 'error', 
          message: `Insufficient funds for ${project.name}. Need ${formatCurrency(project.cost)}`,
          id: Date.now().toString()
        }
      });
      return;
    }

    // Check if another project in same category is already active
    const activeInCategory = projects.find(p => p.category === project.category && p.isActive);
    if (activeInCategory) {
      dispatch({ 
        type: 'ADD_NOTIFICATION', 
        payload: { 
          type: 'warning', 
          message: `Complete "${activeInCategory.name}" before starting new ${project.category} research`,
          id: Date.now().toString()
        }
      });
      return;
    }

    // Deduct cost and start project
    dispatch({ type: 'SPEND_CAPITAL', payload: project.cost });
    
    setProjects(prev => prev.map(p => 
      p.id === project.id 
        ? { ...p, isActive: true, startDate: new Date(state.gameDate) }
        : p
    ));

    dispatch({ 
      type: 'ADD_NOTIFICATION', 
      payload: { 
        type: 'info', 
        message: `Research started: ${project.name} (${formatDuration(project.duration)})`,
        id: Date.now().toString()
      }
    });

    setShowProjectModal(false);
  };

  const cancelResearch = (projectId: string) => {
    const project = projects.find(p => p.id === projectId);
    if (!project) return;

    // Refund 70% of cost
    const refund = Math.round(project.cost * 0.7);
    dispatch({ type: 'ADD_CAPITAL', payload: refund });
    
    setProjects(prev => prev.map(p => 
      p.id === projectId 
        ? { ...p, isActive: false, progress: 0, startDate: undefined }
        : p
    ));

    dispatch({ 
      type: 'ADD_NOTIFICATION', 
      payload: { 
        type: 'info', 
        message: `Research cancelled: ${project.name}. Refunded ${formatCurrency(refund)}`,
        id: Date.now().toString()
      }
    });
  };

  // Simulate research progress
  React.useEffect(() => {
    if (state.isPaused) return;

    const interval = setInterval(() => {
      setProjects(prev => prev.map(project => {
        if (!project.isActive || project.isCompleted) return project;

        const dailyProgress = 100 / project.duration; // Progress per day
        const newProgress = Math.min(100, project.progress + dailyProgress);
        
        if (newProgress >= 100) {
          // Research completed
          dispatch({ 
            type: 'ADD_NOTIFICATION', 
            payload: { 
              type: 'info', 
              message: `🎉 Research completed: ${project.name}! Benefits unlocked.`,
              id: Date.now().toString()
            }
          });

          return {
            ...project,
            progress: 100,
            isCompleted: true,
            isActive: false,
            completionDate: new Date(state.gameDate)
          };
        }

        return { ...project, progress: newProgress };
      }));
    }, state.gameSpeed);

    return () => clearInterval(interval);
  }, [state.isPaused, state.gameSpeed, state.gameDate, dispatch]);

  const filteredProjects = selectedCategory === 'all' 
    ? projects 
    : projects.filter(project => project.category === selectedCategory);

  const researchStats = {
    totalProjects: projects.length,
    activeProjects: projects.filter(p => p.isActive).length,
    completedProjects: projects.filter(p => p.isCompleted).length,
    totalInvestment: projects.filter(p => p.isActive || p.isCompleted).reduce((sum, p) => sum + p.cost, 0)
  };

  return (
        <View style={styles.container}>
      <LinearGradient colors={['#000000', '#8B0040', '#006400']} style={styles.background}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Research & Development</Text>
          <Text style={styles.subtitle}>Invest in technology to gain competitive advantages</Text>
        </View>

        {/* Research Statistics */}
        <BlurView intensity={15} style={styles.statsGrid}>
          <View style={styles.statCard}>
            <MaterialIcons name="science" size={24} color="#4DD0E1" />
            <Text style={styles.statValue}>{researchStats.totalProjects}</Text>
            <Text style={styles.statLabel}>Available Projects</Text>
          </View>
          
          <View style={styles.statCard}>
            <MaterialIcons name="trending-up" size={24} color="#FF9800" />
            <Text style={styles.statValue}>{researchStats.activeProjects}</Text>
            <Text style={styles.statLabel}>Active Research</Text>
          </View>
          
          <View style={styles.statCard}>
            <MaterialIcons name="check-circle" size={24} color="#4CAF50" />
            <Text style={styles.statValue}>{researchStats.completedProjects}</Text>
            <Text style={styles.statLabel}>Completed</Text>
          </View>
          
          <View style={styles.statCard}>
            <MaterialIcons name="attach-money" size={24} color="#2196F3" />
            <Text style={styles.statValue}>{formatCurrency(researchStats.totalInvestment)}</Text>
            <Text style={styles.statLabel}>Total Investment</Text>
          </View>
        </BlurView>

        {/* Category Filter */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.categoryFilter}>
          {['all', 'network', 'services', 'efficiency', 'innovation'].map(category => (
            <TouchableOpacity
              key={category}
              style={[styles.categoryButton, selectedCategory === category && styles.categoryButtonActive]}
              onPress={() => setSelectedCategory(category as any)}
            >
              <MaterialIcons 
                name={getCategoryIcon(category)} 
                size={16} 
                color={selectedCategory === category ? 'white' : 'rgba(255,255,255,0.8)'} 
              />
              <Text style={[styles.categoryText, selectedCategory === category && styles.categoryTextActive]}>
                {category.charAt(0).toUpperCase() + category.slice(1)}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {/* Research Projects List */}
        <ScrollView style={styles.projectsList} showsVerticalScrollIndicator={false}>
          {filteredProjects.map(project => (
            <BlurView key={project.id} intensity={15} style={styles.projectCard}>
              <TouchableOpacity 
                style={styles.projectContent}
                onPress={() => {
                  setSelectedProject(project);
                  setShowProjectModal(true);
                }}
                activeOpacity={0.8}
              >
                <View style={styles.projectHeader}>
                  <View style={styles.projectInfo}>
                    <View style={styles.projectTitleRow}>
                      <MaterialIcons 
                        name={getCategoryIcon(project.category)} 
                        size={24} 
                        color={getCategoryColor(project.category)} 
                      />
                      <Text style={styles.projectName}>{project.name}</Text>
                      {project.isCompleted && (
                        <MaterialIcons name="check-circle" size={20} color="#4CAF50" />
                      )}
                      {project.isActive && (
                        <MaterialIcons name="science" size={20} color="#FF9800" />
                      )}
                    </View>
                    <Text style={styles.projectDescription}>{project.description}</Text>
                  </View>
                </View>

                <View style={styles.projectDetails}>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>Cost:</Text>
                    <Text style={styles.detailValue}>{formatCurrency(project.cost)}</Text>
                  </View>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>Duration:</Text>
                    <Text style={styles.detailValue}>{formatDuration(project.duration)}</Text>
                  </View>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>Category:</Text>
                    <Text style={[styles.detailValue, { color: getCategoryColor(project.category) }]}>
                      {project.category.toUpperCase()}
                    </Text>
                  </View>
                </View>

                {(project.isActive || project.isCompleted) && (
                  <View style={styles.progressContainer}>
                    <View style={styles.progressHeader}>
                      <Text style={styles.progressLabel}>Progress:</Text>
                      <Text style={styles.progressValue}>{project.progress.toFixed(1)}%</Text>
                    </View>
                    <View style={styles.progressBar}>
                      <View 
                        style={[
                          styles.progressFill, 
                          { 
                            width: `${project.progress}%`,
                            backgroundColor: project.isCompleted ? '#4CAF50' : '#FF9800'
                          }
                        ]} 
                      />
                    </View>
                  </View>
                )}

                <View style={styles.benefitsList}>
                  <Text style={styles.benefitsTitle}>Benefits:</Text>
                  {project.benefits.slice(0, 2).map((benefit, index) => (
                    <Text key={index} style={styles.benefitItem}>• {benefit}</Text>
                  ))}
                  {project.benefits.length > 2 && (
                    <Text style={styles.moreBenefits}>+{project.benefits.length - 2} more benefits</Text>
                  )}
                </View>

                {project.isActive && (
                  <View style={styles.projectActions}>
                    <TouchableOpacity 
                      style={styles.cancelButton}
                      onPress={(e) => {
                        e.stopPropagation();
                        cancelResearch(project.id);
                      }}
                    >
                      <MaterialIcons name="cancel" size={16} color="white" />
                      <Text style={styles.cancelButtonText}>Cancel (70% refund)</Text>
                    </TouchableOpacity>
                  </View>
                )}
              </TouchableOpacity>
            </BlurView>
          ))}
        </ScrollView>

        {/* Project Details Modal */}
        {selectedProject && (
          <Modal visible={showProjectModal} transparent animationType="fade">
            <View style={styles.modalOverlay}>
              <BlurView intensity={40} style={styles.modalContent}>
                <View style={styles.modalHeader}>
                  <View style={styles.modalTitleSection}>
                    <MaterialIcons 
                      name={getCategoryIcon(selectedProject.category)} 
                      size={28} 
                      color={getCategoryColor(selectedProject.category)} 
                    />
                    <Text style={styles.modalTitle}>{selectedProject.name}</Text>
                  </View>
                  <TouchableOpacity onPress={() => setShowProjectModal(false)}>
                    <MaterialIcons name="close" size={24} color="white" />
                  </TouchableOpacity>
                </View>

                <ScrollView style={styles.modalBody}>
                  <Text style={styles.modalDescription}>{selectedProject.description}</Text>
                  
                  <View style={styles.modalDetailsSection}>
                    <Text style={styles.modalSectionTitle}>Project Details</Text>
                    <View style={styles.modalDetailRow}>
                      <Text style={styles.modalDetailLabel}>Investment Required:</Text>
                      <Text style={styles.modalDetailValue}>{formatCurrency(selectedProject.cost)}</Text>
                    </View>
                    <View style={styles.modalDetailRow}>
                      <Text style={styles.modalDetailLabel}>Research Duration:</Text>
                      <Text style={styles.modalDetailValue}>{formatDuration(selectedProject.duration)}</Text>
                    </View>
                    <View style={styles.modalDetailRow}>
                      <Text style={styles.modalDetailLabel}>Category:</Text>
                      <Text style={[styles.modalDetailValue, { color: getCategoryColor(selectedProject.category) }]}>
                        {selectedProject.category.toUpperCase()}
                      </Text>
                    </View>
                  </View>

                  <View style={styles.modalBenefitsSection}>
                    <Text style={styles.modalSectionTitle}>Benefits & Advantages</Text>
                    {selectedProject.benefits.map((benefit, index) => (
                      <View key={index} style={styles.modalBenefitRow}>
                        <MaterialIcons name="check-circle" size={16} color="#4CAF50" />
                        <Text style={styles.modalBenefitText}>{benefit}</Text>
                      </View>
                    ))}
                  </View>

                  {selectedProject.requirements && (
                    <View style={styles.modalRequirementsSection}>
                      <Text style={styles.modalSectionTitle}>Requirements</Text>
                      {selectedProject.requirements.map((requirement, index) => (
                        <View key={index} style={styles.modalRequirementRow}>
                          <MaterialIcons name="info" size={16} color="#2196F3" />
                          <Text style={styles.modalRequirementText}>{requirement}</Text>
                        </View>
                      ))}
                    </View>
                  )}

                  {selectedProject.isActive && (
                    <View style={styles.modalProgressSection}>
                      <Text style={styles.modalSectionTitle}>Research Progress</Text>
                      <View style={styles.modalProgressBar}>
                        <View 
                          style={[
                            styles.modalProgressFill, 
                            { 
                              width: `${selectedProject.progress}%`,
                              backgroundColor: '#FF9800'
                            }
                          ]} 
                        />
                      </View>
                      <Text style={styles.modalProgressText}>
                        {selectedProject.progress.toFixed(1)}% Complete
                      </Text>
                    </View>
                  )}
                </ScrollView>

                {!selectedProject.isActive && !selectedProject.isCompleted && (
                  <View style={styles.modalButtons}>
                    <TouchableOpacity
                      style={styles.modalCancelButton}
                      onPress={() => setShowProjectModal(false)}
                    >
                      <Text style={styles.modalCancelText}>Close</Text>
                    </TouchableOpacity>
                    
                    <TouchableOpacity
                      style={[
                        styles.modalStartButton,
                        state.company.capital < selectedProject.cost && styles.modalButtonDisabled
                      ]}
                      onPress={() => startResearch(selectedProject)}
                      disabled={state.company.capital < selectedProject.cost}
                    >
                      <Text style={styles.modalStartText}>Start Research</Text>
                    </TouchableOpacity>
                  </View>
                )}

                {selectedProject.isCompleted && (
                  <View style={styles.completedBanner}>
                    <MaterialIcons name="check-circle" size={24} color="#4CAF50" />
                    <Text style={styles.completedText}>Research Completed!</Text>
                  </View>
                )}
              </BlurView>
            </View>
          </Modal>
        )}
      </LinearGradient>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
  },
  header: {
    padding: 20,
    alignItems: 'center',
  },
  title: {
    fontSize: 36,
    fontWeight: 'bold',
    color: 'white',
  },
  subtitle: {
    fontSize: 24,
    color: 'rgba(255,255,255,0.8)',
    textAlign: 'center',
    marginTop: 6,
    fontWeight: 'bold',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 16,
    padding: 16,
    marginHorizontal: 20,
    marginBottom: 20,
  },
  statCard: {
    width: '48%',
    alignItems: 'center',
    marginBottom: 16,
  },
  statValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
    marginTop: 8,
    textAlign: 'center',
  },
  statLabel: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
    textAlign: 'center',
    marginTop: 4,
  },
  categoryFilter: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  categoryButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 20,
    marginRight: 8,
  },
  categoryButtonActive: {
    backgroundColor: '#4DD0E1',
  },
  categoryText: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
  },
  categoryTextActive: {
    color: 'white',
  },
  projectsList: {
    flex: 1,
    paddingHorizontal: 20,
  },
  projectCard: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 16,
    marginBottom: 16,
    overflow: 'hidden',
  },
  projectContent: {
    padding: 16,
  },
  projectHeader: {
    marginBottom: 12,
  },
  projectInfo: {
    flex: 1,
  },
  projectTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 8,
  },
  projectName: {
    flex: 1,
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
  },
  projectDescription: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
    lineHeight: 20,
  },
  projectDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  detailRow: {
    alignItems: 'center',
  },
  detailLabel: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.6)',
    fontWeight: 'bold',
  },
  detailValue: {
    fontSize: 14,
    fontWeight: 'bold',
    color: 'white',
    marginTop: 2,
  },
  progressContainer: {
    marginBottom: 12,
  },
  progressHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 6,
  },
  progressLabel: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
  },
  progressValue: {
    fontSize: 12,
    fontWeight: 'bold',
    color: 'white',
  },
  progressBar: {
    height: 8,
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 4,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    borderRadius: 4,
  },
  benefitsList: {
    marginBottom: 12,
  },
  benefitsTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#4DD0E1',
    marginBottom: 6,
  },
  benefitItem: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
    marginBottom: 2,
  },
  moreBenefits: {
    fontSize: 12,
    color: '#4DD0E1',
    fontWeight: 'bold',
    fontStyle: 'italic',
  },
  projectActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
  cancelButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: '#F44336',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
  },
  cancelButtonText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: 'white',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.8)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    width: '90%',
    maxWidth: 500,
    maxHeight: '90%',
    backgroundColor: 'rgba(0,77,64,0.95)',
    borderRadius: 20,
    overflow: 'hidden',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.2)',
  },
  modalTitleSection: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white',
    flex: 1,
  },
  modalBody: {
    flex: 1,
    padding: 20,
  },
  modalDescription: {
    fontSize: 16,
    color: 'rgba(255,255,255,0.9)',
    fontWeight: 'bold',
    lineHeight: 24,
    marginBottom: 20,
  },
  modalDetailsSection: {
    marginBottom: 20,
  },
  modalSectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#4DD0E1',
    marginBottom: 12,
  },
  modalDetailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  modalDetailLabel: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
  },
  modalDetailValue: {
    fontSize: 14,
    fontWeight: 'bold',
    color: 'white',
  },
  modalBenefitsSection: {
    marginBottom: 20,
  },
  modalBenefitRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 8,
    marginBottom: 8,
  },
  modalBenefitText: {
    flex: 1,
    fontSize: 14,
    color: 'rgba(255,255,255,0.9)',
    fontWeight: 'bold',
    lineHeight: 20,
  },
  modalRequirementsSection: {
    marginBottom: 20,
  },
  modalRequirementRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 8,
    marginBottom: 8,
  },
  modalRequirementText: {
    flex: 1,
    fontSize: 14,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
    lineHeight: 20,
  },
  modalProgressSection: {
    marginBottom: 20,
  },
  modalProgressBar: {
    height: 12,
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 6,
    overflow: 'hidden',
    marginBottom: 8,
  },
  modalProgressFill: {
    height: '100%',
    borderRadius: 6,
  },
  modalProgressText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
  },
  modalButtons: {
    flexDirection: 'row',
    gap: 12,
    padding: 20,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.2)',
  },
  modalCancelButton: {
    flex: 1,
    backgroundColor: 'rgba(255,255,255,0.2)',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  modalCancelText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'white',
  },
  modalStartButton: {
    flex: 1,
    backgroundColor: '#00ACC1',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  modalButtonDisabled: {
    backgroundColor: 'rgba(255,255,255,0.3)',
  },
  modalStartText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'white',
  },
  completedBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
    backgroundColor: 'rgba(76,175,80,0.2)',
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(76,175,80,0.3)',
  },
  completedText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#4CAF50',
  },
});