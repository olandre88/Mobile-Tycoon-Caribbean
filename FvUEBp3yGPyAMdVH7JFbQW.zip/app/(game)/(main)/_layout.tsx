import React, { useState } from 'react';
import { View, Text, TouchableOpacity, ScrollView, TextInput, Modal, Platform, Alert, StyleSheet, Dimensions } from 'react-native';
import { Slot, router, usePathname } from 'expo-router';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { BlurView } from 'expo-blur';
import * as ImagePicker from 'expo-image-picker';
import { useGame } from '../../../hooks/useGame';
import LiveAcquisitionWidget from '../../../components/LiveAcquisitionWidget';

const { width: screenWidth } = Dimensions.get('window');

interface NavigationItem {
  id: string;
  name: string;
  icon: string;
  route: string;
  color: string;
}

const navigationItems: NavigationItem[] = [
  { id: 'countries', name: 'Countries', icon: 'public', route: '/(game)/(main)/', color: '#00FF00' },
  { id: 'infrastructure', name: 'Infrastructure', icon: 'cell-tower', route: '/(game)/(main)/infrastructure', color: '#00FFFF' },
  { id: 'employees', name: 'Employees', icon: 'people', route: '/(game)/(main)/employees', color: '#FF0080' },
  { id: 'markets', name: 'Markets', icon: 'analytics', route: '/(game)/(main)/markets', color: '#80FF00' },
  { id: 'budget', name: 'Budget', icon: 'account-balance-wallet', route: '/(game)/(main)/budget', color: '#FF8000' },
  { id: 'services', name: 'Services', icon: 'featured-play-list', route: '/(game)/(main)/services', color: '#8000FF' },
  { id: 'research', name: 'R&D', icon: 'science', route: '/(game)/(main)/research', color: '#FF0040' },
  { id: 'spectrum', name: 'Spectrum', icon: 'radio', route: '/(game)/(main)/spectrum', color: '#40FF00' },
  { id: 'inventory', name: 'Inventory', icon: 'inventory', route: '/(game)/(main)/inventory', color: '#00FF80' },
  { id: 'marketing', name: 'Marketing', icon: 'campaign', route: '/(game)/(main)/marketing', color: '#FF4000' },
];

function CustomHeader() {
  const { state, dispatch } = useGame();
  const pathname = usePathname();
  const insets = useSafeAreaInsets();
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [companyName, setCompanyName] = useState(state.company.name);
  const [ceoName, setCeoName] = useState(state.company.ceo);
  const [companyLogo, setCompanyLogo] = useState(state.company.logo);

  const showAlert = (title: string, message: string, onOk?: () => void) => {
    if (Platform.OS === 'web') {
      alert(`${title}: ${message}`);
      onOk?.();
    } else {
      Alert.alert(title, message, onOk ? [{ text: 'OK', onPress: onOk }] : undefined);
    }
  };

  const formatGameDate = (date: Date) => {
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  const formatCapital = (amount: number) => {
    if (amount >= 1000000) return `$${(amount / 1000000).toFixed(1)}M`;
    if (amount >= 1000) return `$${(amount / 1000).toFixed(0)}K`;
    return `$${amount.toLocaleString()}`;
  };

  const handleNavigation = (route: string) => {
    router.push(route);
    setShowMobileMenu(false);
  };

  const pickImage = async () => {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
      });

      if (!result.canceled && result.assets[0]) {
        const asset = result.assets[0];
        if (asset.fileSize && asset.fileSize > 5 * 1024 * 1024) {
          showAlert('File Too Large', 'Please select an image smaller than 5MB.');
          return;
        }
        setCompanyLogo(asset.uri);
      }
    } catch (error) {
      showAlert('Error', 'Failed to pick image. Please try again.');
    }
  };

  const saveProfile = () => {
    if (!companyName.trim() || !ceoName.trim()) {
      showAlert('Error', 'Company name and CEO name are required');
      return;
    }

    dispatch({
      type: 'SET_COMPANY',
      payload: {
        name: companyName.trim(),
        ceo: ceoName.trim(),
        logo: companyLogo,
      }
    });

    dispatch({ 
      type: 'ADD_NOTIFICATION', 
      payload: { 
        type: 'info', 
        message: 'Company profile updated successfully!',
        id: Date.now().toString()
      }
    });

    setShowProfileModal(false);
  };

  return (
    <>
      <View style={[styles.header, { paddingTop: insets.top, backgroundColor: 'white' }]}>
        <View style={styles.headerContent}>
          <TouchableOpacity onPress={() => setShowProfileModal(true)} style={styles.companySection}>
            <View style={styles.companyLogo}>
              <Text style={styles.logoText}>{state.company.name.charAt(0) || 'C'}</Text>
            </View>
            <View style={styles.companyInfo}>
              <Text style={styles.companyName} numberOfLines={1}>{state.company.name || 'Company'}</Text>
              <Text style={styles.gameDate}>{formatGameDate(state.gameDate)}</Text>
            </View>
          </TouchableOpacity>

          <View style={styles.gameStats}>
            <Text style={styles.capital}>{formatCapital(state.company.capital)}</Text>
            {state.selectedCountry && <LiveAcquisitionWidget />}
          </View>

          <View style={styles.controls}>
            <TouchableOpacity 
              style={[styles.playButton, state.isPaused ? styles.pausedButton : styles.playingButton]}
              onPress={() => dispatch({ type: 'TOGGLE_PAUSE' })}
            >
              <MaterialIcons 
                name={state.isPaused ? 'play-arrow' : 'pause'} 
                size={20} 
                color="white" 
              />
            </TouchableOpacity>

            <TouchableOpacity 
              style={styles.menuButton} 
              onPress={() => setShowMobileMenu(true)}
            >
              <MaterialIcons name="menu" size={20} color="white" />
              {state.notifications.length > 0 && (
                <View style={styles.notificationBadge}>
                  <Text style={styles.badgeText}>{state.notifications.length}</Text>
                </View>
              )}
            </TouchableOpacity>
          </View>
        </View>
      </View>

      <Modal 
        visible={showMobileMenu} 
        transparent 
        animationType={Platform.OS === 'ios' ? 'slide' : 'fade'}
        presentationStyle={Platform.OS === 'ios' ? 'pageSheet' : 'overFullScreen'}
      >
        <View style={styles.modalOverlay}>
          <View style={[styles.mobileMenu, { paddingBottom: insets.bottom }]}>
            <LinearGradient colors={['#000000', '#8B0040', '#006400']} style={styles.menuGradient}>
              <View style={styles.menuHeader}>
                <Text style={styles.menuTitle}>Game Menu</Text>
                <TouchableOpacity onPress={() => setShowMobileMenu(false)}>
                  <MaterialIcons name="close" size={24} color="white" />
                </TouchableOpacity>
              </View>

              <ScrollView style={styles.menuContent}>
                {navigationItems.map((item) => (
                  <TouchableOpacity
                    key={item.id}
                    style={[styles.menuItem, pathname === item.route && styles.activeMenuItem]}
                    onPress={() => handleNavigation(item.route)}
                  >
                    <MaterialIcons name={item.icon as any} size={20} color={item.color} />
                    <Text style={styles.menuItemText}>{item.name}</Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>
            </LinearGradient>
          </View>
        </View>
      </Modal>

      <Modal 
        visible={showProfileModal} 
        transparent 
        animationType={Platform.OS === 'ios' ? 'slide' : 'fade'}
        presentationStyle={Platform.OS === 'ios' ? 'formSheet' : 'overFullScreen'}
      >
        <View style={styles.modalOverlay}>
          <View style={[styles.profileModal, { paddingBottom: insets.bottom + 20 }]}>
            <BlurView intensity={40} style={styles.profileContent}>
              <View style={styles.modalHeader}>
                <Text style={styles.modalTitle}>Company Profile</Text>
                <TouchableOpacity onPress={() => setShowProfileModal(false)}>
                  <MaterialIcons name="close" size={20} color="white" />
                </TouchableOpacity>
              </View>

              <ScrollView style={styles.modalBody}>
                <TouchableOpacity style={styles.logoContainer} onPress={pickImage}>
                  <Text style={styles.logoPlaceholder}>Tap to upload logo</Text>
                </TouchableOpacity>

                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>Company Name</Text>
                  <TextInput
                    style={styles.input}
                    value={companyName}
                    onChangeText={setCompanyName}
                    placeholder="Enter company name"
                    placeholderTextColor="rgba(255,255,255,0.6)"
                    returnKeyType="next"
                  />
                </View>

                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>CEO Name</Text>
                  <TextInput
                    style={styles.input}
                    value={ceoName}
                    onChangeText={setCeoName}
                    placeholder="Enter CEO name"
                    placeholderTextColor="rgba(255,255,255,0.6)"
                    returnKeyType="done"
                  />
                </View>
              </ScrollView>

              <View style={styles.modalButtons}>
                <TouchableOpacity
                  style={styles.cancelButton}
                  onPress={() => setShowProfileModal(false)}
                >
                  <Text style={styles.buttonText}>Cancel</Text>
                </TouchableOpacity>
                
                <TouchableOpacity
                  style={styles.saveButton}
                  onPress={saveProfile}
                >
                  <Text style={styles.buttonText}>Save</Text>
                </TouchableOpacity>
              </View>
            </BlurView>
          </View>
        </View>
      </Modal>
    </>
  );
}

export default function MainLayout() {
  const insets = useSafeAreaInsets();
  
  return (
    <View style={styles.container}>
      <CustomHeader />
      <View style={[styles.content, { paddingBottom: insets.bottom }]}>
        <LinearGradient colors={['#000000', '#8B0040', '#006400']} style={styles.backgroundGradient}>
          <Slot />
        </LinearGradient>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000000',
  },
  content: {
    flex: 1,
  },
  backgroundGradient: {
    flex: 1,
  },
  header: {
    paddingVertical: 8,
    paddingHorizontal: 12,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    minHeight: 44,
    marginBottom: 8,
  },
  companySection: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  companyLogo: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#00FF00',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 8,
  },
  logoText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#000000',
  },
  companyInfo: {
    flex: 1,
  },
  companyName: {
    fontSize: 12,
    fontWeight: 'bold',
    color: 'black',
  },
  gameDate: {
    fontSize: 10,
    color: 'rgba(0,0,0,0.7)',
  },
  gameStats: {
    alignItems: 'center',
    flex: 1,
  },
  capital: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#000000',
  },
  controls: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  playButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  pausedButton: {
    backgroundColor: '#FF0000',
  },
  playingButton: {
    backgroundColor: '#00FF00',
  },
  menuButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(0,0,0,0.8)',
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  notificationBadge: {
    position: 'absolute',
    top: -4,
    right: -4,
    backgroundColor: '#FF0000',
    borderRadius: 8,
    minWidth: 16,
    height: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  badgeText: {
    fontSize: 10,
    fontWeight: 'bold',
    color: 'white',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.8)',
    justifyContent: 'flex-end',
  },
  mobileMenu: {
    height: '75%',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    overflow: 'hidden',
  },
  menuGradient: {
    flex: 1,
  },
  menuHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.2)',
  },
  menuTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'white',
  },
  menuContent: {
    flex: 1,
    padding: 20,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 12,
    marginBottom: 8,
    gap: 12,
  },
  activeMenuItem: {
    backgroundColor: 'rgba(0,255,0,0.2)',
  },
  menuItemText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: 'white',
  },
  profileModal: {
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  profileContent: {
    width: '100%',
    maxWidth: 400,
    backgroundColor: 'rgba(0,0,0,0.95)',
    borderRadius: 16,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.2)',
  },
  modalTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: 'white',
  },
  modalBody: {
    padding: 16,
    maxHeight: 300,
  },
  logoContainer: {
    height: 80,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
    borderStyle: 'dashed',
  },
  logoPlaceholder: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 12,
  },
  inputGroup: {
    marginBottom: 12,
  },
  inputLabel: {
    fontSize: 12,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 4,
  },
  input: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 6,
    padding: 10,
    fontSize: 12,
    color: 'white',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
  },
  modalButtons: {
    flexDirection: 'row',
    gap: 8,
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.2)',
  },
  cancelButton: {
    flex: 1,
    backgroundColor: 'rgba(255,255,255,0.2)',
    paddingVertical: 10,
    borderRadius: 6,
    alignItems: 'center',
  },
  saveButton: {
    flex: 1,
    backgroundColor: '#00FF00',
    paddingVertical: 10,
    borderRadius: 6,
    alignItems: 'center',
  },
  buttonText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: 'white',
  },
});