import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Modal, TextInput } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { MaterialIcons } from '@expo/vector-icons';
import { useGame } from '../../../hooks/useGame';

interface SpectrumBand {
  id: string;
  frequency: string;
  bandwidth: number; // MHz
  coverage: 'urban' | 'suburban' | 'rural' | 'nationwide';
  technology: '3G' | '4G' | '5G' | 'Mixed';
  baseCost: number;
  isOwned: boolean;
  ownershipDate?: Date;
  expiryDate?: Date;
  licenseTerms: number; // years
  renewalCost?: number;
}

interface SpectrumLease {
  id: string;
  carrierName: string;
  spectrumBandId: string;
  monthlyRate: number;
  revenueShare: number; // percentage
  startDate: Date;
  endDate: Date;
  status: 'active' | 'expired' | 'cancelled';
}

const defaultSpectrumBands: Omit<SpectrumBand, 'id' | 'isOwned'>[] = [
  {
    frequency: '700 MHz',
    bandwidth: 20,
    coverage: 'nationwide',
    technology: '4G',
    baseCost: 8000000,
    licenseTerms: 10,
  },
  {
    frequency: '850 MHz',
    bandwidth: 25,
    coverage: 'nationwide', 
    technology: '4G',
    baseCost: 9500000,
    licenseTerms: 10,
  },
  {
    frequency: '1900 MHz',
    bandwidth: 30,
    coverage: 'urban',
    technology: '4G',
    baseCost: 12000000,
    licenseTerms: 10,
  },
  {
    frequency: '2100 MHz',
    bandwidth: 20,
    coverage: 'suburban',
    technology: '4G',
    baseCost: 7000000,
    licenseTerms: 10,
  },
  {
    frequency: '2600 MHz',
    bandwidth: 40,
    coverage: 'urban',
    technology: '5G',
    baseCost: 15000000,
    licenseTerms: 15,
  },
  {
    frequency: '3500 MHz',
    bandwidth: 100,
    coverage: 'urban',
    technology: '5G',
    baseCost: 25000000,
    licenseTerms: 15,
  },
  {
    frequency: '26 GHz',
    bandwidth: 200,
    coverage: 'urban',
    technology: '5G',
    baseCost: 18000000,
    licenseTerms: 10,
  },
  {
    frequency: '28 GHz',
    bandwidth: 400,
    coverage: 'urban',
    technology: '5G',
    baseCost: 30000000,
    licenseTerms: 10,
  }
];

export default function SpectrumTab() {
  const { state, dispatch } = useGame();
  const [spectrumBands, setSpectrumBands] = useState<SpectrumBand[]>(() => 
    defaultSpectrumBands.map(band => ({
      ...band,
      id: `spectrum_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      isOwned: false,
      renewalCost: Math.round(band.baseCost * 0.3)
    }))
  );
  
  const [spectrumLeases, setSpectrumLeases] = useState<SpectrumLease[]>([]);
  const [selectedTab, setSelectedTab] = useState<'overview' | 'available' | 'owned' | 'leasing'>('overview');
  const [showPurchaseModal, setShowPurchaseModal] = useState(false);
  const [showLeaseModal, setShowLeaseModal] = useState(false);
  const [selectedBand, setSelectedBand] = useState<SpectrumBand | null>(null);
  const [leaseForm, setLeaseForm] = useState({
    carrierName: '',
    monthlyRate: 0,
    revenueShare: 0,
    duration: 12 // months
  });

  const getTechnologyColor = (tech: string) => {
    switch (tech) {
      case '3G': return '#FF9800';
      case '4G': return '#2196F3';
      case '5G': return '#9C27B0';
      case 'Mixed': return '#4CAF50';
      default: return '#757575';
    }
  };

  const getCoverageColor = (coverage: string) => {
    switch (coverage) {
      case 'urban': return '#F44336';
      case 'suburban': return '#FF9800';
      case 'rural': return '#4CAF50';
      case 'nationwide': return '#2196F3';
      default: return '#757575';
    }
  };

  const formatCurrency = (amount: number) => {
    if (amount >= 1000000) return `$${(amount / 1000000).toFixed(1)}M`;
    if (amount >= 1000) return `$${(amount / 1000).toFixed(0)}K`;
    return `$${amount.toLocaleString()}`;
  };

  const calculateSpectrumCost = (baseCost: number) => {
    if (!state.selectedCountry) return baseCost;
    
    // Adjust cost based on country population and market size
    const populationFactor = state.selectedCountry.population / 5000000;
    const marketMultiplier = state.selectedCountry.marketSize === 'large' ? 1.5 :
                           state.selectedCountry.marketSize === 'medium' ? 1.0 : 0.6;
    
    return Math.round(baseCost * populationFactor * marketMultiplier);
  };

  const purchaseSpectrum = (bandId: string) => {
    const band = spectrumBands.find(b => b.id === bandId);
    if (!band || !state.selectedCountry) return;

    const actualCost = calculateSpectrumCost(band.baseCost);
    
    if (state.company.capital < actualCost) {
      dispatch({ 
        type: 'ADD_NOTIFICATION', 
        payload: { 
          type: 'error', 
          message: `Insufficient funds for ${band.frequency} license. Need ${formatCurrency(actualCost)}`,
          id: Date.now().toString()
        }
      });
      return;
    }

    // Purchase spectrum
    dispatch({ type: 'SPEND_CAPITAL', payload: actualCost });
    
    const ownershipDate = new Date(state.gameDate);
    const expiryDate = new Date(ownershipDate);
    expiryDate.setFullYear(expiryDate.getFullYear() + band.licenseTerms);

    setSpectrumBands(prev => prev.map(b => 
      b.id === bandId 
        ? { ...b, isOwned: true, ownershipDate, expiryDate }
        : b
    ));

    dispatch({ 
      type: 'ADD_NOTIFICATION', 
      payload: { 
        type: 'info', 
        message: `🎉 Acquired ${band.frequency} spectrum license for ${formatCurrency(actualCost)}!`,
        id: Date.now().toString()
      }
    });

    setShowPurchaseModal(false);
  };

  const createSpectrumlease = () => {
    if (!selectedBand || !leaseForm.carrierName.trim() || leaseForm.monthlyRate <= 0) {
      dispatch({ 
        type: 'ADD_NOTIFICATION', 
        payload: { 
          type: 'error', 
          message: 'Please provide carrier name and valid lease terms',
          id: Date.now().toString()
        }
      });
      return;
    }

    const startDate = new Date(state.gameDate);
    const endDate = new Date(startDate);
    endDate.setMonth(endDate.getMonth() + leaseForm.duration);

    const newLease: SpectrumLease = {
      id: `lease_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      carrierName: leaseForm.carrierName.trim(),
      spectrumBandId: selectedBand.id,
      monthlyRate: leaseForm.monthlyRate,
      revenueShare: leaseForm.revenueShare,
      startDate,
      endDate,
      status: 'active'
    };

    setSpectrumLeases(prev => [...prev, newLease]);
    
    dispatch({ 
      type: 'ADD_NOTIFICATION', 
      payload: { 
        type: 'info', 
        message: `Spectrum lease created with ${leaseForm.carrierName} for ${formatCurrency(leaseForm.monthlyRate)}/month`,
        id: Date.now().toString()
      }
    });

    setShowLeaseModal(false);
    setLeaseForm({
      carrierName: '',
      monthlyRate: 0,
      revenueShare: 0,
      duration: 12
    });
  };

  const renewSpectrum = (bandId: string) => {
    const band = spectrumBands.find(b => b.id === bandId);
    if (!band || !band.renewalCost) return;

    if (state.company.capital < band.renewalCost) {
      dispatch({ 
        type: 'ADD_NOTIFICATION', 
        payload: { 
          type: 'error', 
          message: `Insufficient funds for renewal. Need ${formatCurrency(band.renewalCost)}`,
          id: Date.now().toString()
        }
      });
      return;
    }

    dispatch({ type: 'SPEND_CAPITAL', payload: band.renewalCost });
    
    const newExpiryDate = new Date(band.expiryDate || new Date());
    newExpiryDate.setFullYear(newExpiryDate.getFullYear() + band.licenseTerms);

    setSpectrumBands(prev => prev.map(b => 
      b.id === bandId 
        ? { ...b, expiryDate: newExpiryDate }
        : b
    ));

    dispatch({ 
      type: 'ADD_NOTIFICATION', 
      payload: { 
        type: 'info', 
        message: `${band.frequency} spectrum license renewed for ${band.licenseTerms} years`,
        id: Date.now().toString()
      }
    });
  };

  // Process monthly lease revenue
  React.useEffect(() => {
    if (state.isPaused) return;

    const interval = setInterval(() => {
      const now = new Date(state.gameDate);
      let totalLeaseRevenue = 0;

      // Check for expired leases and collect revenue
      setSpectrumLeases(prev => prev.map(lease => {
        if (lease.status === 'active' && now >= lease.endDate) {
          return { ...lease, status: 'expired' };
        }
        
        if (lease.status === 'active') {
          totalLeaseRevenue += lease.monthlyRate;
        }
        
        return lease;
      }));

      if (totalLeaseRevenue > 0) {
        dispatch({ type: 'ADD_CAPITAL', payload: totalLeaseRevenue });
        dispatch({ 
          type: 'ADD_NOTIFICATION', 
          payload: { 
            type: 'info', 
            message: `💰 Spectrum lease revenue: ${formatCurrency(totalLeaseRevenue)}`,
            id: Date.now().toString()
          }
        });
      }
    }, 30000); // Check every 30 seconds (1 game month)

    return () => clearInterval(interval);
  }, [state.gameDate, state.isPaused, dispatch]);

  const spectrumStats = {
    totalBands: spectrumBands.length,
    ownedBands: spectrumBands.filter(b => b.isOwned).length,
    activeLeases: spectrumLeases.filter(l => l.status === 'active').length,
    monthlyLeaseRevenue: spectrumLeases
      .filter(l => l.status === 'active')
      .reduce((sum, l) => sum + l.monthlyRate, 0)
  };

  const filteredBands = selectedTab === 'overview' ? spectrumBands :
                       selectedTab === 'available' ? spectrumBands.filter(b => !b.isOwned) :
                       selectedTab === 'owned' ? spectrumBands.filter(b => b.isOwned) :
                       spectrumBands.filter(b => b.isOwned);

  if (!state.selectedCountry) {
    return (
      <View style={styles.container}>
        <LinearGradient colors={['#004D40', '#00251A']} style={styles.background}>
          <View style={styles.emptyState}>
            <MaterialIcons name="radio" size={80} color="#4DD0E1" />
            <Text style={styles.emptyTitle}>Select a Market</Text>
            <Text style={styles.emptySubtitle}>
              Choose a country from the Countries tab to manage spectrum licenses
            </Text>
          </View>
        </LinearGradient>
      </View>
    );
  }

  return (
        <View style={styles.container}>
      <LinearGradient colors={['#000000', '#8B0040', '#006400']} style={styles.background}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Spectrum Licensing</Text>
          <Text style={styles.subtitle}>{state.selectedCountry.flag} {state.selectedCountry.name}</Text>
        </View>

        {/* Spectrum Statistics */}
        <BlurView intensity={15} style={styles.statsGrid}>
          <View style={styles.statCard}>
            <MaterialIcons name="radio" size={24} color="#4DD0E1" />
            <Text style={styles.statValue}>{spectrumStats.totalBands}</Text>
            <Text style={styles.statLabel}>Available Bands</Text>
          </View>
          
          <View style={styles.statCard}>
            <MaterialIcons name="check-circle" size={24} color="#4CAF50" />
            <Text style={styles.statValue}>{spectrumStats.ownedBands}</Text>
            <Text style={styles.statLabel}>Owned Licenses</Text>
          </View>
          
          <View style={styles.statCard}>
            <MaterialIcons name="business" size={24} color="#FF9800" />
            <Text style={styles.statValue}>{spectrumStats.activeLeases}</Text>
            <Text style={styles.statLabel}>Active Leases</Text>
          </View>
          
          <View style={styles.statCard}>
            <MaterialIcons name="attach-money" size={24} color="#2196F3" />
            <Text style={styles.statValue}>{formatCurrency(spectrumStats.monthlyLeaseRevenue)}</Text>
            <Text style={styles.statLabel}>Monthly Revenue</Text>
          </View>
        </BlurView>

        {/* Tab Navigation */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.tabNavigation}>
          {['overview', 'available', 'owned', 'leasing'].map(tab => (
            <TouchableOpacity
              key={tab}
              style={[styles.tab, selectedTab === tab && styles.activeTab]}
              onPress={() => setSelectedTab(tab as any)}
            >
              <Text style={[styles.tabText, selectedTab === tab && styles.activeTabText]}>
                {tab.charAt(0).toUpperCase() + tab.slice(1)}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {/* Spectrum Bands List */}
        <ScrollView style={styles.spectrumList} showsVerticalScrollIndicator={false}>
          {selectedTab === 'leasing' ? (
            // Leasing Management View
            <>
              <View style={styles.leasingHeader}>
                <Text style={styles.leasingTitle}>Spectrum Leasing Revenue</Text>
                <TouchableOpacity 
                  style={styles.createLeaseButton}
                  onPress={() => {
                    const ownedBands = spectrumBands.filter(b => b.isOwned);
                    if (ownedBands.length === 0) {
                      dispatch({ 
                        type: 'ADD_NOTIFICATION', 
                        payload: { 
                          type: 'warning', 
                          message: 'You must own spectrum licenses before leasing them out',
                          id: Date.now().toString()
                        }
                      });
                    } else {
                      setSelectedBand(ownedBands[0]);
                      setShowLeaseModal(true);
                    }
                  }}
                >
                  <MaterialIcons name="add" size={20} color="white" />
                  <Text style={styles.createLeaseText}>Create Lease</Text>
                </TouchableOpacity>
              </View>

              {spectrumLeases.map(lease => {
                const band = spectrumBands.find(b => b.id === lease.spectrumBandId);
                return (
                  <BlurView key={lease.id} intensity={15} style={styles.leaseCard}>
                    <View style={styles.leaseHeader}>
                      <Text style={styles.leaseCarrier}>{lease.carrierName}</Text>
                      <View style={[styles.leaseStatus, 
                        lease.status === 'active' ? styles.activeStatus : 
                        lease.status === 'expired' ? styles.expiredStatus : styles.cancelledStatus
                      ]}>
                        <Text style={styles.statusText}>{lease.status.toUpperCase()}</Text>
                      </View>
                    </View>
                    
                    <View style={styles.leaseDetails}>
                      <Text style={styles.leaseSpectrum}>Spectrum: {band?.frequency}</Text>
                      <Text style={styles.leaseRate}>Monthly: {formatCurrency(lease.monthlyRate)}</Text>
                      <Text style={styles.leaseRevShare}>Revenue Share: {lease.revenueShare}%</Text>
                      <Text style={styles.leasePeriod}>
                        {lease.startDate.toLocaleDateString()} - {lease.endDate.toLocaleDateString()}
                      </Text>
                    </View>
                  </BlurView>
                );
              })}

              {spectrumLeases.length === 0 && (
                <View style={styles.emptyLeases}>
                  <MaterialIcons name="business" size={48} color="rgba(255,255,255,0.5)" />
                  <Text style={styles.emptyLeasesText}>No spectrum leases yet</Text>
                  <Text style={styles.emptyLeasesSubtext}>Create leases to generate monthly revenue</Text>
                </View>
              )}
            </>
          ) : (
            // Spectrum Bands View
            filteredBands.map(band => (
              <BlurView key={band.id} intensity={15} style={styles.spectrumCard}>
                <View style={styles.spectrumHeader}>
                  <View style={styles.spectrumInfo}>
                    <View style={styles.spectrumTitleRow}>
                      <Text style={styles.spectrumFrequency}>{band.frequency}</Text>
                      {band.isOwned && (
                        <MaterialIcons name="verified" size={20} color="#4CAF50" />
                      )}
                    </View>
                    <View style={styles.spectrumTags}>
                      <View style={[styles.tag, { backgroundColor: getTechnologyColor(band.technology) }]}>
                        <Text style={styles.tagText}>{band.technology}</Text>
                      </View>
                      <View style={[styles.tag, { backgroundColor: getCoverageColor(band.coverage) }]}>
                        <Text style={styles.tagText}>{band.coverage}</Text>
                      </View>
                      <View style={styles.tag}>
                        <Text style={styles.tagText}>{band.bandwidth} MHz</Text>
                      </View>
                    </View>
                  </View>
                </View>

                <View style={styles.spectrumDetails}>
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>License Cost:</Text>
                    <Text style={styles.detailValue}>
                      {formatCurrency(calculateSpectrumCost(band.baseCost))}
                    </Text>
                  </View>
                  
                  {band.isOwned && band.renewalCost && (
                    <View style={styles.detailRow}>
                      <Text style={styles.detailLabel}>Renewal Cost:</Text>
                      <Text style={styles.detailValue}>{formatCurrency(band.renewalCost)}</Text>
                    </View>
                  )}
                  
                  <View style={styles.detailRow}>
                    <Text style={styles.detailLabel}>License Term:</Text>
                    <Text style={styles.detailValue}>{band.licenseTerms} years</Text>
                  </View>

                  {band.isOwned && band.expiryDate && (
                    <View style={styles.detailRow}>
                      <Text style={styles.detailLabel}>Expires:</Text>
                      <Text style={[
                        styles.detailValue,
                        { color: new Date(band.expiryDate) < new Date(Date.now() + 365*24*60*60*1000) ? '#FF9800' : '#4CAF50' }
                      ]}>
                        {band.expiryDate.toLocaleDateString()}
                      </Text>
                    </View>
                  )}
                </View>

                <View style={styles.spectrumActions}>
                  {!band.isOwned ? (
                    <TouchableOpacity 
                      style={styles.purchaseButton}
                      onPress={() => {
                        setSelectedBand(band);
                        setShowPurchaseModal(true);
                      }}
                    >
                      <MaterialIcons name="shopping-cart" size={16} color="white" />
                      <Text style={styles.purchaseButtonText}>Purchase License</Text>
                    </TouchableOpacity>
                  ) : (
                    <View style={styles.ownedActions}>
                      {band.expiryDate && new Date(band.expiryDate) < new Date(Date.now() + 2*365*24*60*60*1000) && (
                        <TouchableOpacity 
                          style={styles.renewButton}
                          onPress={() => renewSpectrum(band.id)}
                        >
                          <MaterialIcons name="refresh" size={16} color="white" />
                          <Text style={styles.renewButtonText}>Renew</Text>
                        </TouchableOpacity>
                      )}
                      
                      <TouchableOpacity 
                        style={styles.leaseButton}
                        onPress={() => {
                          setSelectedBand(band);
                          setShowLeaseModal(true);
                        }}
                      >
                        <MaterialIcons name="business" size={16} color="white" />
                        <Text style={styles.leaseButtonText}>Lease Out</Text>
                      </TouchableOpacity>
                    </View>
                  )}
                </View>
              </BlurView>
            ))
          )}
        </ScrollView>

        {/* Purchase Modal */}
        {selectedBand && (
          <Modal visible={showPurchaseModal} transparent animationType="fade">
            <View style={styles.modalOverlay}>
              <BlurView intensity={40} style={styles.modalContent}>
                <View style={styles.modalHeader}>
                  <Text style={styles.modalTitle}>Purchase Spectrum License</Text>
                  <TouchableOpacity onPress={() => setShowPurchaseModal(false)}>
                    <MaterialIcons name="close" size={24} color="white" />
                  </TouchableOpacity>
                </View>

                <View style={styles.modalBody}>
                  <Text style={styles.modalSpectrum}>{selectedBand.frequency} Band</Text>
                  
                  <View style={styles.modalDetails}>
                    <View style={styles.modalDetailRow}>
                      <Text style={styles.modalDetailLabel}>Bandwidth:</Text>
                      <Text style={styles.modalDetailValue}>{selectedBand.bandwidth} MHz</Text>
                    </View>
                    
                    <View style={styles.modalDetailRow}>
                      <Text style={styles.modalDetailLabel}>Technology:</Text>
                      <Text style={styles.modalDetailValue}>{selectedBand.technology}</Text>
                    </View>
                    
                    <View style={styles.modalDetailRow}>
                      <Text style={styles.modalDetailLabel}>Coverage:</Text>
                      <Text style={styles.modalDetailValue}>{selectedBand.coverage}</Text>
                    </View>
                    
                    <View style={styles.modalDetailRow}>
                      <Text style={styles.modalDetailLabel}>License Cost:</Text>
                      <Text style={styles.modalDetailValue}>
                        {formatCurrency(calculateSpectrumCost(selectedBand.baseCost))}
                      </Text>
                    </View>
                    
                    <View style={styles.modalDetailRow}>
                      <Text style={styles.modalDetailLabel}>License Term:</Text>
                      <Text style={styles.modalDetailValue}>{selectedBand.licenseTerms} years</Text>
                    </View>
                    
                    <View style={styles.modalDetailRow}>
                      <Text style={styles.modalDetailLabel}>Available Capital:</Text>
                      <Text style={styles.modalDetailValue}>{formatCurrency(state.company.capital)}</Text>
                    </View>
                  </View>
                </View>

                <View style={styles.modalButtons}>
                  <TouchableOpacity
                    style={styles.modalCancelButton}
                    onPress={() => setShowPurchaseModal(false)}
                  >
                    <Text style={styles.modalCancelText}>Cancel</Text>
                  </TouchableOpacity>
                  
                  <TouchableOpacity
                    style={[
                      styles.modalConfirmButton,
                      state.company.capital < calculateSpectrumCost(selectedBand.baseCost) && styles.modalButtonDisabled
                    ]}
                    onPress={() => purchaseSpectrum(selectedBand.id)}
                    disabled={state.company.capital < calculateSpectrumCost(selectedBand.baseCost)}
                  >
                    <Text style={styles.modalConfirmText}>Purchase License</Text>
                  </TouchableOpacity>
                </View>
              </BlurView>
            </View>
          </Modal>
        )}

        {/* Lease Modal */}
        <Modal visible={showLeaseModal} transparent animationType="fade">
          <View style={styles.modalOverlay}>
            <BlurView intensity={40} style={styles.modalContent}>
              <View style={styles.modalHeader}>
                <Text style={styles.modalTitle}>Create Spectrum Lease</Text>
                <TouchableOpacity onPress={() => setShowLeaseModal(false)}>
                  <MaterialIcons name="close" size={24} color="white" />
                </TouchableOpacity>
              </View>

              <ScrollView style={styles.modalBody}>
                {selectedBand && (
                  <Text style={styles.modalSpectrum}>{selectedBand.frequency} License</Text>
                )}
                
                <View style={styles.inputContainer}>
                  <Text style={styles.inputLabel}>Carrier Name</Text>
                  <TextInput
                    style={styles.input}
                    value={leaseForm.carrierName}
                    onChangeText={(text) => setLeaseForm(prev => ({ ...prev, carrierName: text }))}
                    placeholder="Enter carrier name"
                    placeholderTextColor="rgba(255,255,255,0.6)"
                  />
                </View>

                <View style={styles.inputContainer}>
                  <Text style={styles.inputLabel}>Monthly Rate ($)</Text>
                  <TextInput
                    style={styles.input}
                    value={leaseForm.monthlyRate.toString()}
                    onChangeText={(text) => setLeaseForm(prev => ({ ...prev, monthlyRate: parseFloat(text) || 0 }))}
                    placeholder="Monthly lease rate"
                    keyboardType="numeric"
                    placeholderTextColor="rgba(255,255,255,0.6)"
                  />
                </View>

                <View style={styles.inputContainer}>
                  <Text style={styles.inputLabel}>Revenue Share (%)</Text>
                  <TextInput
                    style={styles.input}
                    value={leaseForm.revenueShare.toString()}
                    onChangeText={(text) => setLeaseForm(prev => ({ ...prev, revenueShare: parseFloat(text) || 0 }))}
                    placeholder="Revenue share percentage"
                    keyboardType="numeric"
                    placeholderTextColor="rgba(255,255,255,0.6)"
                  />
                </View>

                <View style={styles.inputContainer}>
                  <Text style={styles.inputLabel}>Duration (Months)</Text>
                  <TextInput
                    style={styles.input}
                    value={leaseForm.duration.toString()}
                    onChangeText={(text) => setLeaseForm(prev => ({ ...prev, duration: parseInt(text) || 12 }))}
                    placeholder="Lease duration in months"
                    keyboardType="numeric"
                    placeholderTextColor="rgba(255,255,255,0.6)"
                  />
                </View>
              </ScrollView>

              <View style={styles.modalButtons}>
                <TouchableOpacity
                  style={styles.modalCancelButton}
                  onPress={() => setShowLeaseModal(false)}
                >
                  <Text style={styles.modalCancelText}>Cancel</Text>
                </TouchableOpacity>
                
                <TouchableOpacity
                  style={styles.modalConfirmButton}
                  onPress={createSpectrumlease}
                >
                  <Text style={styles.modalConfirmText}>Create Lease</Text>
                </TouchableOpacity>
              </View>
            </BlurView>
          </View>
        </Modal>
      </LinearGradient>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
  },
  header: {
    padding: 20,
    alignItems: 'center',
  },
  title: {
    fontSize: 36,
    fontWeight: 'bold',
    color: 'white',
  },
  subtitle: {
    fontSize: 24,
    color: 'rgba(255,255,255,0.8)',
    textAlign: 'center',
    marginTop: 6,
    fontWeight: 'bold',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 16,
    padding: 16,
    marginHorizontal: 20,
    marginBottom: 20,
  },
  statCard: {
    width: '48%',
    alignItems: 'center',
    marginBottom: 16,
  },
  statValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
    marginTop: 8,
    textAlign: 'center',
  },
  statLabel: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
    textAlign: 'center',
    marginTop: 4,
  },
  tabNavigation: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  tab: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 20,
    marginRight: 8,
  },
  activeTab: {
    backgroundColor: '#4DD0E1',
  },
  tabText: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
  },
  activeTabText: {
    color: 'white',
  },
  spectrumList: {
    flex: 1,
    paddingHorizontal: 20,
  },
  spectrumCard: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
  },
  spectrumHeader: {
    marginBottom: 16,
  },
  spectrumInfo: {
    flex: 1,
  },
  spectrumTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 12,
  },
  spectrumFrequency: {
    flex: 1,
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white',
  },
  spectrumTags: {
    flexDirection: 'row',
    gap: 8,
    flexWrap: 'wrap',
  },
  tag: {
    backgroundColor: 'rgba(255,255,255,0.2)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  tagText: {
    fontSize: 10,
    fontWeight: 'bold',
    color: 'white',
  },
  spectrumDetails: {
    marginBottom: 16,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  detailLabel: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
  },
  detailValue: {
    fontSize: 14,
    fontWeight: 'bold',
    color: 'white',
  },
  spectrumActions: {
    flexDirection: 'row',
    gap: 8,
  },
  purchaseButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#00ACC1',
    paddingVertical: 10,
    borderRadius: 8,
  },
  purchaseButtonText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: 'white',
  },
  ownedActions: {
    flex: 1,
    flexDirection: 'row',
    gap: 8,
  },
  renewButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 4,
    backgroundColor: '#FF9800',
    paddingVertical: 8,
    borderRadius: 6,
  },
  renewButtonText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: 'white',
  },
  leaseButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 4,
    backgroundColor: '#4CAF50',
    paddingVertical: 8,
    borderRadius: 6,
  },
  leaseButtonText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: 'white',
  },
  leasingHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  leasingTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
  },
  createLeaseButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: '#00ACC1',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
  },
  createLeaseText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: 'white',
  },
  leaseCard: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
  },
  leaseHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  leaseCarrier: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
  },
  leaseStatus: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  activeStatus: {
    backgroundColor: 'rgba(76,175,80,0.3)',
  },
  expiredStatus: {
    backgroundColor: 'rgba(244,67,54,0.3)',
  },
  cancelledStatus: {
    backgroundColor: 'rgba(158,158,158,0.3)',
  },
  statusText: {
    fontSize: 10,
    fontWeight: 'bold',
    color: 'white',
  },
  leaseDetails: {
    gap: 4,
  },
  leaseSpectrum: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#4DD0E1',
  },
  leaseRate: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#4CAF50',
  },
  leaseRevShare: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
  },
  leasePeriod: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.6)',
    fontWeight: 'bold',
  },
  emptyLeases: {
    alignItems: 'center',
    padding: 40,
  },
  emptyLeasesText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
    marginTop: 16,
  },
  emptyLeasesSubtext: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.6)',
    textAlign: 'center',
    marginTop: 8,
    fontWeight: 'bold',
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  emptyTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
    marginTop: 20,
  },
  emptySubtitle: {
    fontSize: 16,
    color: 'rgba(255,255,255,0.8)',
    textAlign: 'center',
    marginTop: 12,
    lineHeight: 24,
    fontWeight: 'bold',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.8)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    width: '90%',
    maxWidth: 500,
    maxHeight: '80%',
    backgroundColor: 'rgba(0,77,64,0.95)',
    borderRadius: 20,
    overflow: 'hidden',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.2)',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white',
  },
  modalBody: {
    flex: 1,
    padding: 20,
  },
  modalSpectrum: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#4DD0E1',
    textAlign: 'center',
    marginBottom: 20,
  },
  modalDetails: {
    marginBottom: 20,
  },
  modalDetailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  modalDetailLabel: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
  },
  modalDetailValue: {
    fontSize: 14,
    fontWeight: 'bold',
    color: 'white',
  },
  inputContainer: {
    marginBottom: 16,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 8,
  },
  input: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    color: 'white',
    fontWeight: 'bold',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
  },
  modalButtons: {
    flexDirection: 'row',
    gap: 12,
    padding: 20,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.2)',
  },
  modalCancelButton: {
    flex: 1,
    backgroundColor: 'rgba(255,255,255,0.2)',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  modalCancelText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'white',
  },
  modalConfirmButton: {
    flex: 1,
    backgroundColor: '#00ACC1',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  modalButtonDisabled: {
    backgroundColor: 'rgba(255,255,255,0.3)',
  },
  modalConfirmText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'white',
  },
});