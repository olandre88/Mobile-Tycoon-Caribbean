import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, TextInput, Modal, Alert, Platform } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { MaterialIcons } from '@expo/vector-icons';
import { useGame } from '../../../hooks/useGame';

interface InventoryItem {
  id: string;
  name: string;
  category: 'esim' | 'sim' | 'phone' | 'internet-box' | 'accessory';
  type: string;
  orderCost: number;
  sellingPrice: number;
  quantity: number;
  specifications?: string[];
  brand: string;
  popularity: number;
}

const deviceCategories = [
  {
    id: 'esim',
    name: 'eSIM Plans',
    icon: 'sim-card',
    color: '#00FFFF'
  },
  {
    id: 'sim',
    name: 'SIM Cards',
    icon: 'credit-card',
    color: '#00FF7F'
  },
  {
    id: 'phone',
    name: 'Smartphones',
    icon: 'smartphone',
    color: '#32CD32'
  },
  {
    id: 'internet-box',
    name: 'Internet Boxes',
    icon: 'router',
    color: '#00CED1'
  },
  {
    id: 'accessory',
    name: 'Accessories',
    icon: 'headphones',
    color: '#20B2AA'
  }
];

const defaultInventory: InventoryItem[] = [
  // eSIM Plans
  {
    id: 'esim_basic',
    name: 'Basic eSIM Plan',
    category: 'esim',
    type: '5GB Data + 500 Minutes',
    orderCost: 15,
    sellingPrice: 35,
    quantity: 1000,
    brand: 'Caribbean Mobile',
    popularity: 75,
    specifications: ['5GB Data', '500 Minutes', '100 SMS']
  },
  {
    id: 'esim_premium',
    name: 'Premium eSIM Plan',
    category: 'esim',
    type: 'Unlimited Data + Minutes',
    orderCost: 35,
    sellingPrice: 85,
    quantity: 500,
    brand: 'Caribbean Mobile',
    popularity: 90,
    specifications: ['Unlimited Data', 'Unlimited Minutes', 'Unlimited SMS']
  },
  
  // SIM Cards
  {
    id: 'sim_prepaid',
    name: 'Prepaid SIM Card',
    category: 'sim',
    type: 'Standard/Micro/Nano',
    orderCost: 2,
    sellingPrice: 10,
    quantity: 2000,
    brand: 'Universal',
    popularity: 80,
    specifications: ['Triple Cut', 'Pre-activated', '2GB Bonus Data']
  },
  {
    id: 'sim_postpaid',
    name: 'Postpaid SIM Card',
    category: 'sim',
    type: 'Contract SIM',
    orderCost: 5,
    sellingPrice: 25,
    quantity: 1500,
    brand: 'Universal',
    popularity: 70,
    specifications: ['Contract Required', '5GB Bonus', 'International Roaming']
  },
  
  // Smartphones
  {
    id: 'phone_budget',
    name: 'Galaxy A15',
    category: 'phone',
    type: 'Budget Smartphone',
    orderCost: 120,
    sellingPrice: 199,
    quantity: 150,
    brand: 'Samsung',
    popularity: 85,
    specifications: ['6.5" Display', '4GB RAM', '128GB Storage', '50MP Camera']
  },
  {
    id: 'phone_mid',
    name: 'iPhone 15',
    category: 'phone',
    type: 'Premium Smartphone',
    orderCost: 549,
    sellingPrice: 799,
    quantity: 75,
    brand: 'Apple',
    popularity: 95,
    specifications: ['6.1" Display', '8GB RAM', '256GB Storage', '48MP Camera']
  },
  {
    id: 'phone_premium',
    name: 'Galaxy S24 Ultra',
    category: 'phone',
    type: 'Flagship Smartphone',
    orderCost: 579,
    sellingPrice: 899,
    quantity: 50,
    brand: 'Samsung',
    popularity: 92,
    specifications: ['6.8" Display', '12GB RAM', '512GB Storage', '200MP Camera']
  },
  
  // Internet Boxes
  {
    id: 'box_basic',
    name: '4G Home Router',
    category: 'internet-box',
    type: 'Basic Internet Box',
    orderCost: 80,
    sellingPrice: 149,
    quantity: 200,
    brand: 'Huawei',
    popularity: 75,
    specifications: ['150Mbps 4G', 'Wi-Fi 5', '10 Device Support', 'External Antenna']
  },
  {
    id: 'box_premium',
    name: '5G Home Gateway',
    category: 'internet-box',
    type: 'Premium Internet Box',
    orderCost: 180,
    sellingPrice: 299,
    quantity: 100,
    brand: 'Samsung',
    popularity: 88,
    specifications: ['1Gbps 5G', 'Wi-Fi 6', '50 Device Support', 'Mesh Support']
  },
  
  // Accessories
  {
    id: 'acc_charger',
    name: 'Fast Charging Cable',
    category: 'accessory',
    type: 'USB-C Cable',
    orderCost: 8,
    sellingPrice: 25,
    quantity: 500,
    brand: 'Universal',
    popularity: 70,
    specifications: ['USB-C to USB-C', '100W Fast Charging', '1.5m Length']
  },
  {
    id: 'acc_case',
    name: 'Protective Phone Case',
    category: 'accessory',
    type: 'Universal Case',
    orderCost: 12,
    sellingPrice: 35,
    quantity: 400,
    brand: 'CaseMate',
    popularity: 65,
    specifications: ['Drop Protection', 'Clear Design', 'Wireless Charging Compatible']
  },
  {
    id: 'acc_earbuds',
    name: 'Wireless Earbuds',
    category: 'accessory',
    type: 'Bluetooth Earbuds',
    orderCost: 35,
    sellingPrice: 89,
    quantity: 150,
    brand: 'Galaxy Buds',
    popularity: 82,
    specifications: ['Active Noise Canceling', '8hr Battery', 'Touch Controls']
  }
];

export default function InventoryTab() {
  const { state, dispatch } = useGame();
  const [inventory, setInventory] = useState<InventoryItem[]>(defaultInventory);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [editingPrice, setEditingPrice] = useState<string | null>(null);
  const [newPrice, setNewPrice] = useState('');
  const [showOrderModal, setShowOrderModal] = useState(false);
  const [selectedItem, setSelectedItem] = useState<InventoryItem | null>(null);
  const [orderQuantity, setOrderQuantity] = useState('1');

  // Web alert state
  const [alertConfig, setAlertConfig] = useState<{
    visible: boolean;
    title: string;
    message: string;
    onOk?: () => void;
  }>({ visible: false, title: '', message: '' });

  const showWebAlert = (title: string, message: string, onOk?: () => void) => {
    if (Platform.OS === 'web') {
      setAlertConfig({ visible: true, title, message, onOk });
    } else {
      Alert.alert(title, message, onOk ? [{ text: 'OK', onPress: onOk }] : undefined);
    }
  };

  // Auto-sell devices to new customers
  useEffect(() => {
    const sellDevicesToCustomers = () => {
      const newCustomerCount = state.customers.filter(
        customer => new Date(customer.acquisitionDate).toDateString() === new Date().toDateString()
      ).length;

      if (newCustomerCount > 0) {
        let totalRevenue = 0;
        const updatedInventory = [...inventory];

        // Calculate device sales for new customers
        newCustomerCount * 0.6; // 60% of customers buy something
        
        updatedInventory.forEach((item, index) => {
          let salesCount = 0;
          
          // Different categories have different purchase rates
          switch (item.category) {
            case 'sim':
            case 'esim':
              salesCount = Math.floor(newCustomerCount * 0.8); // 80% need SIM/eSIM
              break;
            case 'phone':
              salesCount = Math.floor(newCustomerCount * 0.3); // 30% buy phones
              break;
            case 'internet-box':
              salesCount = Math.floor(newCustomerCount * 0.15); // 15% buy internet boxes
              break;
            case 'accessory':
              salesCount = Math.floor(newCustomerCount * 0.4); // 40% buy accessories
              break;
          }
          
          // Apply popularity and availability modifiers
          salesCount = Math.floor(salesCount * (item.popularity / 100));
          salesCount = Math.min(salesCount, item.quantity);
          
          if (salesCount > 0) {
            const profit = (item.sellingPrice - item.orderCost) * salesCount;
            totalRevenue += item.sellingPrice * salesCount;
            
            updatedInventory[index] = {
              ...item,
              quantity: item.quantity - salesCount
            };
            
            // Add profit to capital
            dispatch({ type: 'ADD_CAPITAL', payload: profit });
          }
        });
        
        setInventory(updatedInventory);
        
        if (totalRevenue > 0) {
          dispatch({ 
            type: 'ADD_NOTIFICATION', 
            payload: { 
              type: 'info', 
              message: `📱 Device sales: $${totalRevenue.toLocaleString()} revenue from ${newCustomerCount} customers!`,
              id: Date.now().toString()
            }
          });
        }
      }
    };

    sellDevicesToCustomers();
  }, [state.customers.length]);

  const handleOrder = (item: InventoryItem) => {
    setSelectedItem(item);
    setOrderQuantity('1');
    setShowOrderModal(true);
  };

  const confirmOrder = () => {
    if (!selectedItem) return;
    
    const qty = parseInt(orderQuantity) || 1;
    const totalCost = selectedItem.orderCost * qty;
    
    if (state.company.capital < totalCost) {
      showWebAlert('Insufficient Capital', `Need $${totalCost.toLocaleString()} to order ${qty} ${selectedItem.name}. Available: $${state.company.capital.toLocaleString()}`);
      return;
    }
    
    // Update inventory
    setInventory(prev => prev.map(item => 
      item.id === selectedItem.id 
        ? { ...item, quantity: item.quantity + qty }
        : item
    ));
    
    // Deduct capital
    dispatch({ type: 'SPEND_CAPITAL', payload: totalCost });
    
    dispatch({ 
      type: 'ADD_NOTIFICATION', 
      payload: { 
        type: 'info', 
        message: `📦 Ordered ${qty}x ${selectedItem.name} for $${totalCost.toLocaleString()}`,
        id: Date.now().toString()
      }
    });
    
    setShowOrderModal(false);
  };

  const handlePriceEdit = (itemId: string, currentPrice: number) => {
    setEditingPrice(itemId);
    setNewPrice(currentPrice.toString());
  };

  const savePriceEdit = (itemId: string) => {
    const price = parseFloat(newPrice) || 0;
    if (price >= 1) {
      setInventory(prev => prev.map(item => 
        item.id === itemId 
          ? { ...item, sellingPrice: price }
          : item
      ));
      setEditingPrice(null);
    }
  };

  const formatCurrency = (amount: number) => {
    return `$${amount.toLocaleString()}`;
  };

  const getProfit = (item: InventoryItem) => {
    return item.sellingPrice - item.orderCost;
  };

  const getProfitMargin = (item: InventoryItem) => {
    return item.sellingPrice > 0 ? ((item.sellingPrice - item.orderCost) / item.sellingPrice * 100) : 0;
  };

  const getTotalValue = () => {
    return inventory.reduce((sum, item) => sum + (item.orderCost * item.quantity), 0);
  };

  const filteredInventory = selectedCategory === 'all' 
    ? inventory 
    : inventory.filter(item => item.category === selectedCategory);

  return (
        <View style={styles.container}>
      <LinearGradient colors={['#000000', '#8B0040', '#006400']} style={styles.background}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Device Inventory</Text>
          <Text style={styles.subtitle}>
            Total Value: {formatCurrency(getTotalValue())} • {inventory.reduce((sum, item) => sum + item.quantity, 0)} Items
          </Text>
        </View>

        {/* Category Filter */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.categoryFilter}>
          <TouchableOpacity
            style={[styles.categoryButton, selectedCategory === 'all' && styles.categoryButtonActive]}
            onPress={() => setSelectedCategory('all')}
          >
            <MaterialIcons name="apps" size={20} color={selectedCategory === 'all' ? '#000000' : 'white'} />
            <Text style={[styles.categoryText, selectedCategory === 'all' && styles.categoryTextActive]}>
              All
            </Text>
          </TouchableOpacity>
          
          {deviceCategories.map(category => (
            <TouchableOpacity
              key={category.id}
              style={[
                styles.categoryButton, 
                selectedCategory === category.id && styles.categoryButtonActive,
                { borderColor: category.color }
              ]}
              onPress={() => setSelectedCategory(category.id)}
            >
              <MaterialIcons 
                name={category.icon as any} 
                size={20} 
                color={selectedCategory === category.id ? '#000000' : category.color} 
              />
              <Text style={[
                styles.categoryText, 
                selectedCategory === category.id && styles.categoryTextActive,
                { color: selectedCategory === category.id ? '#000000' : category.color }
              ]}>
                {category.name}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {/* Inventory List */}
        <ScrollView style={styles.inventoryList} showsVerticalScrollIndicator={false}>
          {filteredInventory.map(item => (
            <BlurView key={item.id} intensity={20} style={[styles.itemCard, { borderColor: deviceCategories.find(c => c.id === item.category)?.color || '#00FFFF' }]}>
              <View style={styles.itemHeader}>
                <View style={styles.itemInfo}>
                  <Text style={styles.itemName}>{item.name}</Text>
                  <Text style={styles.itemType}>{item.type} • {item.brand}</Text>
                  <Text style={styles.itemSpecs}>
                    {item.specifications?.slice(0, 2).join(' • ') || 'Standard specifications'}
                  </Text>
                </View>
                
                <View style={styles.itemActions}>
                  <Text style={[
                    styles.stockText,
                    item.quantity < 10 ? styles.lowStock : 
                    item.quantity < 50 ? styles.mediumStock : styles.highStock
                  ]}>
                    Stock: {item.quantity}
                  </Text>
                  <TouchableOpacity 
                    style={styles.orderButton}
                    onPress={() => handleOrder(item)}
                  >
                    <MaterialIcons name="add-shopping-cart" size={16} color="white" />
                    <Text style={styles.orderButtonText}>Order</Text>
                  </TouchableOpacity>
                </View>
              </View>

              <View style={styles.pricingSection}>
                <View style={styles.priceRow}>
                  <Text style={styles.priceLabel}>Order Cost:</Text>
                  <Text style={styles.orderCost}>{formatCurrency(item.orderCost)}</Text>
                </View>
                
                <View style={styles.priceRow}>
                  <Text style={styles.priceLabel}>Selling Price:</Text>
                  {editingPrice === item.id ? (
                    <View style={styles.priceEdit}>
                      <TextInput
                        style={styles.priceInput}
                        value={newPrice}
                        onChangeText={setNewPrice}
                        keyboardType="numeric"
                        placeholder="Price"
                        placeholderTextColor="rgba(255,255,255,0.6)"
                      />
                      <TouchableOpacity 
                        style={styles.saveButton}
                        onPress={() => savePriceEdit(item.id)}
                      >
                        <MaterialIcons name="check" size={16} color="white" />
                      </TouchableOpacity>
                      <TouchableOpacity 
                        style={styles.cancelButton}
                        onPress={() => setEditingPrice(null)}
                      >
                        <MaterialIcons name="close" size={16} color="white" />
                      </TouchableOpacity>
                    </View>
                  ) : (
                    <TouchableOpacity 
                      style={styles.priceDisplay}
                      onPress={() => handlePriceEdit(item.id, item.sellingPrice)}
                    >
                      <Text style={styles.sellingPrice}>{formatCurrency(item.sellingPrice)}</Text>
                      <MaterialIcons name="edit" size={14} color="#00FFFF" />
                    </TouchableOpacity>
                  )}
                </View>

                <View style={styles.profitRow}>
                  <Text style={styles.profitLabel}>Profit per Unit:</Text>
                  <Text style={[styles.profitValue, { color: getProfit(item) > 0 ? '#00FF7F' : '#FF4444' }]}>
                    {formatCurrency(getProfit(item))} ({getProfitMargin(item).toFixed(1)}%)
                  </Text>
                </View>

                <View style={styles.popularityRow}>
                  <Text style={styles.popularityLabel}>Popularity:</Text>
                  <View style={styles.popularityBar}>
                    <View 
                      style={[
                        styles.popularityFill, 
                        { 
                          width: `${item.popularity}%`,
                          backgroundColor: item.popularity > 80 ? '#00FF7F' : item.popularity > 60 ? '#FFFF00' : '#FF4444'
                        }
                      ]} 
                    />
                  </View>
                  <Text style={styles.popularityValue}>{item.popularity}%</Text>
                </View>
              </View>
            </BlurView>
          ))}
        </ScrollView>

        {/* Order Modal */}
        <Modal visible={showOrderModal} transparent animationType="fade">
          <View style={styles.modalOverlay}>
            <BlurView intensity={40} style={styles.modalContent}>
              <View style={styles.modalHeader}>
                <Text style={styles.modalTitle}>Order Devices</Text>
                <TouchableOpacity onPress={() => setShowOrderModal(false)}>
                  <MaterialIcons name="close" size={24} color="white" />
                </TouchableOpacity>
              </View>

              {selectedItem && (
                <View style={styles.modalBody}>
                  <Text style={styles.modalItemName}>{selectedItem.name}</Text>
                  <Text style={styles.modalItemType}>{selectedItem.type}</Text>
                  
                  <View style={styles.modalDetailsSection}>
                    <View style={styles.modalDetailRow}>
                      <Text style={styles.modalDetailLabel}>Unit Cost:</Text>
                      <Text style={styles.modalDetailValue}>{formatCurrency(selectedItem.orderCost)}</Text>
                    </View>
                    
                    <View style={styles.modalDetailRow}>
                      <Text style={styles.modalDetailLabel}>Current Stock:</Text>
                      <Text style={styles.modalDetailValue}>{selectedItem.quantity} units</Text>
                    </View>
                  </View>

                  <View style={styles.quantitySection}>
                    <Text style={styles.quantityLabel}>Order Quantity:</Text>
                    <View style={styles.quantityControls}>
                      <TouchableOpacity 
                        style={styles.quantityButton}
                        onPress={() => setOrderQuantity(Math.max(1, parseInt(orderQuantity) - 1).toString())}
                      >
                        <MaterialIcons name="remove" size={20} color="white" />
                      </TouchableOpacity>
                      <TextInput
                        style={styles.quantityInput}
                        value={orderQuantity}
                        onChangeText={setOrderQuantity}
                        keyboardType="numeric"
                        textAlign="center"
                        placeholderTextColor="rgba(255,255,255,0.6)"
                      />
                      <TouchableOpacity 
                        style={styles.quantityButton}
                        onPress={() => setOrderQuantity((parseInt(orderQuantity) + 1).toString())}
                      >
                        <MaterialIcons name="add" size={20} color="white" />
                      </TouchableOpacity>
                    </View>
                  </View>

                  <View style={styles.totalSection}>
                    <Text style={styles.totalLabel}>Total Cost:</Text>
                    <Text style={styles.totalValue}>
                      {formatCurrency(selectedItem.orderCost * (parseInt(orderQuantity) || 1))}
                    </Text>
                  </View>
                </View>
              )}

              <View style={styles.modalButtons}>
                <TouchableOpacity
                  style={styles.modalCancelButton}
                  onPress={() => setShowOrderModal(false)}
                >
                  <Text style={styles.modalCancelText}>Cancel</Text>
                </TouchableOpacity>
                
                <TouchableOpacity
                  style={styles.modalConfirmButton}
                  onPress={confirmOrder}
                >
                  <Text style={styles.modalConfirmText}>Order Devices</Text>
                </TouchableOpacity>
              </View>
            </BlurView>
          </View>
        </Modal>

        {/* Web Alert Modal */}
        {Platform.OS === 'web' && (
          <Modal visible={alertConfig.visible} transparent animationType="fade">
            <View style={styles.alertOverlay}>
              <View style={styles.alertBox}>
                <Text style={styles.alertTitle}>{alertConfig.title}</Text>
                <Text style={styles.alertMessage}>{alertConfig.message}</Text>
                <TouchableOpacity 
                  style={styles.alertButton}
                  onPress={() => {
                    alertConfig.onOk?.();
                    setAlertConfig(prev => ({ ...prev, visible: false }));
                  }}
                >
                  <Text style={styles.alertButtonText}>OK</Text>
                </TouchableOpacity>
              </View>
            </View>
          </Modal>
        )}
      </LinearGradient>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
  },
  header: {
    padding: 20,
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#00FFFF',
  },
  title: {
    fontSize: 42,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 24,
    color: '#00FFFF',
    fontWeight: 'bold',
  },
  categoryFilter: {
    paddingHorizontal: 20,
    paddingVertical: 15,
    marginBottom: 10,
  },
  categoryButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 20,
    marginRight: 10,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.3)',
  },
  categoryButtonActive: {
    backgroundColor: '#00FFFF',
  },
  categoryText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: 'white',
  },
  categoryTextActive: {
    color: '#000000',
  },
  inventoryList: {
    flex: 1,
    paddingHorizontal: 20,
  },
  itemCard: {
    backgroundColor: 'rgba(0,255,255,0.1)',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
  },
  itemHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  itemInfo: {
    flex: 1,
  },
  itemName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 4,
  },
  itemType: {
    fontSize: 14,
    color: '#00FFFF',
    fontWeight: 'bold',
    marginBottom: 2,
  },
  itemSpecs: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
  },
  itemActions: {
    alignItems: 'flex-end',
  },
  stockText: {
    fontSize: 12,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  lowStock: {
    color: '#FF4444',
  },
  mediumStock: {
    color: '#FFAA00',
  },
  highStock: {
    color: '#00FF7F',
  },
  orderButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: '#00AA00',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
  },
  orderButtonText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: 'white',
  },
  pricingSection: {
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.2)',
  },
  priceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  priceLabel: {
    fontSize: 14,
    fontWeight: 'bold',
    color: 'white',
  },
  orderCost: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#FFAA00',
  },
  priceDisplay: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  sellingPrice: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#00FF7F',
  },
  priceEdit: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  priceInput: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    fontSize: 14,
    color: 'white',
    fontWeight: 'bold',
    minWidth: 70,
    textAlign: 'center',
  },
  saveButton: {
    backgroundColor: '#00AA00',
    padding: 4,
    borderRadius: 4,
  },
  cancelButton: {
    backgroundColor: '#AA0000',
    padding: 4,
    borderRadius: 4,
  },
  profitRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  profitLabel: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
  },
  profitValue: {
    fontSize: 12,
    fontWeight: 'bold',
  },
  popularityRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  popularityLabel: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
  },
  popularityBar: {
    flex: 1,
    height: 6,
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 3,
    overflow: 'hidden',
  },
  popularityFill: {
    height: '100%',
    borderRadius: 3,
  },
  popularityValue: {
    fontSize: 12,
    color: 'white',
    fontWeight: 'bold',
    minWidth: 35,
    textAlign: 'right',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.8)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    width: '90%',
    maxWidth: 400,
    backgroundColor: 'rgba(0,26,0,0.95)',
    borderRadius: 20,
    borderWidth: 2,
    borderColor: '#00FFFF',
    overflow: 'hidden',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#00FFFF',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white',
  },
  modalBody: {
    padding: 20,
  },
  modalItemName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#00FFFF',
    textAlign: 'center',
    marginBottom: 4,
  },
  modalItemType: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.8)',
    textAlign: 'center',
    marginBottom: 20,
    fontWeight: 'bold',
  },
  modalDetailsSection: {
    marginBottom: 20,
  },
  modalDetailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  modalDetailLabel: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
  },
  modalDetailValue: {
    fontSize: 14,
    fontWeight: 'bold',
    color: 'white',
  },
  quantitySection: {
    alignItems: 'center',
    marginBottom: 20,
  },
  quantityLabel: {
    fontSize: 14,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 10,
  },
  quantityControls: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  quantityButton: {
    backgroundColor: '#00FFFF',
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  quantityInput: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 8,
    padding: 8,
    fontSize: 16,
    color: 'white',
    fontWeight: 'bold',
    minWidth: 60,
    borderWidth: 1,
    borderColor: '#00FFFF',
  },
  totalSection: {
    alignItems: 'center',
    paddingTop: 15,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.2)',
  },
  totalLabel: {
    fontSize: 16,
    color: 'rgba(255,255,255,0.8)',
    fontWeight: 'bold',
    marginBottom: 5,
  },
  totalValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#00FF7F',
  },
  modalButtons: {
    flexDirection: 'row',
    gap: 12,
    padding: 20,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.2)',
  },
  modalCancelButton: {
    flex: 1,
    backgroundColor: 'rgba(255,255,255,0.2)',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  modalCancelText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'white',
  },
  modalConfirmButton: {
    flex: 1,
    backgroundColor: '#00FFFF',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  modalConfirmText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#000000',
  },
  alertOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  alertBox: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 8,
    minWidth: 280,
  },
  alertTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    color: 'black',
  },
  alertMessage: {
    fontSize: 16,
    marginBottom: 20,
    color: 'black',
  },
  alertButton: {
    backgroundColor: '#007AFF',
    padding: 10,
    borderRadius: 4,
    alignItems: 'center',
  },
  alertButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});