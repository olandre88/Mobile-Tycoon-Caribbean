import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Platform, Modal, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Image } from 'expo-image';
import * as ImagePicker from 'expo-image-picker';
import { MaterialIcons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useGame } from '../../hooks/useGame';

export default function CompanySetupScreen() {
  const { state, dispatch } = useGame();
  const [companyName, setCompanyName] = useState('');
  const [ceoName, setCeoName] = useState('');
  const [companyLogo, setCompanyLogo] = useState<string | null>(null);

  // Web alert state
  const [alertConfig, setAlertConfig] = useState<{
    visible: boolean;
    title: string;
    message: string;
    onOk?: () => void;
  }>({ visible: false, title: '', message: '' });

  const showWebAlert = (title: string, message: string, onOk?: () => void) => {
    if (Platform.OS === 'web') {
      setAlertConfig({ visible: true, title, message, onOk });
    } else {
      Alert.alert(title, message, onOk ? [{ text: 'OK', onPress: onOk }] : undefined);
    }
  };

  const pickImage = async () => {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
      });

      if (!result.canceled && result.assets[0]) {
        setCompanyLogo(result.assets[0].uri);
      }
    } catch (error) {
      showWebAlert('Error', 'Failed to pick image. Please try again.');
    }
  };

  const handleContinue = () => {
    if (!companyName.trim()) {
      showWebAlert('Error', 'Please enter a company name');
      return;
    }

    if (!ceoName.trim()) {
      showWebAlert('Error', 'Please enter CEO name');
      return;
    }

    if (companyName.length < 3) {
      showWebAlert('Error', 'Company name must be at least 3 characters');
      return;
    }

    dispatch({
      type: 'SET_COMPANY',
      payload: {
        name: companyName.trim(),
        ceo: ceoName.trim(),
        logo: companyLogo,
      }
    });

    router.replace('/(game)/(main)');
  };

  return (
        <SafeAreaView style={styles.container} edges={['top', 'bottom']}>
      <LinearGradient
        colors={['#000000', '#8B0040', '#006400']}
        style={styles.background}
      >
        <View style={styles.content}>
          <BlurView intensity={20} style={styles.setupCard}>
            <View style={styles.header}>
              <MaterialIcons name="business" size={48} color="#4DD0E1" />
              <Text style={styles.title}>Company Setup</Text>
              <Text style={styles.subtitle}>
                Welcome {state.username}! Let us build your telecommunications empire
              </Text>
            </View>

            <View style={styles.form}>
              <View style={styles.inputContainer}>
                <Text style={styles.label}>Company Name</Text>
                <TextInput
                  style={styles.input}
                  value={companyName}
                  onChangeText={setCompanyName}
                  placeholder="e.g., Caribbean Connect Ltd"
                  placeholderTextColor="rgba(255,255,255,0.6)"
                />
              </View>

              <View style={styles.inputContainer}>
                <Text style={styles.label}>CEO / President Name</Text>
                <TextInput
                  style={styles.input}
                  value={ceoName}
                  onChangeText={setCeoName}
                  placeholder="Enter CEO name"
                  placeholderTextColor="rgba(255,255,255,0.6)"
                />
              </View>

              <View style={styles.inputContainer}>
                <Text style={styles.label}>Company Logo</Text>
                <TouchableOpacity style={styles.logoContainer} onPress={pickImage}>
                  {companyLogo ? (
                    <Image source={{ uri: companyLogo }} style={styles.logoImage} />
                  ) : (
                    <View style={styles.logoPlaceholder}>
                      <MaterialIcons name="add-photo-alternate" size={32} color="rgba(255,255,255,0.6)" />
                      <Text style={styles.logoText}>Upload Logo</Text>
                    </View>
                  )}
                </TouchableOpacity>
              </View>

              <View style={styles.capitalContainer}>
                <Text style={styles.capitalLabel}>Starting Capital</Text>
                <Text style={styles.capitalAmount}>$30,000,000</Text>
              </View>

              <TouchableOpacity style={styles.continueButton} onPress={handleContinue}>
                <Text style={styles.buttonText}>Start Building Empire</Text>
                <MaterialIcons name="arrow-forward" size={24} color="white" />
              </TouchableOpacity>
            </View>
          </BlurView>
        </View>

        {/* Web Alert Modal */}
        {Platform.OS === 'web' && (
          <Modal visible={alertConfig.visible} transparent animationType="fade">
            <View style={styles.alertOverlay}>
              <View style={styles.alertBox}>
                <Text style={styles.alertTitle}>{alertConfig.title}</Text>
                <Text style={styles.alertMessage}>{alertConfig.message}</Text>
                <TouchableOpacity 
                  style={styles.alertButton}
                  onPress={() => {
                    alertConfig.onOk?.();
                    setAlertConfig(prev => ({ ...prev, visible: false }));
                  }}
                >
                  <Text style={styles.alertButtonText}>OK</Text>
                </TouchableOpacity>
              </View>
            </View>
          </Modal>
        )}
      </LinearGradient>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  setupCard: {
    width: '100%',
    maxWidth: 500,
    borderRadius: 20,
    padding: 30,
    backgroundColor: 'rgba(255,255,255,0.1)',
  },
  header: {
    alignItems: 'center',
    marginBottom: 30,
  },
  title: {
    fontSize: 42,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
    marginTop: 15,
  },
  subtitle: {
    fontSize: 24,
    color: 'rgba(255,255,255,0.8)',
    textAlign: 'center',
    marginTop: 15,
    fontWeight: 'bold',
  },
  form: {
    gap: 20,
  },
  inputContainer: {
    gap: 8,
  },
  label: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
  },
  input: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 12,
    padding: 23,
    fontSize: 24,
    color: 'white',
    fontWeight: 'bold',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
  },
  logoContainer: {
    height: 120,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
    borderStyle: 'dashed',
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoImage: {
    width: '100%',
    height: '100%',
    borderRadius: 12,
  },
  logoPlaceholder: {
    alignItems: 'center',
    gap: 8,
  },
  logoText: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 14,
    fontWeight: 'bold',
  },
  capitalContainer: {
    backgroundColor: 'rgba(76,175,80,0.2)',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(76,175,80,0.3)',
  },
  capitalLabel: {
    fontSize: 14,
    fontWeight: 'bold',
    color: 'white',
    opacity: 0.8,
  },
  capitalAmount: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#4CAF50',
    marginTop: 4,
  },
  continueButton: {
    backgroundColor: '#00ACC1',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginTop: 10,
  },
  buttonText: {
    color: 'white',
    fontSize: 27,
    fontWeight: 'bold',
  },
  alertOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  alertBox: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 8,
    minWidth: 280,
  },
  alertTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    color: 'black',
  },
  alertMessage: {
    fontSize: 16,
    marginBottom: 20,
    color: 'black',
  },
  alertButton: {
    backgroundColor: '#007AFF',
    padding: 10,
    borderRadius: 4,
    alignItems: 'center',
  },
  alertButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});