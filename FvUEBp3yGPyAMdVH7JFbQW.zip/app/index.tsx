import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, Alert, StyleSheet, Platform, KeyboardAvoidingView, ScrollView } from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { router } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useGame } from '../hooks/useGame';

export default function LoginScreen() {
  const { dispatch } = useGame();
  const insets = useSafeAreaInsets();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadSavedCredentials();
  }, []);

  const loadSavedCredentials = async () => {
    try {
      const saved = await AsyncStorage.getItem('mobileCaribbean_credentials');
      if (saved) {
        const { username: savedUsername, password: savedPassword } = JSON.parse(saved);
        setUsername(savedUsername || '');
        setPassword(savedPassword || '');
        setRememberMe(true);
      }
    } catch (error) {
      console.log('Failed to load credentials:', error);
    }
  };

  const showAlert = (title: string, message: string, onOk?: () => void) => {
    Alert.alert(title, message, onOk ? [{ text: 'OK', onPress: onOk }] : undefined);
  };

  const handleAuth = async () => {
    if (!username.trim() || !password.trim()) {
      showAlert('Error', 'Please enter both username and password');
      return;
    }

    if (username.length < 3) {
      showAlert('Error', 'Username must be at least 3 characters long');
      return;
    }

    if (password.length < 6) {
      showAlert('Error', 'Password must be at least 6 characters long');
      return;
    }

    setLoading(true);

    try {
      await new Promise(resolve => setTimeout(resolve, 1000));

      if (isRegistering) {
        const userData = { username, password, createdAt: new Date().toISOString() };
        await AsyncStorage.setItem(`user_${username}`, JSON.stringify(userData));
        showAlert('Success', 'Account created successfully!', () => {
          setIsRegistering(false);
        });
      } else {
        const userData = await AsyncStorage.getItem(`user_${username}`);
        if (!userData) {
          showAlert('Error', 'Account not found. Please register first.');
          setLoading(false);
          return;
        }

        const { password: storedPassword } = JSON.parse(userData);
        if (password !== storedPassword) {
          showAlert('Error', 'Invalid password');
          setLoading(false);
          return;
        }

        if (rememberMe) {
          await AsyncStorage.setItem('mobileCaribbean_credentials', JSON.stringify({ username, password }));
        } else {
          await AsyncStorage.removeItem('mobileCaribbean_credentials');
        }

        dispatch({ type: 'SET_AUTH', payload: { username } });
        router.replace('/(game)/setup');
      }
    } catch (error) {
      showAlert('Error', 'Authentication failed. Please try again.');
    }

    setLoading(false);
  };

  return (
        <SafeAreaView style={styles.container} edges={['top', 'bottom']}>
      <LinearGradient
        colors={['#000000', '#8B0040', '#006400']}
        style={styles.background}
      >
        <KeyboardAvoidingView 
          style={styles.keyboardView}
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}
        >
          <ScrollView 
            contentContainerStyle={styles.scrollContent}
            keyboardShouldPersistTaps="handled"
            showsVerticalScrollIndicator={false}
          >
            <BlurView intensity={20} style={styles.loginCard}>
              <View style={styles.header}>
                <Text style={styles.title}>Mobile Tycoon</Text>
                <Text style={styles.subtitle}>Caribbean</Text>
                <Text style={styles.description}>
                  Build your telecommunications empire across the Caribbean islands
                </Text>
              </View>

              <View style={styles.form}>
                <View style={styles.inputContainer}>
                  <Text style={styles.label}>Username</Text>
                  <TextInput
                    style={styles.input}
                    value={username}
                    onChangeText={setUsername}
                    placeholder="Enter your username"
                    placeholderTextColor="rgba(255,255,255,0.6)"
                    autoCapitalize="none"
                    autoCorrect={false}
                    returnKeyType="next"
                  />
                </View>

                <View style={styles.inputContainer}>
                  <Text style={styles.label}>Password</Text>
                  <TextInput
                    style={styles.input}
                    value={password}
                    onChangeText={setPassword}
                    placeholder="Enter your password"
                    placeholderTextColor="rgba(255,255,255,0.6)"
                    secureTextEntry
                    returnKeyType="done"
                    onSubmitEditing={handleAuth}
                  />
                </View>

                {!isRegistering && (
                  <TouchableOpacity 
                    style={styles.rememberContainer}
                    onPress={() => setRememberMe(!rememberMe)}
                  >
                    <View style={[styles.checkbox, rememberMe && styles.checkboxChecked]}>
                      {rememberMe && <Text style={styles.checkmark}>✓</Text>}
                    </View>
                    <Text style={styles.rememberText}>Remember me</Text>
                  </TouchableOpacity>
                )}

                <TouchableOpacity
                  style={[styles.button, loading && styles.buttonDisabled]}
                  onPress={handleAuth}
                  disabled={loading}
                >
                  <Text style={styles.buttonText}>
                    {loading ? 'Processing...' : (isRegistering ? 'Create Account' : 'Login')}
                  </Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={styles.switchButton}
                  onPress={() => setIsRegistering(!isRegistering)}
                >
                  <Text style={styles.switchText}>
                    {isRegistering ? 'Already have an account? Login' : 'New player? Create Account'}
                  </Text>
                </TouchableOpacity>
              </View>
            </BlurView>
          </ScrollView>
        </KeyboardAvoidingView>
      </LinearGradient>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
  },
  keyboardView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    minHeight: '100%',
  },
  loginCard: {
    width: '100%',
    maxWidth: 400,
    borderRadius: 20,
    padding: 30,
    backgroundColor: 'rgba(255,255,255,0.1)',
  },
  header: {
    alignItems: 'center',
    marginBottom: 30,
  },
  title: {
    fontSize: 42,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 30,
    fontWeight: 'bold',
    color: '#4DD0E1',
    textAlign: 'center',
    marginTop: -8,
  },
  description: {
    fontSize: 21,
    color: 'rgba(255,255,255,0.8)',
    textAlign: 'center',
    marginTop: 15,
    fontWeight: 'bold',
    lineHeight: 30,
  },
  form: {
    gap: 20,
  },
  inputContainer: {
    gap: 8,
  },
  label: {
    fontSize: 21,
    fontWeight: 'bold',
    color: 'white',
  },
  input: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 12,
    padding: 23,
    fontSize: 21,
    color: 'white',
    fontWeight: 'bold',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
    minHeight: 66,
  },
  rememberContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  checkbox: {
    width: 20,
    height: 20,
    borderRadius: 4,
    borderWidth: 2,
    borderColor: 'white',
    justifyContent: 'center',
    alignItems: 'center',
  },
  checkboxChecked: {
    backgroundColor: '#4DD0E1',
  },
  checkmark: {
    color: 'white',
    fontSize: 12,
    fontWeight: 'bold',
  },
  rememberText: {
    color: 'white',
    fontSize: 12,
    fontWeight: 'bold',
  },
  button: {
    backgroundColor: '#00ACC1',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginTop: 10,
    minHeight: 44,
    justifyContent: 'center',
  },
  buttonDisabled: {
    opacity: 0.6,
  },
  buttonText: {
    color: 'white',
    fontSize: 24,
    fontWeight: 'bold',
  },
  switchButton: {
    alignItems: 'center',
    marginTop: 10,
    padding: 10,
  },
  switchText: {
    color: '#4DD0E1',
    fontSize: 12,
    fontWeight: 'bold',
  },
});