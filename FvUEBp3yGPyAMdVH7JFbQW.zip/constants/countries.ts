export interface CountryData {
  id: string;
  name: string;
  population: number;
  gdpPerCapita: number;
  region: string;
  flag: string;
  licenseStatus: 'none' | 'negotiating' | 'owned';
  licenseExpiry?: Date;
  marketSize: 'small' | 'medium' | 'large';
  competitors: number;
}

export const CARIBBEAN_COUNTRIES: CountryData[] = [
  // Small Markets
  {
    id: 'montserrat',
    name: 'Montserrat',
    population: 4992,
    gdpPerCapita: 8500,
    region: 'British Overseas Territories',
    flag: '🇲🇸',
    licenseStatus: 'none',
    marketSize: 'small',
    competitors: 1
  },
  {
    id: 'anguilla',
    name: 'Anguilla',
    population: 15003,
    gdpPerCapita: 12200,
    region: 'British Overseas Territories',
    flag: '🇦🇮',
    licenseStatus: 'none',
    marketSize: 'small',
    competitors: 2
  },
  {
    id: 'bonaire',
    name: 'Bonaire',
    population: 20104,
    gdpPerCapita: 16000,
    region: 'Caribbean Netherlands',
    flag: '🇧🇶',
    licenseStatus: 'none',
    marketSize: 'small',
    competitors: 1
  },
  {
    id: 'bvi',
    name: 'British Virgin Islands',
    population: 30237,
    gdpPerCapita: 34200,
    region: 'British Overseas Territories',
    flag: '🇻🇬',
    licenseStatus: 'none',
    marketSize: 'small',
    competitors: 3
  },
  {
    id: 'cayman',
    name: 'Cayman Islands',
    population: 68136,
    gdpPerCapita: 43800,
    region: 'British Overseas Territories',
    flag: '🇰🇾',
    licenseStatus: 'none',
    marketSize: 'small',
    competitors: 4
  },
  {
    id: 'turks',
    name: 'Turks and Caicos',
    population: 38718,
    gdpPerCapita: 29100,
    region: 'British Overseas Territories',
    flag: '🇹🇨',
    licenseStatus: 'none',
    marketSize: 'small',
    competitors: 2
  },
  {
    id: 'aruba',
    name: 'Aruba',
    population: 106314,
    gdpPerCapita: 25300,
    region: 'Kingdom of Netherlands',
    flag: '🇦🇼',
    licenseStatus: 'none',
    marketSize: 'small',
    competitors: 3
  },
  {
    id: 'curacao',
    name: 'Curaçao',
    population: 190338,
    gdpPerCapita: 15000,
    region: 'Kingdom of Netherlands',
    flag: '🇨🇼',
    licenseStatus: 'none',
    marketSize: 'small',
    competitors: 4
  },
  {
    id: 'sint-maarten',
    name: 'Sint Maarten',
    population: 42876,
    gdpPerCapita: 66800,
    region: 'Kingdom of Netherlands',
    flag: '🇸🇽',
    licenseStatus: 'none',
    marketSize: 'small',
    competitors: 3
  },
  
  // Medium Markets
  {
    id: 'jamaica',
    name: 'Jamaica',
    population: 2900000,
    gdpPerCapita: 4200,
    region: 'Greater Antilles',
    flag: '🇯🇲',
    licenseStatus: 'none',
    marketSize: 'medium',
    competitors: 5
  },
  {
    id: 'puerto-rico',
    name: 'Puerto Rico',
    population: 3200000,
    gdpPerCapita: 31400,
    region: 'Greater Antilles',
    flag: '🇵🇷',
    licenseStatus: 'none',
    marketSize: 'medium',
    competitors: 6
  },
  {
    id: 'trinidad',
    name: 'Trinidad & Tobago',
    population: 1400000,
    gdpPerCapita: 15400,
    region: 'Lesser Antilles',
    flag: '🇹🇹',
    licenseStatus: 'none',
    marketSize: 'medium',
    competitors: 4
  },
  {
    id: 'bahamas',
    name: 'The Bahamas',
    population: 393248,
    gdpPerCapita: 27700,
    region: 'Lucayan Archipelago',
    flag: '🇧🇸',
    licenseStatus: 'none',
    marketSize: 'small',
    competitors: 3
  },
  {
    id: 'barbados',
    name: 'Barbados',
    population: 287371,
    gdpPerCapita: 18600,
    region: 'Lesser Antilles',
    flag: '🇧🇧',
    licenseStatus: 'none',
    marketSize: 'small',
    competitors: 3
  },
  {
    id: 'guyana',
    name: 'Guyana',
    population: 786552,
    gdpPerCapita: 8100,
    region: 'South America',
    flag: '🇬🇾',
    licenseStatus: 'none',
    marketSize: 'small',
    competitors: 3
  },
  {
    id: 'suriname',
    name: 'Suriname',
    population: 597927,
    gdpPerCapita: 7100,
    region: 'South America',
    flag: '🇸🇷',
    licenseStatus: 'none',
    marketSize: 'small',
    competitors: 2
  },

  // Large Markets
  {
    id: 'cuba',
    name: 'Cuba',
    population: 11300000,
    gdpPerCapita: 7600,
    region: 'Greater Antilles',
    flag: '🇨🇺',
    licenseStatus: 'none',
    marketSize: 'large',
    competitors: 2
  },
  {
    id: 'dominican',
    name: 'Dominican Republic',
    population: 10800000,
    gdpPerCapita: 8200,
    region: 'Greater Antilles',
    flag: '🇩🇴',
    licenseStatus: 'none',
    marketSize: 'large',
    competitors: 7
  },
  {
    id: 'colombia',
    name: 'Colombia',
    population: 50900000,
    gdpPerCapita: 6400,
    region: 'South America',
    flag: '🇨🇴',
    licenseStatus: 'none',
    marketSize: 'large',
    competitors: 12
  },
  {
    id: 'venezuela',
    name: 'Venezuela',
    population: 28400000,
    gdpPerCapita: 2500,
    region: 'South America',
    flag: '🇻🇪',
    licenseStatus: 'none',
    marketSize: 'large',
    competitors: 8
  },
  {
    id: 'haiti',
    name: 'Haiti',
    population: 11400000,
    gdpPerCapita: 1800,
    region: 'Greater Antilles',
    flag: '🇭🇹',
    licenseStatus: 'none',
    marketSize: 'large',
    competitors: 4
  },
  {
    id: 'honduras',
    name: 'Honduras',
    population: 9900000,
    gdpPerCapita: 2600,
    region: 'Central America',
    flag: '🇭🇳',
    licenseStatus: 'none',
    marketSize: 'medium',
    competitors: 5
  },
  {
    id: 'nicaragua',
    name: 'Nicaragua',
    population: 6600000,
    gdpPerCapita: 2200,
    region: 'Central America',
    flag: '🇳🇮',
    licenseStatus: 'none',
    marketSize: 'medium',
    competitors: 4
  },
  {
    id: 'belize',
    name: 'Belize',
    population: 419199,
    gdpPerCapita: 4700,
    region: 'Central America',
    flag: '🇧🇿',
    licenseStatus: 'none',
    marketSize: 'small',
    competitors: 2
  }
];

export const calculateLicenseCost = (population: number): number => {
  return Math.round((population / 5000000) * 2500000);
};

export const getCountryByMarketSize = (size: 'small' | 'medium' | 'large') => {
  return CARIBBEAN_COUNTRIES.filter(country => country.marketSize === size);
};

export const getCountryByRegion = (region: string) => {
  return CARIBBEAN_COUNTRIES.filter(country => country.region === region);
};