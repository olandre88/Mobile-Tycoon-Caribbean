import { useEffect } from 'react';
import { useGame } from './useGame';

export function useGameTimer() {
  const { state, dispatch } = useGame();

  useEffect(() => {
    if (!state.isPaused && state.isAuthenticated) {
      // Enhanced timer system for 30-minute gameplay year
      const gameTimer = setInterval(() => {
        // Advance game time by 1 day every ~4.93 seconds
        dispatch({ type: 'ADVANCE_TIME' });
      }, state.gameSpeed);

      // Monthly processing (every 30 game days ≈ 2.5 real minutes)
      const monthlyTimer = setInterval(() => {
        if (!state.isPaused && state.isAuthenticated) {
          // Process monthly expenses and revenue
          const currentDate = new Date(state.gameDate);
          if (currentDate.getDate() === 1) {
            // First of the month - process expenses
            console.log('🗓️ Monthly Processing - First of Month:', currentDate.toLocaleDateString());
            
            // Calculate monthly expenses
            const monthlyExpenses = {
              salaries: state.employees.reduce((sum, emp) => sum + emp.salary, 0),
              maintenance: state.infrastructure.reduce((sum, inf) => sum + inf.maintenanceCost, 0),
              marketing: state.marketingCampaigns
                .filter(c => c.status === 'active')
                .reduce((sum, c) => sum + c.budget, 0),
              loans: state.loans?.reduce((sum, loan) => sum + loan.monthlyPayment, 0) || 0
            };

            const totalExpenses = Object.values(monthlyExpenses).reduce((sum, expense) => sum + expense, 0);

            // Check if company can afford expenses
            if (state.company.capital >= totalExpenses) {
              dispatch({ type: 'SPEND_CAPITAL', payload: totalExpenses });
              dispatch({
                type: 'ADD_NOTIFICATION',
                payload: {
                  type: 'info',
                  message: `💰 Monthly expenses: $${totalExpenses.toLocaleString()} deducted`,
                  id: Date.now().toString()
                }
              });
            } else {
              // Insufficient funds - pause game
              dispatch({ type: 'TOGGLE_PAUSE' });
              dispatch({
                type: 'ADD_NOTIFICATION',
                payload: {
                  type: 'error',
                  message: `🚨 Insufficient funds for monthly expenses! Game paused.`,
                  id: Date.now().toString()
                }
              });
            }
          }
        }
      }, state.gameSpeed * 30); // Check every 30 game days

      // Daily processing timer
      const dailyTimer = setInterval(() => {
        if (!state.isPaused && state.isAuthenticated && state.selectedCountry) {
          // Daily customer acquisition and market dynamics
          processDailyGameEvents();
        }
      }, state.gameSpeed); // Every game day

      return () => {
        clearInterval(gameTimer);
        clearInterval(monthlyTimer);
        clearInterval(dailyTimer);
      };
    }
  }, [state.isPaused, state.isAuthenticated, state.gameSpeed]);

  const processDailyGameEvents = () => {
    // Daily customer acquisition based on new timing
    const baseAcquisition = Math.floor(Math.random() * 50) + 10; // 10-60 customers per day
    
    // Marketing multiplier
    const activeCampaigns = state.marketingCampaigns?.filter(c => 
      c.status === 'active' && c.targetSegment === state.selectedCountry?.id
    ) || [];
    const marketingMultiplier = 1 + (activeCampaigns.length * 0.3);

    // Infrastructure multiplier
    const infrastructureCount = state.infrastructure?.filter(inf => 
      inf.countryId === state.selectedCountry?.id
    ).length || 0;
    const infrastructureMultiplier = Math.min(2.0, 1 + (infrastructureCount * 0.1));

    // Employee multiplier
    const employeeCount = state.employees?.filter(emp => 
      emp.countryId === state.selectedCountry?.id
    ).length || 0;
    const employeeMultiplier = Math.min(1.5, 1 + (employeeCount * 0.05));

    const totalAcquisition = Math.floor(
      baseAcquisition * marketingMultiplier * infrastructureMultiplier * employeeMultiplier
    );

    if (totalAcquisition > 0) {
      // Add customers to the selected country
      for (let i = 0; i < totalAcquisition; i++) {
        const segments = ['budget', 'premium', 'business', 'family', 'home'];
        const selectedSegment = segments[Math.floor(Math.random() * segments.length)];
        
        const newCustomer = {
          id: `customer_${Date.now()}_${i}_${Math.random().toString(36).substr(2, 9)}`,
          segment: selectedSegment,
          arpu: Math.floor(Math.random() * 50) + 25, // $25-75 ARPU
          acquisitionDate: new Date(state.gameDate),
          churnRisk: Math.random() * 0.3 + 0.05, // 5-35% churn risk
          satisfaction: Math.random() * 30 + 70, // 70-100% satisfaction
          countryId: state.selectedCountry?.id || '',
          usage: {
            voice: Math.random() * 400 + 100,
            sms: Math.random() * 150 + 50,
            data: Math.random() * 8 + 2
          },
          isActive: true,
          acquisitionChannel: 'daily_processing',
          devicesPurchased: []
        };

        dispatch({ type: 'ADD_CUSTOMER', payload: newCustomer });
      }

      console.log(`📈 Daily Acquisition: ${totalAcquisition} customers added`);
    }

    // Process customer churn (2.5% monthly base rate)
    const dailyChurnRate = 0.025 / 30; // Monthly rate divided by 30 days
    const activeCustomers = state.customers?.filter(c => 
      c.isActive && c.countryId === state.selectedCountry?.id
    ) || [];
    
    const churnCount = Math.floor(activeCustomers.length * dailyChurnRate);
    if (churnCount > 0) {
      for (let i = 0; i < churnCount && i < activeCustomers.length; i++) {
        const customerToChurn = activeCustomers[i];
        dispatch({ type: 'REMOVE_CUSTOMER', payload: customerToChurn.id });
      }
      console.log(`📉 Daily Churn: ${churnCount} customers lost`);
    }
  };

  return {
    gameYear: state.gameDate.getFullYear(),
    gameMonth: state.gameDate.getMonth() + 1,
    gameDay: state.gameDate.getDate(),
    isPaused: state.isPaused,
    gameSpeed: state.gameSpeed
  };
}