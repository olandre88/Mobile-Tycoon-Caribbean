import React, { createContext, useReducer, useEffect, ReactNode } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Platform } from 'react-native';

export interface Company {
  name: string;
  ceo: string;
  logo: string | null;
  capital: number;
  reputation: number;
}

export interface Country {
  id: string;
  name: string;
  population: number;
  gdpPerCapita: number;
  region: string;
  flag: string;
  licenseStatus: 'none' | 'owned';
  marketSize: 'small' | 'medium' | 'large';
  competitors: number;
}

export interface Employee {
  id: string;
  name: string;
  position: string;
  salary: number;
  skills: {
    technical: number;
    management: number;
    sales: number;
    customerService: number;
  };
  avatar: string;
  hireDate: Date;
  performance: number;
  countryId: string;
  experience: number;
  education: string;
  nationality: string;
}

export interface Infrastructure {
  id: string;
  type: 'cell-tower' | 'base-station' | 'data-controller' | 'fiber-cable' | 'server-rack' | 'satellite-dish';
  name: string;
  cost: number;
  maintenanceCost: number;
  coverage: number;
  capacity: number;
  reliability: number;
  countryId: string;
  installDate: Date;
  status: 'operational' | 'maintenance' | 'offline';
}

export interface Customer {
  id: string;
  segment: 'budget' | 'premium' | 'business' | 'family' | 'home';
  arpu: number;
  acquisitionDate: Date;
  countryId: string;
  isActive: boolean;
}

export interface GameState {
  isAuthenticated: boolean;
  username: string;
  company: Company;
  gameDate: Date;
  gameSpeed: number;
  isPaused: boolean;
  selectedCountry: Country | null;
  countries: Country[];
  employees: Employee[];
  infrastructure: Infrastructure[];
  customers: Customer[];
  notifications: Array<{
    id: string;
    type: 'warning' | 'info' | 'error';
    message: string;
  }>;
  settings: {
    autoSave: boolean;
    soundEnabled: boolean;
    gameSpeed: number;
  };
}

const initialState: GameState = {
  isAuthenticated: false,
  username: '',
  company: {
    name: '',
    ceo: '',
    logo: null,
    capital: 30000000,
    reputation: 50
  },
  gameDate: new Date('2024-01-01'),
  gameSpeed: 4932, // 1 year = 30 minutes
  isPaused: false,
  selectedCountry: null,
  countries: [],
  employees: [],
  infrastructure: [],
  customers: [],
  notifications: [],
  settings: {
    autoSave: true,
    soundEnabled: true,
    gameSpeed: 4932
  }
};

type GameAction = 
  | { type: 'SET_AUTH'; payload: { username: string } }
  | { type: 'SET_COMPANY'; payload: Partial<Company> }
  | { type: 'TOGGLE_PAUSE' }
  | { type: 'ADVANCE_TIME' }
  | { type: 'SELECT_COUNTRY'; payload: Country }
  | { type: 'SET_COUNTRIES'; payload: Country[] }
  | { type: 'ADD_EMPLOYEE'; payload: Employee }
  | { type: 'UPDATE_EMPLOYEE'; payload: { id: string; updates: Partial<Employee> } }
  | { type: 'REMOVE_EMPLOYEE'; payload: string }
  | { type: 'ADD_INFRASTRUCTURE'; payload: Infrastructure }
  | { type: 'ADD_CUSTOMER'; payload: Customer }
  | { type: 'ADD_NOTIFICATION'; payload: { type: 'warning' | 'info' | 'error'; message: string; id?: string } }
  | { type: 'CLEAR_NOTIFICATIONS' }
  | { type: 'UPDATE_SETTINGS'; payload: Partial<GameState['settings']> }
  | { type: 'SPEND_CAPITAL'; payload: number }
  | { type: 'ADD_CAPITAL'; payload: number }
  | { type: 'RESET_GAME' };

function gameReducer(state: GameState, action: GameAction): GameState {
  try {
    switch (action.type) {
      case 'SET_AUTH':
        return { ...state, isAuthenticated: true, username: action.payload.username };
      
      case 'SET_COMPANY':
        return { ...state, company: { ...state.company, ...action.payload } };
      
      case 'TOGGLE_PAUSE':
        return { ...state, isPaused: !state.isPaused };
      
      case 'ADVANCE_TIME':
        if (state.isPaused) return state;
        const newDate = new Date(state.gameDate);
        newDate.setDate(newDate.getDate() + 1);
        return { ...state, gameDate: newDate };
      
      case 'SELECT_COUNTRY':
        return { ...state, selectedCountry: action.payload };
      
      case 'SET_COUNTRIES':
        return { ...state, countries: action.payload };

      case 'ADD_EMPLOYEE':
        return { ...state, employees: [...state.employees, action.payload] };

      case 'UPDATE_EMPLOYEE':
        return {
          ...state,
          employees: state.employees.map(emp =>
            emp.id === action.payload.id ? { ...emp, ...action.payload.updates } : emp
          )
        };

      case 'REMOVE_EMPLOYEE':
        return { ...state, employees: state.employees.filter(emp => emp.id !== action.payload) };

      case 'ADD_INFRASTRUCTURE':
        return { ...state, infrastructure: [...state.infrastructure, action.payload] };

      case 'ADD_CUSTOMER':
        return { ...state, customers: [...state.customers, action.payload] };
      
      case 'ADD_NOTIFICATION':
        const newNotif = {
          ...action.payload,
          id: action.payload.id || Date.now().toString()
        };
        return { ...state, notifications: [...state.notifications, newNotif] };
      
      case 'CLEAR_NOTIFICATIONS':
        return { ...state, notifications: [] };

      case 'SPEND_CAPITAL':
        return {
          ...state,
          company: {
            ...state.company,
            capital: Math.max(0, state.company.capital - action.payload)
          }
        };

      case 'ADD_CAPITAL':
        return {
          ...state,
          company: {
            ...state.company,
            capital: state.company.capital + action.payload
          }
        };
      
      case 'UPDATE_SETTINGS':
        return { 
          ...state, 
          settings: { ...state.settings, ...action.payload },
          gameSpeed: action.payload.gameSpeed ?? state.gameSpeed
        };
      
      case 'RESET_GAME':
        return { ...initialState };
      
      default:
        return state;
    }
  } catch (error) {
    console.error('GameReducer error:', error);
    return state;
  }
}

export const GameContext = createContext<{
  state: GameState;
  dispatch: React.Dispatch<GameAction>;
} | undefined>(undefined);

export function GameProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(gameReducer, initialState);

  // Game time advancement
  useEffect(() => {
    if (!state.isPaused && state.isAuthenticated) {
      const interval = setInterval(() => {
        dispatch({ type: 'ADVANCE_TIME' });
      }, state.gameSpeed);
      return () => clearInterval(interval);
    }
  }, [state.isPaused, state.isAuthenticated, state.gameSpeed]);

  // Auto-save (iOS compatible)
  useEffect(() => {
    if (state.isAuthenticated && state.settings.autoSave) {
      const saveGame = async () => {
        try {
          const gameData = JSON.stringify(state);
          await AsyncStorage.setItem('mobileCaribbean_gameState', gameData);
        } catch (error) {
          console.error('Save failed:', error);
        }
      };
      
      const saveInterval = setInterval(saveGame, 30000);
      return () => clearInterval(saveInterval);
    }
  }, [state, state.settings.autoSave]);

  // Load saved game on startup
  useEffect(() => {
    const loadGame = async () => {
      try {
        const savedGame = await AsyncStorage.getItem('mobileCaribbean_gameState');
        if (savedGame) {
          const gameData = JSON.parse(savedGame);
          // Restore game state if needed
          console.log('Game loaded successfully');
        }
      } catch (error) {
        console.error('Load failed:', error);
      }
    };
    
    loadGame();
  }, []);

  return (
    <GameContext.Provider value={{ state, dispatch }}>
      {children}
    </GameContext.Provider>
  );
}